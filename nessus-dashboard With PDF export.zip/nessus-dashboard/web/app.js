/* Vulnerability dashboard front-end. Works against the local API or against data embedded by `app.py export`. */
(function () {
  "use strict";
  const EMBED = window.__EMBEDDED__ || null;
  const SEV = ["Critical", "High", "Medium", "Low"];
  const SEV_VAR = { Critical: "--sev-critical", High: "--sev-high", Medium: "--sev-medium", Low: "--sev-low" };
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const state = { period: null, enclave: "", data: null, charts: {}, modalRows: [] };
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

  // ------------------------------------------------------------ utilities
  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (n) => (n == null || isNaN(n) ? "–" : Number(n).toLocaleString());
  const fmt1 = (n) => (n == null || isNaN(n) ? "–" : Number(n).toLocaleString(undefined, { maximumFractionDigits: 1 }));
  const periodLabel = (p) => (p ? MONTHS[parseInt(p.slice(5, 7), 10) - 1] + " " + p.slice(0, 4) : "–");
  const periodShort = (p) => (p ? MONTHS[parseInt(p.slice(5, 7), 10) - 1] + " ’" + p.slice(2, 4) : "–");
  const dateLabel = (d) => (d ? d : "–");
  const daysBetween = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);
  const todayIso = () => new Date().toISOString().slice(0, 10);
  const sevClass = (name) => "sev-" + String(name || "").toLowerCase();
  const sevBadge = (name) => `<span class="badge ${sevClass(name)}">${esc(name)}</span>`;

  function delta(cur, prev, goodWhen, suffix) {
    if (prev == null || cur == null) return `<span class="d flat">no previous scan</span>`;
    const d = cur - prev;
    const cls = d === 0 ? "flat" : (goodWhen === "down" ? (d < 0 ? "good" : "bad") : goodWhen === "up" ? (d > 0 ? "good" : "bad") : "flat");
    const sign = d > 0 ? "+" : "";
    const txt = d === 0 ? "no change" : `${sign}${Number.isInteger(d) ? fmt(d) : fmt1(d)}${suffix || ""}`;
    return `<span class="d ${cls}">${d > 0 ? "▲" : d < 0 ? "▼" : "•"} ${txt}</span><span>vs previous</span>`;
  }

  function toast(msg, ms) {
    const t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("show"), ms || 2500);
  }

  function table(headers, rows, opts) {
    opts = opts || {};
    const th = headers.map((h) => `<th class="${h.num ? "num" : ""}">${esc(h.label)}</th>`).join("");
    const body = rows.map((r, i) => `<tr class="${opts.clickable ? "clickable" : ""} ${opts.activeIndex === i ? "active" : ""}" data-i="${i}">` +
      r.map((c, j) => `<td class="${headers[j].num ? "num" : ""} ${headers[j].wrap ? "wrap" : ""} ${headers[j].trunc ? "trunc" : ""} ${headers[j].wide ? "wide" : ""}">${c == null ? "–" : c}</td>`).join("") + "</tr>").join("");
    return `<table class="data"><thead><tr>${th}</tr></thead><tbody>${body || `<tr><td colspan="${headers.length}" class="empty">${esc(opts.empty || "nothing to show")}</td></tr>`}</tbody></table>`;
  }

  // -------------------------------------------------------------- charts
  function chartDefaults() {
    Chart.defaults.color = css("--ink-2");
    Chart.defaults.borderColor = css("--grid");
    Chart.defaults.font.family = 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
    Chart.defaults.font.size = 12;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.plugins.legend.labels.boxWidth = 8;
    Chart.defaults.plugins.legend.labels.boxHeight = 8;
    Chart.defaults.plugins.legend.position = "top";
    Chart.defaults.plugins.legend.align = "end";
    Chart.defaults.plugins.tooltip.backgroundColor = css("--ink");
    Chart.defaults.plugins.tooltip.titleColor = css("--page");
    Chart.defaults.plugins.tooltip.bodyColor = css("--page");
    Chart.defaults.plugins.tooltip.padding = 8;
    Chart.defaults.plugins.tooltip.cornerRadius = 6;
    Chart.defaults.animation = false;
  }
  function makeChart(id, config) {
    if (state.charts[id]) { state.charts[id].destroy(); delete state.charts[id]; }
    const el = document.getElementById(id);
    if (!el) return;
    state.charts[id] = new Chart(el.getContext("2d"), config);
  }
  const axisBase = () => ({
    x: { grid: { display: false }, border: { color: css("--axis") }, ticks: { maxRotation: 0, autoSkip: true } },
    y: { beginAtZero: true, grid: { color: css("--grid") }, border: { display: false }, ticks: { precision: 0, callback: (v) => fmt(v) } },
  });
  const stackedBar = (sevKey) => ({
    label: sevKey, backgroundColor: css(SEV_VAR[sevKey]), borderColor: css("--surface"),
    borderWidth: { top: 2, bottom: 0, left: 0, right: 0 }, borderSkipped: false, barPercentage: 0.7, categoryPercentage: 0.8,
  });

  // --------------------------------------------------------------- loading
  async function fetchDashboard(period, enclave) {
    if (EMBED) {
      const d = EMBED.dashboards[enclave || ""] || EMBED.dashboards[""];
      return JSON.parse(JSON.stringify(d));
    }
    const r = await fetch(`/api/dashboard?period=${encodeURIComponent(period || "")}&enclave=${encodeURIComponent(enclave || "")}`, { cache: "no-store" });
    if (!r.ok) throw new Error("server returned " + r.status);
    const d = await r.json();
    if (d.error) throw new Error(d.error);
    return d;
  }

  function readHash() {
    const h = new URLSearchParams(location.hash.replace(/^#/, ""));
    state.period = h.get("period") || null;
    state.enclave = h.get("enclave") || "";
  }
  function writeHash() {
    const h = new URLSearchParams();
    if (state.period) h.set("period", state.period);
    if (state.enclave) h.set("enclave", state.enclave);
    history.replaceState(null, "", "#" + h.toString());
  }

  async function load() {
    document.querySelector("main").classList.add("skeleton");
    try {
      const d = await fetchDashboard(state.period, state.enclave);
      state.data = d;
      if (!d.empty) { state.period = d.selection.period; state.enclave = d.selection.enclave || ""; }
      writeHash();
      render(d);
    } catch (e) {
      $("#banner").style.display = "";
      $("#banner").textContent = "Could not load dashboard data: " + e.message;
    } finally {
      document.querySelector("main").classList.remove("skeleton");
    }
  }

  // ---------------------------------------------------------------- render
  function render(d) {
    chartDefaults();
    fillSelectors(d);
    if (d.empty) {
      $("#banner").style.display = "";
      $("#banner").innerHTML = "No scans loaded yet. Put <code>.nessus</code>, <code>.csv</code> or <code>.xlsx</code> exports under <code>data/scans/&lt;Enclave&gt;/</code> and click <b>Refresh data</b>.";
      renderDataPanel(d.meta);
      return;
    }
    const sel = d.selection;
    const missing = sel.enclaves_total - sel.enclaves_in_period;
    const banner = $("#banner");
    if (!state.enclave && missing > 0) {
      banner.style.display = "";
      banner.textContent = `${missing} of ${sel.enclaves_total} enclaves have no scan in ${periodLabel(sel.period)}; totals below cover only the ${sel.enclaves_in_period} that were scanned.`;
    } else banner.style.display = "none";
    $("#subtitle").textContent = `${state.enclave || "All enclaves"} · ${periodLabel(sel.period)} · scans ${sel.latest_scan_date ? "through " + sel.latest_scan_date : ""}`;
    $("#export").href = `/api/export?period=${encodeURIComponent(sel.period)}`;
    $("#brief").href = `/api/brief?period=${encodeURIComponent(sel.period)}&enclave=${encodeURIComponent(state.enclave || "")}`;
    renderKpis(d); renderTrend(d); renderHealth(d); renderEnclaves(d); renderChange(d); renderAge(d);
    renderSla(d); renderCoverage(d); renderTop(d); renderHosts(d); renderKev(d);
    renderPoamSummary(d); renderPoamCoverage(d); renderPoamOverdue(d); renderPoamGaps(d); renderDataPanel(d.meta);
  }

  function fillSelectors(d) {
    const ps = $("#period"), es = $("#enclave");
    const periods = EMBED ? [EMBED.period] : d.meta.periods.slice().reverse();
    ps.innerHTML = periods.map((p) => `<option value="${esc(p)}" ${p === state.period ? "selected" : ""}>${esc(periodLabel(p))}</option>`).join("");
    ps.disabled = !!EMBED;
    es.innerHTML = `<option value="">All enclaves</option>` + d.meta.enclaves.map((e) => `<option value="${esc(e)}" ${e === state.enclave ? "selected" : ""}>${esc(e)}</option>`).join("");
  }

  function renderKpis(d) {
    const k = d.kpis, h = k.health, nf = d.new_fixed.totals_sev;
    const sevTile = (name) => {
      const s = k.severity[name];
      return `<div class="card tile"><div class="label"><span class="dot ${name.toLowerCase()}"></span>${name}</div>
        <div class="value">${fmt(s.value)}</div><div class="delta">${delta(s.value, s.prev, "down")}</div>
        <div class="foot">${fmt(nf.new[name])} new · ${fmt(nf.fixed[name])} fixed</div></div>`;
    };
    const kevFoot = d.meta.kev_entries ? `${fmt(k.kev.value)} on CISA KEV (${fmt(k.kev.cves)} CVEs)` : "KEV catalog not loaded";
    const crit = d.sla.by_severity.Critical;
    const chNot = d.poam.coverage.Critical.not_on_poam + d.poam.coverage.High.not_on_poam;
    $("#kpis").innerHTML = `
      <div class="card tile hero"><div class="label">Network health score</div>
        <div class="value">${h.score == null ? "–" : fmt1(h.score)}<span class="grade">${esc(h.grade || "–")}</span></div>
        <div class="delta">${delta(h.score, h.prev_score, "up", " pts")}</div>
        <div class="meter"><span style="width:${Math.max(0, Math.min(100, h.score || 0))}%"></span></div>
        <div class="foot">${fmt1(h.density)} weighted findings per host · previous grade ${esc(h.prev_grade || "–")}</div></div>
      <div class="card tile"><div class="label">Hosts scanned</div><div class="value">${fmt(k.hosts.value)}</div>
        <div class="delta">${delta(k.hosts.value, k.hosts.prev, "none")}</div>
        <div class="foot">${d.selection.enclaves_in_period} of ${d.selection.enclaves_total} enclaves · +${fmt(d.coverage.added_total)} / −${fmt(d.coverage.dropped_total)} hosts</div></div>
      ${sevTile("Critical")}${sevTile("High")}${sevTile("Medium")}
      <div class="card tile"><div class="label">Exploit available</div><div class="value">${fmt(k.exploitable.value)}</div>
        <div class="delta">${delta(k.exploitable.value, k.exploitable.prev, "down")}</div><div class="foot">${kevFoot}</div></div>
      <div class="card tile"><div class="label">Past SLA</div><div class="value">${fmt(k.sla_overdue.value)}</div>
        <div class="delta"><span class="d flat">of ${fmt(k.total.value)} open findings</span></div>
        <div class="foot">Critical within ${crit.sla_days} d: ${crit.compliance == null ? "–" : fmt1(crit.compliance) + "%"}</div></div>
      <div class="card tile"><div class="label">Not on POA&amp;M</div><div class="value">${d.poam.loaded ? fmt(k.not_on_poam.value) : "–"}</div>
        <div class="delta"><span class="d flat">${d.poam.loaded ? "findings with no POA&M item" : "no POA&M loaded"}</span></div>
        <div class="foot">${d.poam.loaded ? fmt(chNot) + " critical / high untracked" : "drop the workbook in data/poam"}</div></div>
      <div class="card tile"><div class="label">Change this period</div>
        <div class="value"><span style="color:var(--new)">+${fmt(k.new)}</span> <span style="font-size:18px;color:var(--muted)">/</span> <span style="color:var(--fixed)">−${fmt(k.fixed)}</span></div>
        <div class="delta"><span class="d flat">new / fixed · ${fmt(k.persistent)} persistent</span></div>
        <div class="foot">${d.new_fixed.fixed_avg_days_open != null ? "fixed items were open " + fmt1(d.new_fixed.fixed_avg_days_open) + " d on average" : "first scan: nothing to compare"}</div></div>`;
  }

  function renderTrend(d) {
    const t = d.trend;
    $("#trend-hint").textContent = state.enclave ? state.enclave : `all enclaves, ${d.meta.enclaves.length} total`;
    makeChart("chart-trend", {
      type: "bar",
      data: { labels: t.map((r) => periodShort(r.period)), datasets: SEV.map((s) => ({ ...stackedBar(s), data: t.map((r) => r[s]) })) },
      options: {
        responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: { ...axisBase().x, stacked: true }, y: { ...axisBase().y, stacked: true } },
        plugins: { tooltip: { callbacks: {
          title: (items) => { const r = t[items[0].dataIndex]; return `${periodLabel(r.period)} · ${fmt(r.hosts)} hosts · ${r.scans} scan${r.scans === 1 ? "" : "s"}`; },
          footer: (items) => { const r = t[items[0].dataIndex]; return `Total ${fmt(SEV.reduce((a, s) => a + r[s], 0))} · health ${r.health == null ? "–" : r.health} (${r.grade || "–"})`; },
        } } },
      },
    });
    $("#card-trend .table-view").innerHTML = table(
      [{ label: "Month" }, { label: "Scans", num: true }, { label: "Hosts", num: true }, ...SEV.map((s) => ({ label: s, num: true })), { label: "Total", num: true }, { label: "Health", num: true }],
      t.map((r) => [periodLabel(r.period), r.scans, fmt(r.hosts), ...SEV.map((s) => fmt(r[s])), fmt(SEV.reduce((a, s) => a + r[s], 0)), r.health == null ? "–" : `${r.health} (${r.grade})`]));
  }

  function renderHealth(d) {
    const t = d.trend;
    const accent = css("--accent");
    makeChart("chart-health", {
      type: "line",
      data: { labels: t.map((r) => periodShort(r.period)), datasets: [{
        label: "Health score", data: t.map((r) => r.health), borderColor: accent, backgroundColor: accent + "22",
        borderWidth: 2, pointRadius: 3, pointHoverRadius: 6, pointBackgroundColor: accent, fill: true, tension: 0.25, spanGaps: true }] },
      options: {
        responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: axisBase().x, y: { ...axisBase().y, min: 0, max: 100, ticks: { stepSize: 25 } } },
        plugins: { legend: { display: false }, tooltip: { callbacks: {
          title: (items) => periodLabel(t[items[0].dataIndex].period),
          label: (item) => { const r = t[item.dataIndex]; return ` ${r.health == null ? "–" : r.health} (${r.grade}) · ${fmt(r.hosts)} hosts`; } } } },
      },
    });
    $("#card-health .table-view").innerHTML = table([{ label: "Month" }, { label: "Health", num: true }, { label: "Grade" }, { label: "Hosts", num: true }],
      t.map((r) => [periodLabel(r.period), r.health == null ? "–" : r.health, r.grade || "–", fmt(r.hosts)]));
  }

  function meter(score) {
    if (score == null) return "–";
    const col = score >= 75 ? css("--good") : score >= 50 ? css("--warning") : css("--sev-critical");
    return `<div class="meter-cell"><div class="bar"><span style="width:${Math.max(0, Math.min(100, score))}%;background:${col}"></span></div><span class="val">${fmt1(score)}</span></div>`;
  }

  function renderEnclaves(d) {
    const rows = d.enclaves;
    const activeIndex = rows.findIndex((r) => r.enclave === state.enclave);
    const html = table(
      [{ label: "Enclave" }, { label: "Scan date" }, { label: "Hosts", num: true }, { label: "Critical", num: true }, { label: "High", num: true }, { label: "Medium", num: true }, { label: "Low", num: true },
       { label: "Exploitable", num: true }, { label: "KEV", num: true }, { label: "Health" }, { label: "Grade" }, { label: "Δ health", num: true }],
      rows.map((r) => {
        if (!r.scanned) return [`<b>${esc(r.enclave)}</b>`, `<span class="dim">no scan this period${r.last_period ? " · last " + periodLabel(r.last_period) : ""}</span>`, null, null, null, null, null, null, null, null, null, null];
        const dh = r.prev_health == null ? null : r.health - r.prev_health;
        const sevCell = (s) => { const dv = r["prev_" + s] == null ? null : r[s] - r["prev_" + s]; return `${fmt(r[s])}${dv == null || dv === 0 ? "" : ` <span class="dim" style="font-size:11px">(${dv > 0 ? "+" : ""}${dv})</span>`}`; };
        return [`<b>${esc(r.enclave)}</b>`, r.scan_date, `${fmt(r.hosts)}${r.prev_hosts != null && r.prev_hosts !== r.hosts ? ` <span class="dim" style="font-size:11px">(${r.hosts - r.prev_hosts > 0 ? "+" : ""}${r.hosts - r.prev_hosts})</span>` : ""}`,
          sevCell("Critical"), sevCell("High"), sevCell("Medium"), sevCell("Low"), fmt(r.exploitable), fmt(r.kev), meter(r.health), `<span class="badge grade">${esc(r.grade)}</span>`,
          dh == null ? "–" : `<span class="${dh > 0 ? "d good" : dh < 0 ? "d bad" : ""}" style="font-weight:600;color:${dh > 0 ? "var(--good-ink)" : dh < 0 ? "var(--bad-ink)" : "inherit"}">${dh > 0 ? "+" : ""}${fmt1(dh)}</span>`];
      }), { clickable: true, activeIndex });
    const body = $("#card-enclaves .card-body");
    body.innerHTML = html;
    $$("tr.clickable", body).forEach((tr) => tr.addEventListener("click", () => {
      const r = rows[+tr.dataset.i];
      state.enclave = state.enclave === r.enclave ? "" : r.enclave;
      load();
    }));
  }

  function renderChange(d) {
    const per = d.new_fixed.per_enclave, tot = d.new_fixed.totals;
    $("#change-hint").textContent = `+${fmt(tot.new)} new · −${fmt(tot.fixed)} fixed · ${fmt(tot.persistent)} persistent`;
    const labels = per.map((r) => r.enclave);
    makeChart("chart-change", {
      type: "bar",
      data: { labels, datasets: [
        { label: "Fixed (no longer detected)", data: per.map((r) => -r.fixed), backgroundColor: css("--fixed"), borderRadius: 4, barPercentage: 0.6, categoryPercentage: 0.7 },
        { label: "New", data: per.map((r) => r.new), backgroundColor: css("--new"), borderRadius: 4, barPercentage: 0.6, categoryPercentage: 0.7 },
      ] },
      options: {
        indexAxis: "y", responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: { stacked: true, grid: { color: css("--grid") }, border: { display: false }, ticks: { callback: (v) => fmt(Math.abs(v)) } },
                  y: { stacked: true, grid: { display: false }, border: { color: css("--axis") } } },
        plugins: { tooltip: { callbacks: {
          label: (item) => ` ${item.dataset.label}: ${fmt(Math.abs(item.raw))}`,
          footer: (items) => { const r = per[items[0].dataIndex]; return r.baseline ? "first scan for this enclave" : `persistent ${fmt(r.persistent)} · vs ${periodLabel(r.prev_period)}`; } } } },
      },
    });
    $("#card-change .table-view").innerHTML = table(
      [{ label: "Enclave" }, { label: "Compared to" }, { label: "New", num: true }, { label: "New C/H", num: true }, { label: "Fixed", num: true }, { label: "Fixed C/H", num: true }, { label: "Persistent", num: true }],
      per.map((r) => [esc(r.enclave), r.baseline ? "first scan" : periodLabel(r.prev_period), fmt(r.new), `${r.new_sev.Critical} / ${r.new_sev.High}`, fmt(r.fixed), `${r.fixed_sev.Critical} / ${r.fixed_sev.High}`, fmt(r.persistent)]));
    $("#change-note").textContent = "A finding counts as fixed when the same host, plugin and port no longer appear in the next scan. Hosts that dropped out of the scan make their findings look fixed; check scan coverage.";
  }

  function renderAge(d) {
    const a = d.age;
    makeChart("chart-age", {
      type: "bar",
      data: { labels: a.map((b) => b.label), datasets: SEV.map((s) => ({ ...stackedBar(s), data: a.map((b) => b[s]) })) },
      options: { responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: { ...axisBase().x, stacked: true }, y: { ...axisBase().y, stacked: true } },
        plugins: { tooltip: { callbacks: { footer: (items) => `Total ${fmt(SEV.reduce((acc, s) => acc + a[items[0].dataIndex][s], 0))}` } } } },
    });
    $("#card-age .table-view").innerHTML = table([{ label: "Age" }, ...SEV.map((s) => ({ label: s, num: true })), { label: "Total", num: true }],
      a.map((b) => [b.label, ...SEV.map((s) => fmt(b[s])), fmt(SEV.reduce((acc, s) => acc + b[s], 0))]));
  }

  function renderSla(d) {
    const s = d.sla.by_severity, kev = d.sla.kev, m = d.mttr;
    $("#sla-hint").textContent = "share of open findings still inside their SLA window";
    const row = (name, st, labelHtml) => {
      const pct = st.compliance;
      const col = pct == null ? css("--muted") : pct >= 90 ? css("--good") : pct >= 70 ? css("--warning") : css("--sev-critical");
      return `<div class="meter-row"><div class="name">${labelHtml}</div>
        <div class="bar"><span style="width:${pct == null ? 0 : pct}%;background:${col}"></span></div>
        <div class="pct">${pct == null ? "–" : fmt1(pct) + "%"}</div>
        <div class="sub">${st.total ? `${fmt(st.within)} of ${fmt(st.total)} within ${st.sla_days} days · <b>${fmt(st.overdue)} overdue</b> · avg age ${fmt1(st.avg_age)} d · oldest ${fmt(st.oldest)} d` : "no open findings"}</div></div>`;
    };
    const kevRow = kev.sla_days ? row("KEV", { compliance: kev.total ? Math.round(1000 * (kev.total - kev.overdue) / kev.total) / 10 : null,
      total: kev.total, within: kev.total - kev.overdue, overdue: kev.overdue, sla_days: kev.sla_days, avg_age: null, oldest: null },
      `<span class="badge kev">KEV</span>`).replace(/ · avg age – d · oldest – d/, "") : "";
    let html = `<div class="meter-list">` + SEV.map((n) => row(n, s[n], `<span class="dot ${n.toLowerCase()}"></span>${n}`)).join("") + kevRow + `</div>`;
    html += `<dl class="kv" style="margin-top:14px"><dt>Mean time to remediate</dt><dd>${SEV.map((n) => `${n} <b>${m[n].mean_days == null ? "–" : fmt1(m[n].mean_days) + " d"}</b> <span class="dim" style="color:var(--muted)">(${fmt(m[n].closed)} closed)</span>`).join(" · ")}</dd></dl>`;
    $("#card-sla .card-body").innerHTML = html;
    const sd = d.meta.sla_days;
    $("#sla-note").textContent = `SLA windows from config.json: Critical ${sd.Critical} d, High ${sd.High} d, Medium ${sd.Medium} d, Low ${sd.Low} d, KEV ${sd.KEV} d. Time to remediate = first detection to the first scan where the finding is gone, over all loaded history.`;
  }

  function renderCoverage(d) {
    const per = d.coverage.per_enclave;
    const chips = (list, n) => list.length ? `<details><summary>${n} host${n === 1 ? "" : "s"}</summary><div class="chips">${list.map((h) => `<span class="chip">${esc(h)}</span>`).join("")}${n > list.length ? `<span class="chip">… ${n - list.length} more</span>` : ""}</div></details>` : "0";
    $("#card-coverage .card-body").innerHTML = table(
      [{ label: "Enclave" }, { label: "Hosts", num: true }, { label: "Previous", num: true }, { label: "Change", num: true }, { label: "New hosts" }, { label: "Dropped hosts" }],
      per.map((r) => [esc(r.enclave), fmt(r.hosts), r.prev_hosts == null ? "–" : fmt(r.prev_hosts),
        r.prev_hosts == null ? "first scan" : `<span style="color:${r.hosts - r.prev_hosts < 0 ? "var(--bad-ink)" : "inherit"}">${r.hosts - r.prev_hosts > 0 ? "+" : ""}${fmt(r.hosts - r.prev_hosts)}</span>`,
        chips(r.added, r.added_n), chips(r.dropped, r.dropped_n)]));
  }

  function poamBadge(p) {
    if (!p) return `<span class="badge poam-none">none</span>`;
    const open = ["Ongoing", "Delayed"].includes(p.status);
    return `<span class="badge ${open ? "poam-open" : "poam-closed"}" title="${esc(p.item_id)}${p.scheduled ? " · due " + p.scheduled : ""}${p.items > 1 ? " · " + p.items + " items" : ""}">${esc(p.status)}</span>`;
  }
  const flags = (r) => [r.is_kev ? `<span class="badge kev" title="in the CISA Known Exploited Vulnerabilities catalog">KEV</span>` : "",
    r.exploit ? `<span class="badge exploit" title="${esc(r.frameworks || "exploit available")}">Exploit</span>` : "",
    r.malware ? `<span class="badge exploit">Malware</span>` : ""].filter(Boolean).join(" ") || `<span class="dim">–</span>`;

  function renderTop(d) {
    const rows = d.top_vulns;
    const body = $("#card-top .card-body");
    body.innerHTML = table(
      [{ label: "Severity" }, { label: "Plugin", num: true }, { label: "Vulnerability", wrap: true }, { label: "Hosts", num: true }, { label: "Enclaves", num: true }, { label: "Flags" }, { label: "CVSS3", num: true }, { label: "VPR", num: true }, { label: "First seen" }, { label: "POA&M" }, { label: "Risk", num: true }],
      rows.map((r) => [sevBadge(r.severity_name), r.plugin_id, `<span title="${esc(r.solution)}">${esc(r.name)}</span>${r.cves ? `<div class="dim" style="font-size:11px">${esc(r.cves.split(",").slice(0, 3).join(", "))}${r.cves.split(",").length > 3 ? " …" : ""}</div>` : ""}`,
        fmt(r.hosts), r.enclaves, flags(r), r.cvss3 == null ? "–" : r.cvss3, r.vpr == null ? "–" : r.vpr, r.first_seen, poamBadge(r.poam_status), fmt1(r.risk)]),
      { clickable: true, empty: "no findings in this scope" });
    $$("tr.clickable", body).forEach((tr) => tr.addEventListener("click", () => { const r = rows[+tr.dataset.i]; openModal(`${r.name} (plugin ${r.plugin_id})`, { plugin_id: r.plugin_id }); }));
  }

  function renderHosts(d) {
    const rows = d.worst_hosts;
    const body = $("#card-hosts .card-body");
    body.innerHTML = table(
      [{ label: "Host" }, { label: "Enclave" }, { label: "OS", trunc: true }, { label: "C", num: true }, { label: "H", num: true }, { label: "M", num: true }, { label: "L", num: true }, { label: "Exploit", num: true }, { label: "KEV", num: true }, { label: "Score", num: true }],
      rows.map((r) => [`<b>${esc(r.host_key)}</b>${r.ip && r.ip !== r.host_key ? `<div class="dim" style="font-size:11px">${esc(r.ip)}</div>` : ""}`, esc(r.enclave), `<span class="dim" title="${esc(r.os || "")}">${esc(r.os || "–")}</span>`,
        r.Critical, r.High, r.Medium, r.Low, r.exploitable, r.kev, fmt1(r.score)]),
      { clickable: true, empty: "no hosts in this scope" });
    $$("tr.clickable", body).forEach((tr) => tr.addEventListener("click", () => { const r = rows[+tr.dataset.i]; openModal(`${r.host_key} (${r.enclave})`, { host_key: r.host_key, enclave: r.enclave }); }));
  }

  function renderKev(d) {
    const rows = d.kev_items;
    $("#kev-hint").textContent = d.meta.kev_entries ? `${fmt(d.kpis.kev.value)} findings match ${fmt(d.kpis.kev.cves)} catalog CVEs` : "";
    const body = $("#card-kev .card-body");
    if (!d.meta.kev_entries) { body.innerHTML = `<div class="empty">KEV catalog not loaded. Run <code>python app.py update-kev</code> (needs internet) or copy the CISA JSON/CSV into <code>data/kev</code>.</div>`; return; }
    body.innerHTML = table(
      [{ label: "CVE" }, { label: "Vulnerability", trunc: true, wide: true }, { label: "Severity" }, { label: "Hosts", num: true }, { label: "CISA due" }, { label: "First seen" }, { label: "POA&M" }],
      rows.map((r) => [`<b>${esc(r.cve)}</b>${r.ransomware ? `<div><span class="badge outline">ransomware</span></div>` : ""}`, `<span title="${esc(r.name)}">${esc(r.name)}</span><div class="dim" style="font-size:11px">${esc(r.vendor)} ${esc(r.product)}</div>`, sevBadge(r.severity_name), fmt(r.hosts),
        `${r.due_date || "–"} ${r.past_due ? `<span class="badge overdue">past due</span>` : ""}`, r.first_seen, r.on_poam ? `<span class="badge poam-open">yes</span>` : `<span class="badge poam-none">no</span>`]),
      { clickable: true, empty: "no findings match a KEV entry" });
    $$("tr.clickable", body).forEach((tr) => tr.addEventListener("click", () => { const r = rows[+tr.dataset.i]; openModal(`${r.cve} · ${r.name}`, { q: r.cve, kev: 1 }); }));
  }

  function renderPoamSummary(d) {
    const p = d.poam, body = $("#card-poam-summary .card-body");
    if (!p.loaded) { $("#poam-hint").textContent = ""; body.innerHTML = `<div class="empty">No POA&amp;M loaded. Copy the eMASS POA&amp;M export (.xlsx or .csv) into <code>data/poam</code> and click Refresh data.</div>`; return; }
    const order = [["Ongoing", "--cat-1"], ["Delayed", "--cat-2"], ["Completed", "--cat-3"], ["Risk Accepted", "--cat-7"], ["Not Applicable", "--persistent"]];
    const counts = Object.assign({}, p.status_counts);
    const other = Object.keys(counts).filter((k) => !order.some((o) => o[0] === k)).reduce((a, k) => a + counts[k], 0);
    const segs = order.map(([k, v]) => [k, counts[k] || 0, css(v)]).concat(other ? [["Other", other, css("--muted")]] : []).filter((s) => s[1] > 0);
    const total = segs.reduce((a, s) => a + s[1], 0);
    $("#poam-hint").textContent = `${fmt(total)} items in workbook`;
    body.innerHTML = `<div class="segbar">${segs.map((s) => `<span style="flex:${s[1]};background:${s[2]};color:${s[0] === "Not Applicable" ? "#0b0b0b" : "#fff"}" title="${esc(s[0])}: ${s[1]}">${s[1] / total > 0.08 ? s[1] : ""}</span>`).join("")}</div>
      <div class="legend">${segs.map((s) => `<span><i style="background:${s[2]}"></i>${esc(s[0])} ${fmt(s[1])}</span>`).join("")}</div>
      <dl class="kv" style="margin-top:14px">
        <dt>Open items</dt><dd>${fmt((counts.Ongoing || 0) + (counts.Delayed || 0))}</dd>
        <dt>Past scheduled completion</dt><dd><b style="color:${p.overdue_n ? "var(--bad-ink)" : "inherit"}">${fmt(p.overdue_n)}</b></dd>
        <dt>Due in next 30 days</dt><dd>${fmt(p.due_30_n)}</dd>
        <dt>Open with no scheduled date</dt><dd>${fmt(p.no_date_n)}</dd>
        <dt>Closed items still detected</dt><dd>${fmt(p.closed_but_present.length)}${p.closed_but_present.length >= 15 ? "+" : ""} plugins</dd>
      </dl>`;
  }

  function renderPoamCoverage(d) {
    const c = d.poam.coverage;
    const series = [["On POA&M (open)", "open", css("--cat-1")], ["On POA&M (closed)", "closed", css("--cat-closed")], ["Not on POA&M", "not_on_poam", css("--cat-8")]];
    makeChart("chart-poam", {
      type: "bar",
      data: { labels: SEV, datasets: series.map(([label, key, color]) => ({ label, data: SEV.map((s) => c[s][key]), backgroundColor: color, borderColor: css("--surface"), borderWidth: { right: 2, left: 0, top: 0, bottom: 0 }, borderSkipped: false, barPercentage: 0.6, categoryPercentage: 0.8 })) },
      options: { indexAxis: "y", responsive: true, maintainAspectRatio: false, interaction: { mode: "index", intersect: false },
        scales: { x: { stacked: true, grid: { color: css("--grid") }, border: { display: false }, ticks: { precision: 0, callback: (v) => fmt(v) } }, y: { stacked: true, grid: { display: false }, border: { color: css("--axis") } } },
        plugins: { tooltip: { callbacks: { footer: (items) => { const s = SEV[items[0].dataIndex]; const t = c[s].open + c[s].closed + c[s].not_on_poam; return `${fmt(t)} findings · ${t ? Math.round(100 * (c[s].open + c[s].closed) / t) : 0}% tracked`; } } } } },
    });
    $("#card-poam-cov .table-view").innerHTML = table([{ label: "Severity" }, { label: "On POA&M (open)", num: true }, { label: "On POA&M (closed)", num: true }, { label: "Not on POA&M", num: true }, { label: "Tracked", num: true }],
      SEV.map((s) => { const t = c[s].open + c[s].closed + c[s].not_on_poam; return [s, fmt(c[s].open), fmt(c[s].closed), fmt(c[s].not_on_poam), t ? Math.round(100 * (c[s].open + c[s].closed) / t) + "%" : "–"]; }));
  }

  function renderPoamOverdue(d) {
    const rows = d.poam.overdue_items, today = todayIso();
    const body = $("#card-poam-overdue .card-body");
    if (!d.poam.loaded) { body.innerHTML = `<div class="empty">No POA&amp;M loaded.</div>`; return; }
    body.innerHTML = table(
      [{ label: "Item" }, { label: "Description", trunc: true, wide: true }, { label: "Severity" }, { label: "Scheduled" }, { label: "Overdue", num: true }, { label: "Status" }, { label: "Hosts affected", num: true }, { label: "Office" }],
      rows.map((r) => [`<b>${esc(r.item_id)}</b>`, `<span title="${esc(r.description)}">${esc(r.description)}</span>`, esc(r.severity || "–"), r.scheduled, `${fmt(daysBetween(r.scheduled, today))} d`, `<span class="badge poam-open">${esc(r.status)}</span>`, r.plugin_ids ? fmt(r.hosts_affected) : "–", esc(r.office || "–")]),
      { empty: "no overdue POA&M items" });
    if (d.poam.overdue_n > rows.length) body.insertAdjacentHTML("beforeend", `<div class="note">showing ${rows.length} of ${fmt(d.poam.overdue_n)} overdue items</div>`);
  }

  function renderPoamGaps(d) {
    const body = $("#card-poam-gaps .card-body");
    if (!d.poam.loaded) { body.innerHTML = `<div class="empty">No POA&amp;M loaded.</div>`; return; }
    const un = d.poam.unmatched_top, cl = d.poam.closed_but_present;
    let html = `<h3 style="font-size:13px;margin:4px 0 6px">Critical / high findings with no POA&amp;M item</h3>` + table(
      [{ label: "Severity" }, { label: "Plugin", num: true }, { label: "Vulnerability", wrap: true }, { label: "Hosts", num: true }],
      un.map((r) => [sevBadge(r.severity_name), r.plugin_id, esc(r.name), fmt(r.hosts)]), { clickable: true, empty: "every critical and high finding has a POA&M item" });
    html += `<h3 style="font-size:13px;margin:16px 0 6px">Closed on POA&amp;M but still detected</h3>` + table(
      [{ label: "Severity" }, { label: "Plugin", num: true }, { label: "Vulnerability", wrap: true }, { label: "Hosts", num: true }, { label: "POA&M status" }],
      cl.map((r) => [sevBadge(r.severity_name), r.plugin_id, esc(r.name), fmt(r.hosts), r.statuses.map((s) => `<span class="badge poam-closed">${esc(s)}</span>`).join(" ")]), { clickable: true, empty: "nothing marked closed is still being detected" });
    body.innerHTML = html;
    const tables = $$("table", body);
    $$("tr.clickable", tables[0]).forEach((tr) => tr.addEventListener("click", () => { const r = un[+tr.dataset.i]; openModal(`${r.name} (plugin ${r.plugin_id})`, { plugin_id: r.plugin_id }); }));
    $$("tr.clickable", tables[1]).forEach((tr) => tr.addEventListener("click", () => { const r = cl[+tr.dataset.i]; openModal(`${r.name} (plugin ${r.plugin_id})`, { plugin_id: r.plugin_id }); }));
  }

  function renderDataPanel(meta) {
    $("#data-hint").textContent = `last import ${meta.last_ingest || "never"} · ${fmt(meta.kev_entries)} KEV entries · ${fmt(meta.poam_items)} POA&M items`;
    const scans = table([{ label: "Enclave" }, { label: "Period" }, { label: "Scan date" }, { label: "Source" }, { label: "Hosts", num: true }, { label: "Findings", num: true }],
      meta.scans.map((s) => [esc(s.enclave), periodLabel(s.period), s.scan_date, esc(s.source_file), fmt(s.host_count), fmt(s.finding_count)]), { empty: "no scans loaded" });
    const problems = meta.files.filter((f) => f.status !== "ok");
    const log = meta.log.map((l) => `<div class="${esc(l.level)}">${esc(l.at)} ${esc(l.level.toUpperCase())} ${esc(l.message)}</div>`).join("");
    $("#data-body").innerHTML = `<div class="grid cols-2" style="margin:0">
      <div><h3 style="font-size:13px;margin:0 0 6px">Scans in database (${meta.scans.length})</h3><div class="table-scroll" style="max-height:300px">${scans}</div></div>
      <div><h3 style="font-size:13px;margin:0 0 6px">Import messages${problems.length ? ` · <span style="color:var(--bad-ink)">${problems.length} file(s) skipped or failed</span>` : ""}</h3><div class="log">${log || "<div class='info'>nothing yet</div>"}</div>
        <div class="note">Health score = 100 × e^(−density / ${meta.health.scale}), density = (${Object.entries(meta.health.weights).map(([k, v]) => `${v}×${k}`).join(" + ")}) ÷ hosts. Grades: ${Object.entries(meta.health.grades).map(([g, c]) => `${g} ≥ ${c}`).join(", ")}, else F. Tune in config.json.</div></div></div>`;
  }

  // ---------------------------------------------------------------- modal
  async function openModal(title, params) {
    const modal = $("#modal"); $("#modal-title").textContent = title; $("#modal-search").value = "";
    modal.classList.add("open");
    const body = $("#modal-body");
    if (EMBED) { body.innerHTML = `<div class="empty">Per-host detail is available in the live dashboard (run.bat), not in this exported copy.</div>`; $("#modal-count").textContent = ""; return; }
    body.innerHTML = `<div class="empty">loading…</div>`;
    const q = new URLSearchParams({ period: state.period || "", enclave: params.enclave != null ? params.enclave : state.enclave || "", limit: 2000 });
    for (const k of ["plugin_id", "host_key", "severity", "q", "kev", "exploitable"]) if (params[k] != null) q.set(k, params[k]);
    try {
      const r = await fetch("/api/findings?" + q.toString(), { cache: "no-store" });
      const j = await r.json();
      if (j.error) throw new Error(j.error);
      state.modalRows = j.rows;
      renderModalRows();
    } catch (e) { body.innerHTML = `<div class="empty">failed: ${esc(e.message)}</div>`; }
  }
  function renderModalRows() {
    const needle = $("#modal-search").value.trim().toLowerCase();
    const rows = state.modalRows.filter((r) => !needle || [r.host_key, r.ip, r.plugin_name, r.cves, String(r.plugin_id), r.enclave].join(" ").toLowerCase().includes(needle));
    $("#modal-count").textContent = `${fmt(rows.length)}${state.modalRows.length >= 2000 ? "+ (first 2000)" : ""} finding${rows.length === 1 ? "" : "s"}`;
    $("#modal-body").innerHTML = table(
      [{ label: "Severity" }, { label: "Enclave" }, { label: "Host" }, { label: "Plugin", num: true }, { label: "Vulnerability", trunc: true, wide: true }, { label: "Port" }, { label: "CVSS3", num: true }, { label: "VPR", num: true }, { label: "Flags" }, { label: "Age", num: true }, { label: "First seen" }, { label: "POA&M" }],
      rows.map((r) => [sevBadge(r.severity_name), esc(r.enclave), `<b>${esc(r.host_key)}</b>${r.ip && r.ip !== r.host_key ? `<div class="dim" style="font-size:11px">${esc(r.ip)}</div>` : ""}`, r.plugin_id,
        `<span title="${esc(r.plugin_name)}\n\n${esc(r.solution)}">${esc(r.plugin_name)}</span>${r.cves ? `<div class="dim" style="font-size:11px">${esc(r.cves.split(",").slice(0, 4).join(", "))}</div>` : ""}`,
        r.port ? `${r.port}/${esc(r.protocol)}` : "–", r.cvss3 == null ? "–" : r.cvss3, r.vpr == null ? "–" : r.vpr,
        flags({ is_kev: r.is_kev, exploit: r.exploit_available, frameworks: r.exploit_frameworks }), r.age_days == null ? "–" : `${r.age_days} d`, r.first_date,
        r.poam ? r.poam.split(",").map((s) => `<span class="badge ${["Ongoing", "Delayed"].includes(s) ? "poam-open" : "poam-closed"}">${esc(s)}</span>`).join(" ") : `<span class="badge poam-none">none</span>`]),
      { empty: "no findings" });
  }

  // ---------------------------------------------------------------- wiring
  function applyTheme(t) {
    if (t) document.documentElement.setAttribute("data-theme", t); else document.documentElement.removeAttribute("data-theme");
    try { if (t) localStorage.setItem("theme", t); else localStorage.removeItem("theme"); } catch (e) { /* ignore */ }
  }
  function currentTheme() {
    const a = document.documentElement.getAttribute("data-theme");
    if (a) return a;
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function init() {
    try { const t = localStorage.getItem("theme"); if (t) applyTheme(t); } catch (e) { /* ignore */ }
    readHash();
    if (EMBED) { state.period = EMBED.period; $("#refresh").style.display = "none"; $("#export").style.display = "none"; $("#brief").style.display = "none"; }
    $("#period").addEventListener("change", (e) => { state.period = e.target.value; load(); });
    $("#enclave").addEventListener("change", (e) => { state.enclave = e.target.value; load(); });
    $("#theme").addEventListener("click", () => { applyTheme(currentTheme() === "dark" ? "light" : "dark"); if (state.data) render(state.data); });
    $("#toggle-data").addEventListener("click", () => { const p = $("#data-panel"); p.style.display = p.style.display === "none" ? "" : "none"; if (p.style.display === "") p.scrollIntoView({ behavior: "smooth" }); });
    $("#modal-close").addEventListener("click", () => $("#modal").classList.remove("open"));
    $("#modal").addEventListener("click", (e) => { if (e.target.id === "modal") $("#modal").classList.remove("open"); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("#modal").classList.remove("open"); });
    $("#modal-search").addEventListener("input", renderModalRows);
    $$(".table-toggle").forEach((b) => b.addEventListener("click", () => { const card = b.closest(".card"); card.classList.toggle("show-table"); b.textContent = card.classList.contains("show-table") ? "Chart" : "Table"; }));
    $("#refresh").addEventListener("click", async () => {
      const b = $("#refresh"); b.disabled = true; b.textContent = "Refreshing…";
      try {
        const r = await fetch("/api/refresh", { method: "POST" });
        const j = await r.json();
        if (j.error) throw new Error(j.error);
        const warn = j.messages.filter((m) => m.level !== "info").length;
        toast(`${j.changed} file(s) loaded${warn ? `, ${warn} warning(s): see Data panel` : ""}`);
        if (!j.changed) state.period = state.period; else state.period = null;
        await load();
      } catch (e) { toast("Refresh failed: " + e.message, 5000); }
      finally { b.disabled = false; b.textContent = "Refresh data"; }
    });
    window.addEventListener("hashchange", () => { readHash(); load(); });
    load();
  }
  init();
})();
