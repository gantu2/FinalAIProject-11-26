"""A small PDF writer using only the standard library (text, rectangles, lines, Helvetica)."""
import zlib

PAGE_W, PAGE_H = 612.0, 792.0  # US Letter, points

# Helvetica glyph widths (per 1000 em) for ASCII 32..126, from the standard AFM.
_HELV = [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556,
         556, 556, 556, 556, 278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667,
         556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556,
         556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722,
         500, 500, 500, 334, 260, 334, 584]
_HELV_B = [278, 333, 474, 556, 556, 889, 722, 238, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556,
           556, 556, 556, 556, 333, 333, 584, 584, 584, 611, 975, 722, 722, 722, 722, 667, 611, 778, 722, 278, 556, 722,
           611, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 333, 278, 333, 584, 556, 333, 556,
           611, 556, 611, 556, 333, 611, 611, 278, 278, 556, 278, 889, 611, 611, 611, 611, 389, 556, 333, 611, 556, 778,
           556, 556, 500, 389, 280, 389, 584]

_REPLACE = {"–": "-", "—": "-", "‘": "'", "’": "'", "“": '"', "”": '"', "•": "-",
            "…": "...", "×": "x", "−": "-", "≥": ">=", "≤": "<=", "·": "|", "▲": "+",
            "▼": "-", "Δ": "d"}


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def clean(text):
    out = []
    for ch in str(text if text is not None else ""):
        ch = _REPLACE.get(ch, ch)
        o = ord(ch)
        if 32 <= o <= 126 or 160 <= o <= 255:
            out.append(ch)
        elif o in (9, 10):
            out.append(" ")
        else:
            out.append("?")
    return "".join(out)


def text_width(text, size, bold=False):
    table = _HELV_B if bold else _HELV
    w = 0
    for ch in clean(text):
        o = ord(ch)
        w += table[o - 32] if 32 <= o <= 126 else 556
    return w * size / 1000.0


def truncate(text, size, max_w, bold=False):
    text = clean(text)
    if text_width(text, size, bold) <= max_w:
        return text
    ell = "..."
    while text and text_width(text + ell, size, bold) > max_w:
        text = text[:-1]
    return text.rstrip() + ell


def wrap(text, size, max_w, bold=False):
    words = clean(text).split()
    lines, cur = [], ""
    for w in words:
        cand = (cur + " " + w).strip()
        if text_width(cand, size, bold) <= max_w or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines or [""]


class Page:
    def __init__(self):
        self.ops = []

    def write(self, s):
        self.ops.append(s)


class PDF:
    """Coordinates passed to drawing methods use a top-left origin (y grows downward)."""

    def __init__(self, title="", author=""):
        self.pages = []
        self.title = title
        self.author = author
        self.page = None

    def new_page(self):
        self.page = Page()
        self.pages.append(self.page)
        return self.page

    # ---------------------------------------------------------------- shapes
    @staticmethod
    def _c(rgb):
        return "%.3f %.3f %.3f" % rgb

    def rect(self, x, y, w, h, fill=None, stroke=None, line_w=0.5):
        if fill is None and stroke is None:
            return
        ops = ["q"]
        if fill is not None:
            ops.append("%s rg" % self._c(fill))
        if stroke is not None:
            ops.append("%s RG %.2f w" % (self._c(stroke), line_w))
        ops.append("%.2f %.2f %.2f %.2f re" % (x, PAGE_H - y - h, w, h))
        ops.append("B" if fill is not None and stroke is not None else ("f" if fill is not None else "S"))
        ops.append("Q")
        self.page.write(" ".join(ops))

    def line(self, x1, y1, x2, y2, color=(0, 0, 0), line_w=0.5):
        self.page.write("q %s RG %.2f w %.2f %.2f m %.2f %.2f l S Q" % (
            self._c(color), line_w, x1, PAGE_H - y1, x2, PAGE_H - y2))

    def polyline(self, points, color=(0, 0, 0), line_w=1.5):
        if len(points) < 2:
            return
        ops = ["q %s RG %.2f w 1 J 1 j" % (self._c(color), line_w)]
        ops.append("%.2f %.2f m" % (points[0][0], PAGE_H - points[0][1]))
        for x, y in points[1:]:
            ops.append("%.2f %.2f l" % (x, PAGE_H - y))
        ops.append("S Q")
        self.page.write(" ".join(ops))

    def circle(self, cx, cy, r, fill):
        k = 0.5523 * r
        y = PAGE_H - cy
        ops = ["q %s rg" % self._c(fill), "%.2f %.2f m" % (cx + r, y)]
        for (x1, y1, x2, y2, x3, y3) in [(cx + r, y + k, cx + k, y + r, cx, y + r), (cx - k, y + r, cx - r, y + k, cx - r, y),
                                         (cx - r, y - k, cx - k, y - r, cx, y - r), (cx + k, y - r, cx + r, y - k, cx + r, y)]:
            ops.append("%.2f %.2f %.2f %.2f %.2f %.2f c" % (x1, y1, x2, y2, x3, y3))
        ops.append("f Q")
        self.page.write(" ".join(ops))

    # ------------------------------------------------------------------ text
    def text(self, x, y, s, size=9, bold=False, color=(0, 0, 0), align="left", max_w=None):
        """y is the baseline. align: left | right | center."""
        s = clean(s)
        if max_w is not None:
            s = truncate(s, size, max_w, bold)
        w = text_width(s, size, bold)
        if align == "right":
            x -= w
        elif align == "center":
            x -= w / 2.0
        esc = s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        self.page.write("BT /%s %.1f Tf %s rg %.2f %.2f Td (%s) Tj ET" % (
            "F2" if bold else "F1", size, self._c(color), x, PAGE_H - y, esc.encode("cp1252", "replace").decode("latin-1")))
        return w

    def paragraph(self, x, y, s, size=9, max_w=400, bold=False, color=(0, 0, 0), leading=None):
        leading = leading or size * 1.35
        for line in wrap(s, size, max_w, bold):
            self.text(x, y, line, size, bold, color)
            y += leading
        return y

    # ----------------------------------------------------------------- output
    def render(self):
        objs = []

        def add(body):
            objs.append(body)
            return len(objs)

        font1 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
        font2 = add(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
        pages_id = len(objs) + 1 + 2 * len(self.pages)  # reserve: content+page per page, then pages object
        page_ids = []
        for p in self.pages:
            stream = zlib.compress("\n".join(p.ops).encode("latin-1"))
            cid = add(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(stream) + stream + b"\nendstream")
            pid = add(("<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %d %d] /Contents %d 0 R "
                       "/Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> >>" % (
                           pages_id, PAGE_W, PAGE_H, cid, font1, font2)).encode("latin-1"))
            page_ids.append(pid)
        pages_obj = add(("<< /Type /Pages /Kids [%s] /Count %d >>" % (
            " ".join("%d 0 R" % i for i in page_ids), len(page_ids))).encode("latin-1"))
        assert pages_obj == pages_id
        catalog = add(("<< /Type /Catalog /Pages %d 0 R >>" % pages_obj).encode("latin-1"))
        info = add(("<< /Title (%s) /Author (%s) /Producer (nessus-dashboard) >>" % (
            clean(self.title).replace("(", "\\(").replace(")", "\\)"),
            clean(self.author).replace("(", "\\(").replace(")", "\\)"))).encode("cp1252", "replace"))
        out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = []
        for i, body in enumerate(objs, 1):
            offsets.append(len(out))
            out += b"%d 0 obj\n" % i + body + b"\nendobj\n"
        xref = len(out)
        out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
        for off in offsets:
            out += b"%010d 00000 n \n" % off
        out += b"trailer\n<< /Size %d /Root %d 0 R /Info %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (
            len(objs) + 1, catalog, info, xref)
        return bytes(out)
