"""Monthly leadership brief as a PDF, built from the same numbers as the dashboard."""
import datetime as dt

from .pdf import PDF, PAGE_W, PAGE_H, hex_rgb, text_width, wrap

M = 40.0                      # page margin
W = PAGE_W - 2 * M            # content width
INK = hex_rgb("#0b0b0b")
INK2 = hex_rgb("#52514e")
MUTED = hex_rgb("#898781")
GRID = hex_rgb("#e1e0d9")
PANEL = hex_rgb("#f4f4f1")
ACCENT = hex_rgb("#2a78d6")
GOOD = hex_rgb("#006300")
BAD = hex_rgb("#b22626")
SEV = ["Critical", "High", "Medium", "Low"]
SEV_TEXT = {"Critical": hex_rgb("#c62828"), "High": hex_rgb("#c9520f"), "Medium": hex_rgb("#8a6500"), "Low": hex_rgb("#1c5cab")}
SEV_RGB = {"Critical": hex_rgb("#c62828"), "High": hex_rgb("#ef6c2b"), "Medium": hex_rgb("#f2b705"), "Low": hex_rgb("#2a78d6")}
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def period_label(p, short=False):
    if not p:
        return "-"
    m = MONTHS[int(p[5:7]) - 1]
    return "%s '%s" % (m, p[2:4]) if short else "%s %s" % (m, p[:4])


def n(v):
    return "-" if v is None else "{:,}".format(int(v)) if float(v).is_integer() else "{:,.1f}".format(v)


def pct_change(cur, prev):
    if not prev:
        return None
    return 100.0 * (cur - prev) / prev


class Brief:
    def __init__(self, data, cfg):
        self.d = data
        self.cfg = cfg.get("brief", {})
        self.full_cfg = cfg
        sel = data["selection"]
        self.scope = sel["enclave"] or "All enclaves"
        self.period = sel["period"]
        self.title = self.cfg.get("title") or "Vulnerability Posture Brief"
        self.pdf = PDF(title="%s - %s" % (self.title, period_label(self.period)), author=self.cfg.get("organization", ""))
        self.y = 0

    # ------------------------------------------------------------ page flow
    def new_page(self):
        self.pdf.new_page()
        self.y = M + 26

    def need(self, h):
        if self.y + h > PAGE_H - M - 24:
            self.new_page()

    def heading(self, text, sub=None):
        self.need(40)
        self.y += 8
        self.pdf.text(M, self.y, text, 12, True, INK)
        if sub:
            self.pdf.text(M + text_width(text, 12, True) + 8, self.y, sub, 8, False, MUTED)
        self.y += 5
        self.pdf.line(M, self.y, M + W, self.y, GRID, 0.8)
        self.y += 12

    def note(self, text):
        self.need(14)
        self.y = self.pdf.paragraph(M, self.y, text, 7.5, W, False, MUTED) + 2

    def chrome(self):
        """Header and footer on every page, drawn last so the page count is known."""
        total = len(self.pdf.pages)
        marking = self.cfg.get("marking", "")
        org = self.cfg.get("organization", "")
        for i, page in enumerate(self.pdf.pages, 1):
            self.pdf.page = page
            if marking:
                self.pdf.text(PAGE_W / 2, 22, marking, 9, True, INK, "center")
                self.pdf.text(PAGE_W / 2, PAGE_H - 14, marking, 9, True, INK, "center")
            self.pdf.text(M, 38, "%s  |  %s  |  %s" % (self.title, self.scope, period_label(self.period)), 7.5, False, MUTED)
            if org:
                self.pdf.text(M + W, 38, org, 7.5, False, MUTED, "right")
            self.pdf.line(M, 43, M + W, 43, GRID, 0.6)
            self.pdf.text(M, PAGE_H - 28, "Source: Nessus scans through %s. Generated %s." % (
                self.d["selection"]["latest_scan_date"], dt.date.today().isoformat()), 7.5, False, MUTED)
            self.pdf.text(M + W, PAGE_H - 28, "Page %d of %d" % (i, total), 7.5, False, MUTED, "right")

    # --------------------------------------------------------------- pieces
    def table(self, cols, rows, size=8, row_h=15, empty="Nothing to report."):
        """cols: list of (label, width, align). Cells may be str or (str, rgb, bold)."""
        total_w = sum(c[1] for c in cols)
        scale = W / total_w
        cols = [(c[0], c[1] * scale, c[2] if len(c) > 2 else "left") for c in cols]

        def header():
            self.pdf.rect(M, self.y - 10, W, row_h, fill=PANEL)
            x = M
            for label, w, align in cols:
                tx = x + 4 if align == "left" else x + w - 4
                self.pdf.text(tx, self.y, label, size - 0.5, True, INK2, align, w - 8)
                x += w
            self.y += row_h

        self.need(row_h * 3)
        header()
        if not rows:
            self.pdf.text(M + 4, self.y, empty, size, False, MUTED)
            self.y += row_h
        for r in rows:
            if self.y + row_h > PAGE_H - M - 24:
                self.new_page()
                header()
            x = M
            for (label, w, align), cell in zip(cols, r):
                color, bold = INK, False
                if isinstance(cell, tuple):
                    cell, color, bold = cell[0], cell[1], (cell[2] if len(cell) > 2 else False)
                tx = x + 4 if align == "left" else x + w - 4
                self.pdf.text(tx, self.y, "-" if cell is None else cell, size, bold, color, align, w - 8)
                x += w
            self.pdf.line(M, self.y + 4.5, M + W, self.y + 4.5, GRID, 0.4)
            self.y += row_h
        self.y += 6

    def sev_cell(self, name):
        return (name, SEV_TEXT.get(name, INK), True)

    def delta_text(self, cur, prev, good_when="down", unit=""):
        if cur is None or prev is None:
            return ("no previous scan", MUTED)
        d = cur - prev
        if d == 0:
            return ("no change", MUTED)
        good = (d < 0) if good_when == "down" else (d > 0) if good_when == "up" else None
        color = MUTED if good is None else (GOOD if good else BAD)
        return ("%s%s%s vs previous" % ("+" if d > 0 else "", n(round(d, 1)), unit), color)

    # ----------------------------------------------------------------- pages
    def build(self):
        d = self.d
        self.new_page()
        self.cover_block()
        self.kpi_row()
        self.key_points()
        self.trend_charts()
        if len(d["enclaves"]) > 1:
            self.enclave_table()
        self.change_table()
        self.sla_table()
        self.top_vulns()
        self.kev_table()
        self.poam_section()
        self.method_note()
        self.chrome()
        return self.pdf.render()

    def cover_block(self):
        sel = self.d["selection"]
        self.pdf.text(M, self.y + 8, self.title, 20, True, INK)
        self.y += 26
        sub = "%s  |  %s  |  %d of %d enclaves scanned  |  scans through %s" % (
            period_label(self.period), self.scope, sel["enclaves_in_period"], sel["enclaves_total"], sel["latest_scan_date"])
        if sel["enclave"]:
            sub = "%s  |  %s  |  scanned %s" % (period_label(self.period), self.scope, sel["latest_scan_date"])
        self.pdf.text(M, self.y, sub, 9.5, False, INK2)
        self.y += 16

    def kpi_row(self):
        k, d = self.d["kpis"], self.d
        h = k["health"]
        tiles = [
            ("Health score", "%s  %s" % ("-" if h["score"] is None else n(h["score"]), h["grade"] or ""),
             self.delta_text(h["score"], h["prev_score"], "up", " pts")),
            ("Hosts scanned", n(k["hosts"]["value"]), self.delta_text(k["hosts"]["value"], k["hosts"]["prev"], "none")),
            ("Critical", n(k["severity"]["Critical"]["value"]),
             self.delta_text(k["severity"]["Critical"]["value"], k["severity"]["Critical"]["prev"])),
            ("High", n(k["severity"]["High"]["value"]),
             self.delta_text(k["severity"]["High"]["value"], k["severity"]["High"]["prev"])),
            ("Exploit available", n(k["exploitable"]["value"]),
             ("%s on CISA KEV" % n(k["kev"]["value"]), INK2) if d["meta"]["kev_entries"] else
             self.delta_text(k["exploitable"]["value"], k["exploitable"]["prev"])),
            ("Past SLA", n(k["sla_overdue"]["value"]), ("of %s open findings" % n(k["total"]["value"]), INK2)),
        ]
        gap = 6.0
        tw = (W - gap * (len(tiles) - 1)) / len(tiles)
        th = 58
        for i, (label, value, (sub, sub_color)) in enumerate(tiles):
            x = M + i * (tw + gap)
            self.pdf.rect(x, self.y, tw, th, fill=PANEL)
            accent = SEV_RGB.get(label)
            if accent:
                self.pdf.rect(x, self.y, 3, th, fill=accent)
            self.pdf.text(x + 8, self.y + 14, label, 7.5, False, INK2)
            self.pdf.text(x + 8, self.y + 36, value, 17, True, INK, max_w=tw - 12)
            self.pdf.text(x + 8, self.y + 50, sub, 7, False, sub_color, max_w=tw - 12)
        self.y += th + 14

    def key_points(self):
        d, k = self.d, self.d["kpis"]
        pts = []
        h = k["health"]
        if h["score"] is not None:
            if h["prev_score"] is None:
                pts.append("Health score is %s (grade %s). This is the first scan loaded, so there is no prior month to compare." % (n(h["score"]), h["grade"]))
            else:
                diff = round(h["score"] - h["prev_score"], 1)
                word = "improved" if diff > 0 else "declined" if diff < 0 else "held steady"
                pts.append("Health score %s%s to %s (grade %s, was %s)." % (
                    word, "" if diff == 0 else " by %s points" % n(abs(diff)), n(h["score"]), h["grade"], h["prev_grade"]))
        nf = d["new_fixed"]
        if any(not r.get("baseline") for r in nf["per_enclave"]):
            t = nf["totals"]
            pts.append("%s findings were fixed and %s new ones appeared since the previous scan; %s carried over." % (
                n(t["fixed"]), n(t["new"]), n(t["persistent"])))
        for name in ("Critical", "High"):
            s = k["severity"][name]
            pc = pct_change(s["value"], s["prev"])
            if pc is not None:
                pts.append("%s findings %s %s%% to %s (%s new, %s fixed)." % (
                    name, "rose" if pc > 0 else "fell" if pc < 0 else "were unchanged at", n(abs(round(pc))) if pc else "0",
                    n(s["value"]), n(nf["totals_sev"]["new"][name]), n(nf["totals_sev"]["fixed"][name])))
        if d["meta"]["kev_entries"] and k["kev"]["value"]:
            kv = d["sla"]["kev"]
            pts.append("%s findings match %s CVEs in the CISA Known Exploited Vulnerabilities catalog; %s are older than the %s-day window." % (
                n(k["kev"]["value"]), n(k["kev"]["cves"]), n(kv["overdue"]), kv["sla_days"]))
        crit = d["sla"]["by_severity"]["Critical"]
        if crit["total"]:
            pts.append("%s%% of open critical findings are inside the %s-day window; %s are overdue and the oldest is %s days old." % (
                n(crit["compliance"]), crit["sla_days"], n(crit["overdue"]), n(crit["oldest"])))
        scanned = [e for e in d["enclaves"] if e.get("scanned")]
        if len(scanned) > 1:
            worst = min(scanned, key=lambda e: e["health"] if e["health"] is not None else 999)
            best = max(scanned, key=lambda e: e["health"] if e["health"] is not None else -1)
            pts.append("Lowest-scoring enclave is %s (%s, grade %s); highest is %s (%s, grade %s)." % (
                worst["enclave"], n(worst["health"]), worst["grade"], best["enclave"], n(best["health"]), best["grade"]))
        missing = [e["enclave"] for e in d["enclaves"] if not e.get("scanned")]
        if missing:
            pts.append("No scan this month for: %s. Totals exclude them." % ", ".join(missing))
        p = d["poam"]
        if p["loaded"]:
            ch = p["coverage"]["Critical"]["not_on_poam"] + p["coverage"]["High"]["not_on_poam"]
            pts.append("POA&M: %s open items are past their scheduled completion date, and %s critical or high findings have no POA&M item." % (
                n(p["overdue_n"]), n(ch)))
            if p["closed_but_present"]:
                capped = len(p["closed_but_present"]) >= int(self.full_cfg.get("top_n", 15))
                pts.append("%s%s plugin%s marked closed on the POA&M %s still detected by the scanner." % (
                    "At least " if capped else "", n(len(p["closed_but_present"])), "" if len(p["closed_but_present"]) == 1 else "s",
                    "is" if len(p["closed_but_present"]) == 1 else "are"))
        cov = d["coverage"]
        if cov["dropped_total"]:
            pts.append("%s hosts seen last month were not scanned this month (%s new hosts appeared); their findings count as fixed until they are scanned again." % (
                n(cov["dropped_total"]), n(cov["added_total"])))
        self.heading("Key points")
        for pt in pts:
            lines = wrap(pt, 9.5, W - 14)
            self.need(len(lines) * 13 + 3)
            self.pdf.circle(M + 4, self.y - 3, 1.6, INK2)
            for ln in lines:
                self.pdf.text(M + 12, self.y, ln, 9.5, False, INK)
                self.y += 13
            self.y += 3

    def trend_charts(self):
        t = self.d["trend"][-13:]
        if not t:
            return
        self.heading("Trend", "last %d months" % len(t))
        ch = 150
        self.need(ch + 40)
        left_w = W * 0.60
        # ---- stacked bars
        x0, y0 = M + 34, self.y + 16
        pw, ph = left_w - 44, ch - 30
        self.pdf.text(M, self.y, "Open findings by severity", 8.5, True, INK2)
        lx = M + left_w - 10
        for name in reversed(SEV):
            w = text_width(name, 7)
            lx -= w
            self.pdf.text(lx, self.y, name, 7, False, INK2)
            lx -= 9
            self.pdf.rect(lx, self.y - 6, 6, 6, fill=SEV_RGB[name])
            lx -= 8
        top = max(sum(r[s] for s in SEV) for r in t) or 1
        step = self._nice_step(top)
        v = 0
        while v <= step * (int(top / step) + 1) + step * 0.01:
            yy = y0 + ph - ph * v / (step * (int(top / step) + 1))
            self.pdf.line(x0, yy, x0 + pw, yy, GRID, 0.4)
            self.pdf.text(x0 - 4, yy + 2.5, n(v), 6.5, False, MUTED, "right")
            v += step
        ymax = step * (int(top / step) + 1)
        slot = pw / len(t)
        bw = min(22, slot * 0.62)
        for i, r in enumerate(t):
            bx = x0 + slot * i + (slot - bw) / 2
            acc = 0
            for s in SEV:
                hgt = ph * r[s] / ymax
                if hgt > 0:
                    self.pdf.rect(bx, y0 + ph - acc - hgt, bw, max(hgt - 0.8, 0.3), fill=SEV_RGB[s])
                acc += hgt
            if len(t) <= 8 or i % 2 == (len(t) - 1) % 2:
                self.pdf.text(bx + bw / 2, y0 + ph + 10, period_label(r["period"], True), 6.5, False, MUTED, "center")
        self.pdf.line(x0, y0 + ph, x0 + pw, y0 + ph, MUTED, 0.6)
        # ---- health line
        hx0 = M + left_w + 30
        hpw = W - left_w - 40
        self.pdf.text(M + left_w + 6, self.y, "Health score (100 = no findings)", 8.5, True, INK2)
        for v in (0, 25, 50, 75, 100):
            yy = y0 + ph - ph * v / 100.0
            self.pdf.line(hx0, yy, hx0 + hpw, yy, GRID, 0.4)
            self.pdf.text(hx0 - 4, yy + 2.5, str(v), 6.5, False, MUTED, "right")
        pts = []
        for i, r in enumerate(t):
            if r["health"] is None:
                continue
            px = hx0 + (hpw * i / (len(t) - 1) if len(t) > 1 else hpw / 2)
            pts.append((px, y0 + ph - ph * r["health"] / 100.0, r))
        self.pdf.polyline([(p[0], p[1]) for p in pts], ACCENT, 1.6)
        for px, py, r in pts:
            self.pdf.circle(px, py, 2.0, ACCENT)
        if pts:
            px, py, r = pts[-1]
            self.pdf.text(px, py - 6, "%s (%s)" % (n(r["health"]), r["grade"]), 7.5, True, INK, "right")
            self.pdf.text(pts[0][0], y0 + ph + 10, period_label(pts[0][2]["period"], True), 6.5, False, MUTED, "left")
            self.pdf.text(px, y0 + ph + 10, period_label(r["period"], True), 6.5, False, MUTED, "right")
        self.pdf.line(hx0, y0 + ph, hx0 + hpw, y0 + ph, MUTED, 0.6)
        self.y += ch + 16

    @staticmethod
    def _nice_step(top):
        import math
        raw = top / 4.0
        mag = 10 ** math.floor(math.log10(raw)) if raw > 0 else 1
        for m in (1, 2, 2.5, 5, 10):
            if raw <= m * mag:
                return m * mag
        return 10 * mag

    def enclave_table(self):
        self.heading("Enclaves", period_label(self.period))
        rows = []
        for e in self.d["enclaves"]:
            if not e.get("scanned"):
                rows.append([(e["enclave"], INK, True), ("no scan this period", MUTED), None, None, None, None, None, None, None, None, None])
                continue
            dh = None if e["prev_health"] is None else round(e["health"] - e["prev_health"], 1)
            rows.append([(e["enclave"], INK, True), e["scan_date"], n(e["hosts"]), n(e["Critical"]), n(e["High"]), n(e["Medium"]), n(e["Low"]),
                         n(e["exploitable"]), n(e["kev"]), "%s  %s" % (n(e["health"]), e["grade"]),
                         ("-" if dh is None else "%s%s" % ("+" if dh > 0 else "", n(dh)), MUTED if not dh else GOOD if dh > 0 else BAD, True)])
        self.table([("Enclave", 100), ("Scan date", 62), ("Hosts", 40, "right"), ("Critical", 46, "right"), ("High", 40, "right"),
                    ("Medium", 46, "right"), ("Low", 40, "right"), ("Exploit", 44, "right"), ("KEV", 34, "right"),
                    ("Health", 56, "right"), ("Change", 46, "right")], rows)

    def change_table(self):
        nf = self.d["new_fixed"]
        self.heading("Change since previous scan")
        rows = []
        for r in nf["per_enclave"]:
            rows.append([(r["enclave"], INK, True), "first scan" if r.get("baseline") else period_label(r.get("prev_period")),
                         n(r["new"]), "%s / %s" % (n(r["new_sev"]["Critical"]), n(r["new_sev"]["High"])),
                         n(r["fixed"]), "%s / %s" % (n(r["fixed_sev"]["Critical"]), n(r["fixed_sev"]["High"])), n(r["persistent"]),
                         (("%s%s" % ("+" if r["new"] - r["fixed"] > 0 else "", n(r["new"] - r["fixed"]))),
                          BAD if r["new"] - r["fixed"] > 0 else GOOD if r["new"] - r["fixed"] < 0 else MUTED, True)])
        self.table([("Enclave", 110), ("Compared to", 70), ("New", 46, "right"), ("New crit / high", 74, "right"), ("Fixed", 46, "right"),
                    ("Fixed crit / high", 78, "right"), ("Persistent", 60, "right"), ("Net", 46, "right")], rows)
        if nf["fixed_avg_days_open"] is not None:
            self.note("Findings fixed this period had been open %s days on average. Fixed means the same host, plugin and port no longer appear in the scan." % n(nf["fixed_avg_days_open"]))

    def sla_table(self):
        s, m = self.d["sla"]["by_severity"], self.d["mttr"]
        self.heading("Remediation timeliness")
        rows = []
        for name in SEV:
            st = s[name]
            comp = st["compliance"]
            rows.append([self.sev_cell(name), "%s days" % st["sla_days"], n(st["total"]), n(st["within"]),
                         (n(st["overdue"]), BAD if st["overdue"] else INK, bool(st["overdue"])),
                         ("-" if comp is None else "%s%%" % n(comp), MUTED if comp is None else GOOD if comp >= 90 else BAD if comp < 70 else INK, True),
                         "-" if st["avg_age"] is None else "%s d" % n(st["avg_age"]), "%s d" % n(st["oldest"]) if st["total"] else "-",
                         "-" if m[name]["mean_days"] is None else "%s d" % n(m[name]["mean_days"])])
        kv = self.d["sla"]["kev"]
        if self.d["meta"]["kev_entries"] and kv["total"]:
            comp = round(100.0 * (kv["total"] - kv["overdue"]) / kv["total"], 1)
            rows.append([("KEV", SEV_RGB["Critical"], True), "%s days" % kv["sla_days"], n(kv["total"]), n(kv["total"] - kv["overdue"]),
                         (n(kv["overdue"]), BAD if kv["overdue"] else INK, bool(kv["overdue"])),
                         ("%s%%" % n(comp), GOOD if comp >= 90 else BAD if comp < 70 else INK, True), None, None, None])
        self.table([("Severity", 70), ("Window", 56), ("Open", 50, "right"), ("Within", 50, "right"), ("Overdue", 54, "right"),
                    ("In window", 60, "right"), ("Avg age", 54, "right"), ("Oldest", 50, "right"), ("Mean time to fix", 82, "right")], rows)
        self.note("Age is counted from first detection in the loaded scan history. Mean time to fix covers every finding closed in that history.")

    def top_vulns(self):
        rows = []
        for r in self.d["top_vulns"][:10]:
            flags = " ".join(f for f, on in (("KEV", r["is_kev"]), ("Exploit", r["exploit"])) if on) or "-"
            ps = r["poam_status"]
            rows.append([self.sev_cell(r["severity_name"]), str(r["plugin_id"]), r["name"], n(r["hosts"]), n(r["enclaves"]),
                         (flags, BAD if r["is_kev"] else INK2), r["first_seen"],
                         (ps["status"], INK2) if ps else ("none", BAD if r["severity"] >= 3 and self.d["poam"]["loaded"] else MUTED)])
        self.heading("Top vulnerabilities", "ranked by severity weight x hosts affected")
        self.table([("Severity", 50), ("Plugin", 44), ("Vulnerability", 210), ("Hosts", 36, "right"), ("Encl.", 32, "right"),
                    ("Flags", 62), ("First seen", 58), ("POA&M", 64)], rows, empty="No open findings in this scope.")

    def kev_table(self):
        if not self.d["meta"]["kev_entries"]:
            return
        rows = []
        for r in self.d["kev_items"][:10]:
            rows.append([(r["cve"], INK, True), r["name"], self.sev_cell(r["severity_name"]), n(r["hosts"]),
                         ("%s%s" % (r["due_date"] or "-", "  PAST DUE" if r["past_due"] else ""), BAD if r["past_due"] else INK, r["past_due"]),
                         r["first_seen"], ("yes", INK2) if r["on_poam"] else ("no", BAD)])
        self.heading("Known exploited vulnerabilities (CISA KEV)", "top %d by hosts affected" % len(rows) if rows else None)
        self.table([("CVE", 84), ("Vulnerability", 190), ("Severity", 50), ("Hosts", 36, "right"), ("CISA due date", 100),
                    ("First seen", 58), ("POA&M", 40)], rows, empty="No open findings match the KEV catalog.")

    def poam_section(self):
        p = self.d["poam"]
        if not p["loaded"]:
            return
        self.heading("POA&M")
        sc = p["status_counts"]
        line = "  |  ".join("%s %s" % (k, n(v)) for k, v in sorted(sc.items(), key=lambda kv: -kv[1]))
        self.need(30)
        self.pdf.text(M, self.y, "Items by status:  " + line, 9, False, INK, max_w=W)
        self.y += 13
        self.pdf.text(M, self.y, "Past scheduled completion: %s   |   Due in next 30 days: %s   |   Open with no date: %s" % (
            n(p["overdue_n"]), n(p["due_30_n"]), n(p["no_date_n"])), 9, False, INK, max_w=W)
        self.y += 16
        c = p["coverage"]
        rows = []
        for name in SEV:
            tot = c[name]["open"] + c[name]["closed"] + c[name]["not_on_poam"]
            tracked = None if not tot else round(100.0 * (c[name]["open"] + c[name]["closed"]) / tot)
            rows.append([self.sev_cell(name), n(tot), n(c[name]["open"]), n(c[name]["closed"]),
                         (n(c[name]["not_on_poam"]), BAD if c[name]["not_on_poam"] and name in ("Critical", "High") else INK, False),
                         "-" if tracked is None else "%d%%" % tracked])
        self.table([("Severity", 80), ("Open findings", 80, "right"), ("On POA&M (open item)", 110, "right"),
                    ("On POA&M (closed item)", 116, "right"), ("Not on POA&M", 80, "right"), ("Tracked", 60, "right")], rows)
        today = dt.date.today()
        if p["overdue_items"]:
            self.need(70)
            self.pdf.text(M, self.y, "Overdue POA&M items (oldest first)", 9, True, INK2)
            self.y += 12
            rows = []
            for r in p["overdue_items"][:10]:
                days = (today - dt.date.fromisoformat(r["scheduled"])).days
                rows.append([(r["item_id"], INK, True), r["description"], r["severity"] or "-", r["scheduled"], ("%s d" % n(days), BAD, True),
                             n(r["hosts_affected"]) if r["plugin_ids"] else "-", r["office"] or "-"])
            self.table([("Item", 54), ("Description", 210), ("Severity", 56), ("Scheduled", 60), ("Overdue", 48, "right"),
                        ("Hosts", 40, "right"), ("Office", 64)], rows)
            if p["overdue_n"] > len(rows):
                self.note("Showing %d of %s overdue items." % (len(rows), n(p["overdue_n"])))
        if p["unmatched_top"]:
            self.need(70)
            self.pdf.text(M, self.y, "Critical and high findings with no POA&M item", 9, True, INK2)
            self.y += 12
            self.table([("Severity", 60), ("Plugin", 54), ("Vulnerability", 340), ("Hosts", 50, "right")],
                       [[self.sev_cell(r["severity_name"]), str(r["plugin_id"]), r["name"], n(r["hosts"])] for r in p["unmatched_top"][:10]])
        if p["closed_but_present"]:
            self.need(70)
            self.pdf.text(M, self.y, "Closed on the POA&M but still detected", 9, True, INK2)
            self.y += 12
            self.table([("Severity", 60), ("Plugin", 54), ("Vulnerability", 260), ("Hosts", 50, "right"), ("POA&M status", 100)],
                       [[self.sev_cell(r["severity_name"]), str(r["plugin_id"]), r["name"], n(r["hosts"]), ", ".join(r["statuses"])]
                        for r in p["closed_but_present"][:10]])

    def method_note(self):
        meta = self.d["meta"]
        hw = meta["health"]
        sd = meta["sla_days"]
        self.need(60)
        self.y += 4
        self.pdf.line(M, self.y, M + W, self.y, GRID, 0.6)
        self.y += 12
        self.note("How to read this brief. Health score = 100 x e^(-density / %s), where density = (%s) / hosts scanned; grades: %s, else F. "
                  "Remediation windows: Critical %s d, High %s d, Medium %s d, Low %s d, KEV %s d. A finding is the same finding when host, plugin, "
                  "port and protocol match between scans. All figures come from credentialed Nessus scan exports loaded into the dashboard." % (
                      n(hw["scale"]), " + ".join("%s x %s" % (n(v), k) for k, v in hw["weights"].items()),
                      ", ".join("%s >= %s" % (g, c) for g, c in sorted(hw["grades"].items(), key=lambda kv: -kv[1])),
                      sd["Critical"], sd["High"], sd["Medium"], sd["Low"], sd["KEV"]))


def build_brief_pdf(metrics, cfg, period=None, enclave=None):
    data = metrics.dashboard(period, enclave)
    if data.get("empty"):
        raise RuntimeError("no scans loaded")
    return Brief(data, cfg).build(), data["selection"]


def brief_filename(selection):
    scope = (selection["enclave"] or "all-enclaves").replace(" ", "-")
    return "vulnerability-brief-%s-%s.pdf" % (selection["period"], scope)
