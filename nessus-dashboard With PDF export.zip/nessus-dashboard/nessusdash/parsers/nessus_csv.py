"""Parser for Nessus / Tenable CSV exports and the same layout inside .xlsx.

Column names are matched case-insensitively against the aliases below, so a
Nessus Professional CSV, a Tenable.sc CSV and a hand-built combined workbook
all load as long as the headers are recognisable.
"""
import csv
import os

from .common import (ParsedScan, SEVERITY_FROM_RISK, choose_host_key,
                     date_from_filename, extract_cves, parse_date, to_float, to_int)
from .xlsx import excel_serial_to_date, read_workbook

ALIASES = {
    "plugin_id": ["plugin id", "plugin", "pluginid", "plugin_id", "id"],
    "plugin_name": ["name", "plugin name", "plugin_name", "pluginname", "title"],
    "family": ["family", "plugin family"],
    "risk": ["risk", "severity", "risk factor", "risk_factor"],
    "host": ["host", "ip address", "ip", "host ip", "asset", "hostname", "host name"],
    "fqdn": ["dns name", "fqdn", "host fqdn", "host-fqdn"],
    "netbios": ["netbios name", "netbios"],
    "os": ["operating system", "os", "host os"],
    "protocol": ["protocol"],
    "port": ["port"],
    "cvss2": ["cvss v2.0 base score", "cvss base score", "cvss v2 base score", "cvss2"],
    "cvss3": ["cvss v3.0 base score", "cvss3 base score", "cvss v3 base score", "cvss3"],
    "vpr": ["vpr score", "vpr"],
    "cve": ["cve", "cves"],
    "xref": ["xref", "cross references"],
    "exploit": ["exploit?", "exploit available", "exploit_available", "exploitable"],
    "metasploit": ["metasploit", "exploit framework metasploit"],
    "core": ["core impact", "exploit framework core"],
    "canvas": ["canvas", "exploit framework canvas"],
    "frameworks": ["exploit frameworks", "exploit framework"],
    "malware": ["exploited by malware", "exploited_by_malware"],
    "pub_date": ["plugin publication date", "plugin pub date", "publication date"],
    "solution": ["solution"],
    "stig": ["stig severity"],
    "enclave": ["enclave", "site", "network", "location", "environment", "system"],
    "scan_date": ["scan date", "scan start", "last observed", "last seen", "host start"],
}

_TRUE = {"true", "yes", "1", "y"}


def _header_map(header):
    norm = [str(h or "").strip().lower() for h in header]
    out = {}
    for field, names in ALIASES.items():
        for n in names:
            if n in norm:
                out[field] = norm.index(n)
                break
    return out


def looks_like_findings(header):
    hm = _header_map(header)
    return "plugin_id" in hm and "host" in hm and "risk" in hm


def _get(row, hm, field, default=""):
    i = hm.get(field)
    if i is None or i >= len(row):
        return default
    v = row[i]
    return default if v is None else v


def rows_to_scan(rows, source, host_key_priority, enclave_filter=None):
    """Build a ParsedScan from a list of rows (first row = header)."""
    scan = ParsedScan(source)
    if not rows:
        scan.warnings.append("empty file")
        return scan
    header_idx = 0
    for i, row in enumerate(rows[:30]):
        if looks_like_findings(row):
            header_idx = i
            break
    else:
        scan.warnings.append("no recognisable Nessus header row (need Plugin ID, Host, Risk)")
        return scan
    hm = _header_map(rows[header_idx])
    earliest = None
    for row in rows[header_idx + 1:]:
        if not any(str(c).strip() for c in row if c is not None):
            continue
        if enclave_filter is not None and "enclave" in hm:
            if str(_get(row, hm, "enclave")).strip() != enclave_filter:
                continue
        host = str(_get(row, hm, "host")).strip()
        if not host:
            continue
        fqdn = str(_get(row, hm, "fqdn")).strip()
        netbios = str(_get(row, hm, "netbios")).strip()
        props = {"name": host, "host-ip": host if host[:1].isdigit() else "",
                 "host-fqdn": fqdn or (host if not host[:1].isdigit() else ""),
                 "netbios-name": netbios}
        host_key = choose_host_key(props, host_key_priority)
        scan.add_host(host_key, ip=props["host-ip"], fqdn=props["host-fqdn"], netbios=netbios,
                      os_name=str(_get(row, hm, "os")))
        sd = _get(row, hm, "scan_date")
        d = excel_serial_to_date(sd) if isinstance(sd, (int, float)) else parse_date(sd)
        if d and (earliest is None or d < earliest):
            earliest = d
        risk = str(_get(row, hm, "risk")).strip()
        sev = SEVERITY_FROM_RISK.get(risk.lower())
        if sev is None:
            sev = to_int(risk, 0) if risk.isdigit() else 0
        frameworks = [label for field, label in (("metasploit", "Metasploit"), ("core", "Core Impact"),
                                                 ("canvas", "CANVAS"))
                      if str(_get(row, hm, field)).strip().lower() in _TRUE]
        fw_text = str(_get(row, hm, "frameworks")).strip()
        if fw_text and fw_text.lower() not in ("no", "none", "false", "0"):
            frameworks = sorted(set(frameworks) | {x.strip() for x in fw_text.replace(";", ",").split(",") if x.strip()})
        cves = extract_cves(_get(row, hm, "cve")) or extract_cves(_get(row, hm, "xref"))
        pd_raw = _get(row, hm, "pub_date")
        pub = excel_serial_to_date(pd_raw) if isinstance(pd_raw, (int, float)) else parse_date(pd_raw)
        scan.add_finding(
            host_key=host_key,
            plugin_id=to_int(_get(row, hm, "plugin_id")),
            plugin_name=str(_get(row, hm, "plugin_name"))[:255],
            family=str(_get(row, hm, "family"))[:80],
            severity=sev,
            port=to_int(_get(row, hm, "port")),
            protocol=str(_get(row, hm, "protocol")).strip().lower(),
            cvss2=to_float(_get(row, hm, "cvss2")),
            cvss3=to_float(_get(row, hm, "cvss3")),
            vpr=to_float(_get(row, hm, "vpr")),
            cves=cves,
            exploit_available=str(_get(row, hm, "exploit")).strip().lower() in _TRUE or bool(frameworks),
            exploit_frameworks=", ".join(frameworks),
            exploited_by_malware=str(_get(row, hm, "malware")).strip().lower() in _TRUE,
            plugin_pub_date=pub,
            solution=str(_get(row, hm, "solution")),
            stig_severity=str(_get(row, hm, "stig")).strip(),
        )
    scan.scan_date = earliest or date_from_filename(source)
    if earliest is None:
        scan.warnings.append("" if scan.scan_date
                             else "no scan date found in file or filename")
    return scan


def parse_csv(path, host_key_priority):
    with open(path, "r", newline="", encoding="utf-8-sig", errors="replace") as fh:
        rows = list(csv.reader(fh))
    return rows_to_scan(rows, os.path.basename(path), host_key_priority)


def csv_enclave_values(path):
    """Distinct values of an Enclave/Site column in a CSV, if present."""
    with open(path, "r", newline="", encoding="utf-8-sig", errors="replace") as fh:
        rows = list(csv.reader(fh))
    return _enclave_values(rows)


def _enclave_values(rows):
    for i, row in enumerate(rows[:30]):
        if looks_like_findings(row):
            hm = _header_map(row)
            if "enclave" not in hm:
                return None
            vals = sorted({str(_get(r, hm, "enclave")).strip() for r in rows[i + 1:]
                           if str(_get(r, hm, "enclave")).strip()})
            return vals
    return None


def parse_csv_multi(path, host_key_priority):
    """Yield (enclave_or_None, ParsedScan) for a CSV, splitting on an Enclave column if present."""
    with open(path, "r", newline="", encoding="utf-8-sig", errors="replace") as fh:
        rows = list(csv.reader(fh))
    vals = _enclave_values(rows)
    if vals:
        for v in vals:
            yield v, rows_to_scan(rows, os.path.basename(path), host_key_priority, enclave_filter=v)
    else:
        yield None, rows_to_scan(rows, os.path.basename(path), host_key_priority)


def parse_xlsx_multi(path, host_key_priority):
    """Yield (enclave_or_None, ParsedScan) per sheet of a workbook.

    Sheet names become enclave names unless the sheet has an Enclave column, in
    which case the rows are split by that column instead.
    """
    book = read_workbook(path)
    for sheet, rows in book.items():
        if not any(looks_like_findings(r) for r in rows[:30]):
            continue
        vals = _enclave_values(rows)
        if vals:
            for v in vals:
                yield v, rows_to_scan(rows, "%s [%s]" % (os.path.basename(path), sheet),
                                      host_key_priority, enclave_filter=v)
        else:
            generic = sheet.strip().lower().startswith("sheet") or sheet.strip().lower() in ("data", "findings", "vulnerabilities")
            yield (None if generic else sheet.strip()), rows_to_scan(
                rows, "%s [%s]" % (os.path.basename(path), sheet), host_key_priority)
