"""Parser for Nessus v2 .nessus XML exports (streaming, low memory)."""
import os
import xml.etree.ElementTree as ET

from .common import (ParsedScan, SEVERITY_FROM_RISK, choose_host_key,
                     date_from_filename, extract_cves, parse_date, to_float, to_int)

_TRUE = {"true", "yes", "1"}


def parse_nessus(path, host_key_priority):
    scan = ParsedScan(os.path.basename(path))
    earliest = None
    with open(path, "rb") as fh:
        for _ev, el in ET.iterparse(fh, events=("end",)):
            if el.tag != "ReportHost":
                continue
            props = {"name": el.get("name", "")}
            hp = el.find("HostProperties")
            if hp is not None:
                for tag in hp.findall("tag"):
                    props[tag.get("name", "")] = (tag.text or "").strip()
            for key in ("HOST_START", "HOST_END"):
                d = parse_date(props.get(key))
                if d and (earliest is None or d < earliest):
                    earliest = d
            host_key = choose_host_key(props, host_key_priority)
            scan.add_host(host_key, ip=props.get("host-ip", ""), fqdn=props.get("host-fqdn", ""),
                          netbios=props.get("netbios-name", ""), os_name=props.get("operating-system", ""))
            for item in el.findall("ReportItem"):
                _add_item(scan, host_key, item)
            el.clear()
    scan.scan_date = earliest or date_from_filename(os.path.basename(path))
    if earliest is None:
        scan.warnings.append("" if scan.scan_date
                             else "no scan date found in file or filename")
    return scan


def _text(item, tag):
    el = item.find(tag)
    return (el.text or "").strip() if el is not None and el.text else ""


def _add_item(scan, host_key, item):
    sev = to_int(item.get("severity"), -1)
    risk = _text(item, "risk_factor")
    if sev < 0:
        sev = SEVERITY_FROM_RISK.get(risk.lower(), 0)
    frameworks = []
    for tag, label in (("exploit_framework_metasploit", "Metasploit"),
                       ("exploit_framework_core", "Core Impact"),
                       ("exploit_framework_canvas", "CANVAS")):
        if _text(item, tag).lower() in _TRUE:
            frameworks.append(label)
    cves = [c.text.strip().upper() for c in item.findall("cve") if c.text]
    if not cves:
        cves = extract_cves(_text(item, "xref"))
    scan.add_finding(
        host_key=host_key,
        plugin_id=to_int(item.get("pluginID")),
        plugin_name=item.get("pluginName", "")[:255],
        family=item.get("pluginFamily", "")[:80],
        severity=sev,
        port=to_int(item.get("port")),
        protocol=(item.get("protocol") or "").lower(),
        cvss2=to_float(_text(item, "cvss_base_score")),
        cvss3=to_float(_text(item, "cvss3_base_score")),
        vpr=to_float(_text(item, "vpr_score")),
        cves=cves,
        exploit_available=_text(item, "exploit_available").lower() in _TRUE or bool(frameworks),
        exploit_frameworks=", ".join(frameworks),
        exploited_by_malware=_text(item, "exploited_by_malware").lower() in _TRUE,
        plugin_pub_date=(parse_date(_text(item, "plugin_publication_date")) or None),
        solution=_text(item, "solution"),
        stig_severity=_text(item, "stig_severity"),
    )
