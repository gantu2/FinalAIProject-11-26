"""Parser for POA&M workbooks (eMASS export layout or a plain table).

The eMASS POA&M export has a block of system metadata above the real header
row, so the header row is located by searching for a known column title.
"""
import os
import re
import csv

from .common import extract_cves, parse_date
from .xlsx import excel_serial_to_date, read_workbook

DEFAULT_COLUMNS = {
    "item_id": ["poa&m item id", "poam item id", "poa&m id", "poam id", "item id", "id"],
    "description": ["control vulnerability description", "weakness description", "description",
                    "weakness", "vulnerability description"],
    "checks": ["security checks", "security check", "plugin id", "plugin ids", "plugins",
               "vulnerability id", "vuln id", "nessus plugin"],
    "source": ["source identifying vulnerability", "source identifying control vulnerability",
               "source", "source of discovery"],
    "status": ["status", "poa&m status"],
    "scheduled": ["scheduled completion date", "scheduled completion", "due date",
                  "estimated completion date", "target date"],
    "severity": ["raw severity", "severity", "risk"],
    "devices": ["devices affected", "assets affected", "affected assets", "hosts"],
    "office": ["office/org", "office org", "point of contact", "poc", "owner"],
    "milestones": ["milestone with completion dates", "milestones", "milestone"],
    "comments": ["comments", "notes"],
    "control": ["security control number (nc/na/cp only)", "security control number", "control"],
}

STATUS_MAP = {
    "ongoing": "Ongoing", "open": "Ongoing", "in progress": "Ongoing", "active": "Ongoing",
    "delayed": "Delayed", "overdue": "Delayed",
    "completed": "Completed", "complete": "Completed", "closed": "Completed", "remediated": "Completed",
    "risk accepted": "Risk Accepted", "risk acceptance": "Risk Accepted", "accepted": "Risk Accepted",
    "not applicable": "Not Applicable", "n/a": "Not Applicable", "na": "Not Applicable",
    "false positive": "Not Applicable",
}

_PLUGIN_CTX_RE = re.compile(r"plugin\s*(?:id)?\s*[#:]?\s*(\d{4,7})", re.I)
_NUM_RE = re.compile(r"(?<![\d.-])(\d{5,7})(?![\d.-])")


def _norm(s):
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def _find_header(rows, columns):
    id_names = set(columns["item_id"]) | set(columns["description"]) | set(columns["checks"])
    for i, row in enumerate(rows[:40]):
        cells = {_norm(c) for c in row}
        hits = len(cells & id_names)
        if hits >= 1 and len(cells & (set(columns["status"]) | set(columns["scheduled"]))) >= 1:
            return i
    return None


def _col_map(header, columns):
    norm = [_norm(h) for h in header]
    out = {}
    for field, names in columns.items():
        for n in names:
            if n in norm:
                out[field] = norm.index(n)
                break
    return out


def _get(row, cm, field):
    i = cm.get(field)
    if i is None or i >= len(row) or row[i] is None:
        return ""
    return row[i]


def _plugin_ids(checks, source, description):
    ids = []
    for tok in _NUM_RE.findall(str(checks or "")):
        ids.append(int(tok))
    for text in (source, description, checks):
        for tok in _PLUGIN_CTX_RE.findall(str(text or "")):
            ids.append(int(tok))
    seen, out = set(), []
    for i in ids:
        if i not in seen:
            seen.add(i)
            out.append(i)
    return out


def _date(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return excel_serial_to_date(v)
    return parse_date(v)


def parse_poam_rows(rows, source, column_config=None):
    columns = dict(DEFAULT_COLUMNS)
    for k, v in (column_config or {}).items():
        if isinstance(v, str):
            v = [v]
        columns[k] = [_norm(x) for x in v] + columns.get(k, [])
    items, warnings = [], []
    hi = _find_header(rows, columns)
    if hi is None:
        return items, ["%s: no POA&M header row found (need an ID/description column plus Status or Scheduled Completion Date)" % source]
    cm = _col_map(rows[hi], columns)
    for row in rows[hi + 1:]:
        if not any(str(c).strip() for c in row if c is not None):
            continue
        item_id = str(_get(row, cm, "item_id")).strip()
        desc = str(_get(row, cm, "description")).strip()
        checks = _get(row, cm, "checks")
        src = _get(row, cm, "source")
        if not (item_id or desc):
            continue
        raw_status = str(_get(row, cm, "status")).strip()
        status = STATUS_MAP.get(_norm(raw_status), raw_status.title() if raw_status else "Ongoing")
        plugin_ids = _plugin_ids(checks, src, desc)
        cves = extract_cves(" ".join(str(x) for x in (checks, src, desc)))
        sched = _date(_get(row, cm, "scheduled"))
        items.append({
            "item_id": item_id or ("row-%d" % (len(items) + 1)),
            "description": desc[:500],
            "plugin_ids": plugin_ids,
            "cves": cves,
            "status": status,
            "raw_status": raw_status,
            "scheduled": sched.isoformat() if sched else None,
            "severity": str(_get(row, cm, "severity")).strip()[:20],
            "devices": str(_get(row, cm, "devices")).strip()[:300],
            "office": str(_get(row, cm, "office")).strip()[:120],
            "control": str(_get(row, cm, "control")).strip()[:60],
            "milestones": str(_get(row, cm, "milestones")).strip()[:300],
            "source_file": source,
        })
    if items and not any(i["plugin_ids"] or i["cves"] for i in items):
        warnings.append("%s: no plugin IDs or CVEs found in any POA&M row; items cannot be matched to findings" % source)
    return items, warnings


def parse_poam_file(path, column_config=None):
    name = os.path.basename(path)
    ext = os.path.splitext(name)[1].lower()
    all_items, all_warnings = [], []
    if ext in (".xlsx", ".xlsm"):
        book = read_workbook(path)
        for sheet, rows in book.items():
            items, warnings = parse_poam_rows(rows, "%s [%s]" % (name, sheet), column_config)
            if items:
                all_items.extend(items)
            elif len(book) == 1:
                all_warnings.extend(warnings)
        if not all_items and len(book) > 1:
            all_warnings.append("%s: no sheet contained a recognisable POA&M table" % name)
    elif ext == ".csv":
        with open(path, "r", newline="", encoding="utf-8-sig", errors="replace") as fh:
            rows = list(csv.reader(fh))
        items, warnings = parse_poam_rows(rows, name, column_config)
        all_items.extend(items)
        all_warnings.extend(warnings)
    return all_items, all_warnings
