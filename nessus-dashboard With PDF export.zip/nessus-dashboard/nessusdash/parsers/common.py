"""Shared record shapes and helpers for all scan parsers."""
import datetime as dt
import re

SEVERITY_NAMES = {0: "Info", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}
SEVERITY_FROM_RISK = {
    "none": 0, "info": 0, "informational": 0, "": 0,
    "low": 1, "medium": 2, "high": 3, "critical": 4,
}

# Filename date patterns, most specific first.
_FNAME_DATE_PATTERNS = [
    (re.compile(r"(20\d{2})[-_.]?(\d{2})[-_.]?(\d{2})"), "ymd"),
    (re.compile(r"(\d{2})[-_.](\d{2})[-_.](20\d{2})"), "mdy"),
    (re.compile(r"(20\d{2})[-_.]?(\d{2})(?!\d)"), "ym"),
    (re.compile(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[-_ .]?(20\d{2})", re.I), "mony"),
]
_MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}


def date_from_filename(name):
    """Best-effort date from a filename. Returns datetime.date or None."""
    for rx, kind in _FNAME_DATE_PATTERNS:
        m = rx.search(name)
        if not m:
            continue
        try:
            if kind == "ymd":
                return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            if kind == "mdy":
                return dt.date(int(m.group(3)), int(m.group(1)), int(m.group(2)))
            if kind == "ym":
                return dt.date(int(m.group(1)), int(m.group(2)), 1)
            if kind == "mony":
                return dt.date(int(m.group(2)), _MONTHS[m.group(1)[:3].lower()], 1)
        except ValueError:
            continue
    return None


_DATE_FORMATS = [
    "%a %b %d %H:%M:%S %Y",   # Nessus HOST_START: Tue Oct  7 09:12:33 2025
    "%Y/%m/%d", "%Y-%m-%d", "%m/%d/%Y", "%d-%b-%Y", "%b %d, %Y",
    "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%m/%d/%y",
]


def parse_date(value):
    """Parse the date formats seen in Nessus / Tenable / eMASS exports."""
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    s = str(value).strip()
    if not s:
        return None
    s = re.sub(r"\s+", " ", s)
    for fmt in _DATE_FORMATS:
        try:
            return dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    m = re.match(r"(20\d{2})-(\d{2})-(\d{2})", s)
    if m:
        return dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    # "Oct 15, 2026 09:00:00 EDT" (Tenable.sc) and similar: month name, day, year anywhere in the string
    m = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2}),?\s+(20\d{2})", s, re.I)
    if m:
        try:
            return dt.date(int(m.group(3)), _MONTHS[m.group(1)[:3].lower()], int(m.group(2)))
        except ValueError:
            return None
    return None


def to_float(value):
    try:
        if value is None or str(value).strip() == "":
            return None
        return float(str(value).strip())
    except ValueError:
        return None


def to_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (ValueError, TypeError):
        return default


_CVE_RE = re.compile(r"CVE-\d{4}-\d{4,}", re.I)


def extract_cves(text):
    if not text:
        return []
    seen, out = set(), []
    for c in _CVE_RE.findall(str(text)):
        c = c.upper()
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def norm_name(s):
    s = (s or "").strip().lower().rstrip(".")
    return s


def choose_host_key(props, priority):
    """Pick a stable host identifier using the configured priority list."""
    for field in priority:
        v = norm_name(props.get(field))
        if v:
            return v
    return norm_name(props.get("name")) or "unknown"


class ParsedScan:
    """Normalized output of any parser."""

    def __init__(self, source):
        self.source = source
        self.scan_date = None
        self.hosts = {}        # host_key -> dict(ip, fqdn, netbios, os)
        self.findings = []     # list of dict (see add_finding)
        self.warnings = []

    def add_host(self, host_key, ip="", fqdn="", netbios="", os_name=""):
        h = self.hosts.setdefault(host_key, {"ip": "", "fqdn": "", "netbios": "", "os": ""})
        if ip and not h["ip"]:
            h["ip"] = ip
        if fqdn and not h["fqdn"]:
            h["fqdn"] = fqdn
        if netbios and not h["netbios"]:
            h["netbios"] = netbios
        if os_name and not h["os"]:
            h["os"] = os_name[:120]

    def add_finding(self, **f):
        f.setdefault("port", 0)
        f.setdefault("protocol", "")
        f.setdefault("cvss2", None)
        f.setdefault("cvss3", None)
        f.setdefault("vpr", None)
        f.setdefault("cves", [])
        f.setdefault("exploit_available", False)
        f.setdefault("exploit_frameworks", "")
        f.setdefault("exploited_by_malware", False)
        f.setdefault("plugin_pub_date", None)
        f.setdefault("solution", "")
        f.setdefault("family", "")
        f.setdefault("stig_severity", "")
        f["solution"] = (f.get("solution") or "")[:600]
        self.findings.append(f)
