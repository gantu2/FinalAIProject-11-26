"""Minimal .xlsx reader using only the standard library.

Reads shared strings, inline strings, numbers and booleans. Dates stored as
Excel serial numbers are returned as floats; callers convert them with
`excel_serial_to_date` when the column is known to hold dates.
"""
import datetime as _dt
import re
import zipfile
import xml.etree.ElementTree as ET

NS_MAIN = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
NS_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
NS_PKG = "{http://schemas.openxmlformats.org/package/2006/relationships}"

_COL_RE = re.compile(r"([A-Z]+)(\d+)")


def _col_index(ref):
    """'C12' -> 2 (zero based column index)."""
    m = _COL_RE.match(ref or "")
    if not m:
        return None
    n = 0
    for ch in m.group(1):
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def excel_serial_to_date(value):
    """Excel serial (1900 date system) -> datetime.date."""
    try:
        serial = float(value)
    except (TypeError, ValueError):
        return None
    if serial < 1 or serial > 2958465:
        return None
    return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=serial)).date()


def _shared_strings(zf):
    try:
        data = zf.read("xl/sharedStrings.xml")
    except KeyError:
        return []
    out = []
    for si in ET.fromstring(data).iter(NS_MAIN + "si"):
        out.append("".join(t.text or "" for t in si.iter(NS_MAIN + "t")))
    return out


def _sheets(zf):
    """Return list of (sheet_name, zip_path) in workbook order."""
    wb = ET.fromstring(zf.read("xl/workbook.xml"))
    rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))
    rel_map = {}
    for rel in rels.iter(NS_PKG + "Relationship"):
        target = rel.get("Target", "")
        if target.startswith("/"):
            target = target[1:]
        elif not target.startswith("xl/"):
            target = "xl/" + target
        rel_map[rel.get("Id")] = target
    sheets = []
    for sh in wb.iter(NS_MAIN + "sheet"):
        rid = sh.get(NS_REL + "id")
        path = rel_map.get(rid)
        if path and path in zf.namelist():
            sheets.append((sh.get("name"), path))
    return sheets


def _cell_value(c, shared):
    t = c.get("t")
    if t == "inlineStr":
        is_el = c.find(NS_MAIN + "is")
        if is_el is None:
            return ""
        return "".join(x.text or "" for x in is_el.iter(NS_MAIN + "t"))
    v = c.find(NS_MAIN + "v")
    if v is None or v.text is None:
        return ""
    raw = v.text
    if t == "s":
        try:
            return shared[int(raw)]
        except (ValueError, IndexError):
            return ""
    if t == "b":
        return raw == "1"
    if t in ("str", "e"):
        return raw
    # numeric
    try:
        f = float(raw)
        return int(f) if f.is_integer() and "." not in raw and "E" not in raw.upper() else f
    except ValueError:
        return raw


def read_workbook(path, max_rows=None):
    """Return {sheet_name: [[cell, ...], ...]} for every sheet in the file."""
    result = {}
    with zipfile.ZipFile(path) as zf:
        shared = _shared_strings(zf)
        for name, zpath in _sheets(zf):
            rows = []
            with zf.open(zpath) as fh:
                for _ev, el in ET.iterparse(fh, events=("end",)):
                    if el.tag != NS_MAIN + "row":
                        continue
                    row = []
                    for c in el.findall(NS_MAIN + "c"):
                        idx = _col_index(c.get("r"))
                        if idx is None:
                            idx = len(row)
                        while len(row) < idx:
                            row.append("")
                        val = _cell_value(c, shared)
                        if idx < len(row):
                            row[idx] = val
                        else:
                            row.append(val)
                    rows.append(row)
                    el.clear()
                    if max_rows and len(rows) >= max_rows:
                        break
            result[name] = rows
    return result
