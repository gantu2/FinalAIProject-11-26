"""Tiny HTTP server: static files + JSON API. Standard library only."""
import json
import mimetypes
import os
import threading
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

from .ingest import Ingester
from .metrics import Metrics
from . import export as exportmod
from . import brief as briefmod

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")


class State:
    def __init__(self, conn, cfg):
        self.conn = conn
        self.cfg = cfg
        self.metrics = Metrics(conn, cfg)
        self.lock = threading.Lock()
        self.cache = {}
        self.cache_token = None

    def dashboard(self, period, enclave):
        token = self.metrics.conn.execute("SELECT value FROM meta WHERE key='last_ingest'").fetchone()
        token = token["value"] if token else None
        key = (period, enclave)
        with self.lock:
            if token != self.cache_token:
                self.cache.clear()
                self.cache_token = token
            if key in self.cache:
                return self.cache[key]
            data = self.metrics.dashboard(period, enclave)
            self.cache[key] = data
            return data

    def refresh(self):
        with self.lock:
            ing = Ingester(self.conn, self.cfg, log=lambda m: print("  " + m))
            changed = ing.run()
            self.cache.clear()
            return {"changed": changed, "messages": [{"level": lv, "message": m} for lv, m in ing.messages]}


def make_handler(state):
    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, fmt, *args):  # quieter console
            if "/api/" in (args[0] if args else ""):
                return
            super().log_message(fmt, *args)

        def _json(self, obj, status=200):
            body = json.dumps(obj, default=str).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _file(self, rel):
            rel = os.path.normpath(rel).replace("\\", "/").lstrip("/")
            path = os.path.join(WEB_DIR, rel)
            if not os.path.abspath(path).startswith(os.path.abspath(WEB_DIR)) or not os.path.isfile(path):
                self.send_error(404)
                return
            ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
            if path.endswith(".js"):
                ctype = "application/javascript"
            with open(path, "rb") as fh:
                body = fh.read()
            self.send_response(200)
            self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith("text/") or "javascript" in ctype else ""))
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            url = urllib.parse.urlsplit(self.path)
            qs = {k: v[0] for k, v in urllib.parse.parse_qs(url.query).items()}
            path = url.path
            try:
                if path == "/" or path == "/index.html":
                    return self._file("index.html")
                if path.startswith("/static/"):
                    return self._file(path[len("/static/"):])
                if path == "/api/dashboard":
                    return self._json(state.dashboard(qs.get("period"), qs.get("enclave") or None))
                if path == "/api/meta":
                    return self._json(state.metrics.meta())
                if path == "/api/findings":
                    rows = state.metrics.findings(
                        period=qs.get("period"), enclave=qs.get("enclave") or None, plugin_id=qs.get("plugin_id") or None,
                        host_key=qs.get("host_key") or None, severity=qs.get("severity") or None, q=qs.get("q") or None,
                        exploitable=qs.get("exploitable") == "1", kev=qs.get("kev") == "1",
                        limit=min(int(qs.get("limit", 500)), 5000))
                    return self._json({"rows": rows})
                if path == "/api/brief":
                    with state.lock:
                        body, sel = briefmod.build_brief_pdf(state.metrics, state.cfg, qs.get("period"), qs.get("enclave") or None)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/pdf")
                    self.send_header("Content-Disposition", 'attachment; filename="%s"' % briefmod.brief_filename(sel))
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                if path == "/api/export":
                    html = exportmod.build_static_html(state.metrics, qs.get("period"))
                    body = html.encode("utf-8")
                    name = "vulnerability-dashboard-%s.html" % (qs.get("period") or "latest")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                    self.send_header("Content-Disposition", 'attachment; filename="%s"' % name)
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers()
                    self.wfile.write(body)
                    return
                self.send_error(404)
            except Exception as exc:  # surface errors to the UI instead of a blank page
                import traceback
                traceback.print_exc()
                self._json({"error": str(exc)}, status=500)

        def do_POST(self):
            url = urllib.parse.urlsplit(self.path)
            if url.path == "/api/refresh":
                try:
                    return self._json(state.refresh())
                except Exception as exc:
                    import traceback
                    traceback.print_exc()
                    return self._json({"error": str(exc)}, status=500)
            self.send_error(404)

    return Handler


def serve(conn, cfg, open_browser=True):
    state = State(conn, cfg)
    host = cfg["server"].get("host", "127.0.0.1")
    port = int(cfg["server"].get("port", 8050))
    httpd = ThreadingHTTPServer((host, port), make_handler(state))
    httpd.daemon_threads = True
    url = "http://%s:%d/" % (host if host != "0.0.0.0" else "localhost", port)
    print("Dashboard running at %s  (Ctrl+C to stop)" % url)
    if open_browser and cfg["server"].get("open_browser", True):
        try:
            import webbrowser
            threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        except Exception:
            pass
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
