"""Configuration loading with defaults. Edit config.json, not this file."""
import copy
import json
import os

DEFAULTS = {
    "data_dir": "data",
    "server": {"host": "127.0.0.1", "port": 8050, "open_browser": True},
    "enclaves": {
        # Enclave name comes from, in order: an Enclave column / sheet name in the
        # file, the sub-folder under data/scans, then this regex on the filename.
        "filename_regex": "",
        "default_name": "Default",
    },
    "host_key_priority": ["host-fqdn", "netbios-name", "host-ip", "name"],
    "include_info": False,
    "sla_days": {"Critical": 15, "High": 30, "Medium": 90, "Low": 180, "KEV": 14},
    "health_score": {
        "weights": {"Critical": 10, "High": 4, "Medium": 1, "Low": 0.2},
        "scale": 25,
        "grades": {"A": 90, "B": 75, "C": 60, "D": 40},
    },
    "poam": {"columns": {}, "open_statuses": ["Ongoing", "Delayed"]},
    "brief": {"title": "Vulnerability Posture Brief", "organization": "", "marking": ""},
    "top_n": 15,
}


def _merge(base, override):
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path):
    cfg = copy.deepcopy(DEFAULTS)
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            cfg = _merge(cfg, json.load(fh))
    base = os.path.dirname(os.path.abspath(path)) if path else os.getcwd()
    if not os.path.isabs(cfg["data_dir"]):
        cfg["data_dir"] = os.path.join(base, cfg["data_dir"])
    cfg["_base_dir"] = base
    return cfg
