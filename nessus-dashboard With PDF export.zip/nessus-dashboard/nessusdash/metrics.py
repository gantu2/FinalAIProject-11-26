"""All dashboard numbers are computed here from the SQLite store."""
import bisect
import datetime as dt
import math

SEV = {4: "Critical", 3: "High", 2: "Medium", 1: "Low", 0: "Info"}
SEV_ORDER = ["Critical", "High", "Medium", "Low"]
AGE_BUCKETS = [(0, 30, "0-30 d"), (31, 60, "31-60 d"), (61, 90, "61-90 d"), (91, 180, "91-180 d"),
               (181, 365, "181-365 d"), (366, 10 ** 9, "> 1 yr")]


def _d(s):
    return dt.date.fromisoformat(s) if s else None


def _empty_sev():
    return {k: 0 for k in SEV_ORDER}


def _q(conn, sql, params=()):
    return conn.execute(sql, params).fetchall()


def _placeholders(items):
    return ",".join("?" * len(items))


class Metrics:
    def __init__(self, conn, cfg):
        self.conn = conn
        self.cfg = cfg
        self.weights = {k: float(v) for k, v in cfg["health_score"]["weights"].items()}
        self.scale = float(cfg["health_score"].get("scale", 25))
        self.grades = cfg["health_score"]["grades"]
        self.sla = cfg["sla_days"]
        self.open_statuses = set(cfg["poam"].get("open_statuses", ["Ongoing", "Delayed"]))
        self.top_n = int(cfg.get("top_n", 15))

    # ---------------------------------------------------------------- scopes
    def periods(self):
        return [r["period"] for r in _q(self.conn, "SELECT DISTINCT period FROM scans ORDER BY period")]

    def enclaves(self):
        return [r["enclave"] for r in _q(self.conn, "SELECT DISTINCT enclave FROM scans ORDER BY enclave")]

    def _scans(self, period, enclave=None):
        sql = "SELECT * FROM scans WHERE period=?"
        params = [period]
        if enclave:
            sql += " AND enclave=?"
            params.append(enclave)
        return _q(self.conn, sql + " ORDER BY enclave", params)

    def _prev_scan(self, enclave, period):
        return self.conn.execute(
            "SELECT * FROM scans WHERE enclave=? AND period<? ORDER BY period DESC LIMIT 1", (enclave, period)).fetchone()

    # --------------------------------------------------------------- helpers
    def _sev_counts(self, scan_ids):
        out = _empty_sev()
        if not scan_ids:
            return out
        for r in _q(self.conn, "SELECT severity, COUNT(*) n FROM findings WHERE scan_id IN (%s) GROUP BY severity"
                    % _placeholders(scan_ids), scan_ids):
            name = SEV.get(r["severity"])
            if name in out:
                out[name] = r["n"]
        return out

    def _exploit_counts(self, scan_ids):
        if not scan_ids:
            return {"exploitable": 0, "kev": 0, "kev_cves": 0, "malware": 0}
        ph = _placeholders(scan_ids)
        ex = self.conn.execute("SELECT COUNT(*) n FROM findings WHERE scan_id IN (%s) AND exploit_available=1" % ph,
                               scan_ids).fetchone()["n"]
        mal = self.conn.execute("SELECT COUNT(*) n FROM findings WHERE scan_id IN (%s) AND exploited_by_malware=1" % ph,
                                scan_ids).fetchone()["n"]
        kev = self.conn.execute(
            "SELECT COUNT(DISTINCT fc.finding_id) n, COUNT(DISTINCT fc.cve) c FROM finding_cves fc "
            "JOIN kev k ON k.cve = fc.cve JOIN findings f ON f.id = fc.finding_id WHERE f.scan_id IN (%s)" % ph,
            scan_ids).fetchone()
        return {"exploitable": ex, "kev": kev["n"], "kev_cves": kev["c"], "malware": mal}

    def health(self, sev_counts, hosts):
        if not hosts:
            return None, None, 0.0
        density = sum(self.weights.get(k, 0) * v for k, v in sev_counts.items()) / hosts
        score = 100.0 * math.exp(-density / self.scale) if self.scale > 0 else 0.0
        score = round(score, 1)
        grade = "F"
        for g, cutoff in sorted(self.grades.items(), key=lambda kv: -kv[1]):
            if score >= cutoff:
                grade = g
                break
        return score, grade, round(density, 2)

    # ------------------------------------------------------------- dashboard
    def dashboard(self, period=None, enclave=None):
        periods = self.periods()
        enclaves = self.enclaves()
        if not periods:
            return {"empty": True, "meta": self.meta()}
        if period not in periods:
            period = periods[-1]
        if enclave not in enclaves:
            enclave = None
        scans = self._scans(period, enclave)
        scan_ids = [s["id"] for s in scans]
        prev_map = {s["enclave"]: self._prev_scan(s["enclave"], period) for s in scans}
        prev_ids = [p["id"] for p in prev_map.values() if p]
        hosts = sum(s["host_count"] for s in scans)
        prev_hosts = sum(p["host_count"] for p in prev_map.values() if p)
        sev = self._sev_counts(scan_ids)
        prev_sev = self._sev_counts(prev_ids)
        score, grade, density = self.health(sev, hosts)
        pscore, pgrade, _ = self.health(prev_sev, prev_hosts)
        exploit = self._exploit_counts(scan_ids)
        prev_exploit = self._exploit_counts(prev_ids)
        age = self._age_and_sla(scans)
        poam = self._poam(scans, scan_ids)
        nfp = self._new_fixed_persistent(scans, prev_map)
        scan_dates = sorted(s["scan_date"] for s in scans)
        return {
            "empty": False,
            "selection": {"period": period, "enclave": enclave,
                          "scan_dates": {s["enclave"]: s["scan_date"] for s in scans},
                          "latest_scan_date": scan_dates[-1] if scan_dates else None,
                          "enclaves_in_period": len(scans), "enclaves_total": len(enclaves),
                          "prev_periods": {e: (p["period"] if p else None) for e, p in prev_map.items()}},
            "kpis": {
                "health": {"score": score, "grade": grade, "density": density, "prev_score": pscore, "prev_grade": pgrade},
                "hosts": {"value": hosts, "prev": prev_hosts},
                "severity": {k: {"value": sev[k], "prev": prev_sev[k]} for k in SEV_ORDER},
                "total": {"value": sum(sev.values()), "prev": sum(prev_sev.values())},
                "exploitable": {"value": exploit["exploitable"], "prev": prev_exploit["exploitable"]},
                "kev": {"value": exploit["kev"], "prev": prev_exploit["kev"], "cves": exploit["kev_cves"]},
                "malware": {"value": exploit["malware"], "prev": prev_exploit["malware"]},
                "sla_overdue": {"value": age["sla"]["overdue_total"], "prev": None},
                "not_on_poam": {"value": poam["coverage_totals"]["not_on_poam"], "prev": None},
                "new": nfp["totals"]["new"], "fixed": nfp["totals"]["fixed"], "persistent": nfp["totals"]["persistent"],
            },
            "trend": self._trend(enclave),
            "enclaves": self._enclave_table(period, enclaves if not enclave else [enclave]),
            "new_fixed": nfp,
            "age": age["age"],
            "sla": age["sla"],
            "mttr": self._mttr(enclave),
            "top_vulns": self._top_vulns(scan_ids, scans),
            "worst_hosts": self._worst_hosts(scan_ids),
            "kev_items": self._kev_items(scan_ids, scans),
            "coverage": self._coverage(scans, prev_map),
            "poam": poam,
            "meta": self.meta(),
        }

    def meta(self):
        kev_n = self.conn.execute("SELECT COUNT(*) n FROM kev").fetchone()["n"]
        poam_n = self.conn.execute("SELECT COUNT(*) n FROM poam").fetchone()["n"]
        last = self.conn.execute("SELECT value FROM meta WHERE key='last_ingest'").fetchone()
        files = [dict(r) for r in _q(self.conn, "SELECT path, kind, imported_at, status, note FROM files ORDER BY path")]
        log = [dict(r) for r in _q(self.conn, "SELECT at, level, message FROM ingest_log ORDER BY id DESC LIMIT 60")]
        scans = [dict(r) for r in _q(self.conn,
                 "SELECT enclave, period, scan_date, source_file, host_count, finding_count FROM scans ORDER BY period DESC, enclave")]
        return {
            "periods": self.periods(), "enclaves": self.enclaves(),
            "last_ingest": last["value"] if last else None,
            "kev_entries": kev_n, "poam_items": poam_n,
            "sla_days": self.sla, "health": {"weights": self.weights, "scale": self.scale, "grades": self.grades},
            "files": files, "log": log, "scans": scans,
        }

    # ----------------------------------------------------------------- trend
    def _trend(self, enclave):
        sql = ("SELECT s.period, COUNT(DISTINCT s.id) scans, SUM(s.host_count) hosts, "
               "SUM(CASE WHEN f.severity=4 THEN 1 ELSE 0 END) c, SUM(CASE WHEN f.severity=3 THEN 1 ELSE 0 END) h, "
               "SUM(CASE WHEN f.severity=2 THEN 1 ELSE 0 END) m, SUM(CASE WHEN f.severity=1 THEN 1 ELSE 0 END) l, "
               "SUM(CASE WHEN f.exploit_available=1 THEN 1 ELSE 0 END) ex "
               "FROM scans s LEFT JOIN findings f ON f.scan_id = s.id ")
        params = []
        if enclave:
            sql += "WHERE s.enclave=? "
            params.append(enclave)
        sql += "GROUP BY s.period ORDER BY s.period"
        rows = []
        # host_count is summed once per scan, not per finding: recompute from scans table
        host_rows = {r["period"]: (r["hosts"], r["scans"]) for r in _q(
            self.conn, "SELECT period, SUM(host_count) hosts, COUNT(*) scans FROM scans %s GROUP BY period"
            % ("WHERE enclave=?" if enclave else ""), params)}
        for r in _q(self.conn, sql, params):
            hosts, nscans = host_rows.get(r["period"], (0, 0))
            sevc = {"Critical": r["c"] or 0, "High": r["h"] or 0, "Medium": r["m"] or 0, "Low": r["l"] or 0}
            score, grade, _ = self.health(sevc, hosts)
            rows.append({"period": r["period"], "scans": nscans, "hosts": hosts, "exploitable": r["ex"] or 0,
                         "health": score, "grade": grade, **sevc})
        return rows

    # --------------------------------------------------------- enclave table
    def _enclave_table(self, period, enclaves):
        out = []
        for e in enclaves:
            s = self.conn.execute("SELECT * FROM scans WHERE enclave=? AND period=?", (e, period)).fetchone()
            prev = self._prev_scan(e, period)
            if not s:
                last = self.conn.execute("SELECT period, scan_date FROM scans WHERE enclave=? ORDER BY period DESC LIMIT 1",
                                         (e,)).fetchone()
                out.append({"enclave": e, "scanned": False, "last_period": last["period"] if last else None})
                continue
            sev = self._sev_counts([s["id"]])
            score, grade, density = self.health(sev, s["host_count"])
            pscore = None
            psev = _empty_sev()
            if prev:
                psev = self._sev_counts([prev["id"]])
                pscore, _, _ = self.health(psev, prev["host_count"])
            ex = self._exploit_counts([s["id"]])
            out.append({"enclave": e, "scanned": True, "scan_date": s["scan_date"], "hosts": s["host_count"],
                        "prev_hosts": prev["host_count"] if prev else None, "prev_period": prev["period"] if prev else None,
                        "health": score, "grade": grade, "prev_health": pscore, "density": density,
                        "exploitable": ex["exploitable"], "kev": ex["kev"],
                        **{k: sev[k] for k in SEV_ORDER}, **{"prev_" + k: psev[k] for k in SEV_ORDER}})
        return out

    # ------------------------------------------------------ new/fixed/persist
    def _new_fixed_persistent(self, scans, prev_map):
        per = []
        totals = {"new": 0, "fixed": 0, "persistent": 0}
        tot_sev = {"new": _empty_sev(), "fixed": _empty_sev(), "persistent": _empty_sev()}
        fixed_ages = []
        for s in scans:
            prev = prev_map.get(s["enclave"])
            cur = {r["fkey"]: r["severity"] for r in _q(self.conn, "SELECT fkey, severity FROM findings WHERE scan_id=?", (s["id"],))}
            if not prev:
                per.append({"enclave": s["enclave"], "baseline": True, "new": len(cur), "fixed": 0, "persistent": 0,
                            "new_sev": self._sev_of(cur.values()), "fixed_sev": _empty_sev(), "persistent_sev": _empty_sev()})
                continue
            old = {r["fkey"]: r["severity"] for r in _q(self.conn, "SELECT fkey, severity FROM findings WHERE scan_id=?", (prev["id"],))}
            new_keys = [k for k in cur if k not in old]
            fixed_keys = [k for k in old if k not in cur]
            pers_keys = [k for k in cur if k in old]
            row = {"enclave": s["enclave"], "baseline": False, "prev_period": prev["period"],
                   "new": len(new_keys), "fixed": len(fixed_keys), "persistent": len(pers_keys),
                   "new_sev": self._sev_of(cur[k] for k in new_keys),
                   "fixed_sev": self._sev_of(old[k] for k in fixed_keys),
                   "persistent_sev": self._sev_of(cur[k] for k in pers_keys)}
            if fixed_keys:
                ph = _placeholders(fixed_keys[:900])
                first = {r["fkey"]: r["first_date"] for r in _q(
                    self.conn, "SELECT fkey, first_date FROM finding_keys WHERE enclave=? AND fkey IN (%s)" % ph,
                    [s["enclave"]] + fixed_keys[:900])}
                closed = _d(s["scan_date"])
                for k in fixed_keys[:900]:
                    if k in first:
                        fixed_ages.append((closed - _d(first[k])).days)
            per.append(row)
            for kind, keys in (("new", new_keys), ("fixed", fixed_keys), ("persistent", pers_keys)):
                totals[kind] += len(keys)
                src = cur if kind != "fixed" else old
                for k in keys:
                    name = SEV.get(src[k])
                    if name in tot_sev[kind]:
                        tot_sev[kind][name] += 1
        return {"per_enclave": per, "totals": totals, "totals_sev": tot_sev,
                "fixed_avg_days_open": round(sum(fixed_ages) / len(fixed_ages), 1) if fixed_ages else None}

    @staticmethod
    def _sev_of(values):
        out = _empty_sev()
        for v in values:
            name = SEV.get(v)
            if name in out:
                out[name] += 1
        return out

    # ------------------------------------------------------------- age & SLA
    def _age_and_sla(self, scans):
        buckets = [{"label": b[2], **_empty_sev()} for b in AGE_BUCKETS]
        sla = {k: {"sla_days": self.sla.get(k), "total": 0, "overdue": 0, "within": 0, "oldest": 0, "sum_age": 0}
               for k in SEV_ORDER}
        kev_cfg = self.sla.get("KEV")
        kev_stats = {"total": 0, "overdue": 0, "sla_days": kev_cfg}
        for s in scans:
            scan_date = _d(s["scan_date"])
            rows = _q(self.conn,
                      "SELECT f.severity, k.first_date, "
                      "EXISTS(SELECT 1 FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve WHERE fc.finding_id=f.id) is_kev "
                      "FROM findings f JOIN finding_keys k ON k.enclave=f.enclave AND k.fkey=f.fkey WHERE f.scan_id=?",
                      (s["id"],))
            for r in rows:
                name = SEV.get(r["severity"])
                if name not in sla:
                    continue
                age = (scan_date - _d(r["first_date"])).days
                for i, (lo, hi, _lbl) in enumerate(AGE_BUCKETS):
                    if lo <= age <= hi:
                        buckets[i][name] += 1
                        break
                st = sla[name]
                st["total"] += 1
                st["sum_age"] += age
                st["oldest"] = max(st["oldest"], age)
                limit = st["sla_days"]
                if r["is_kev"] and kev_cfg:
                    kev_stats["total"] += 1
                    if age > kev_cfg:
                        kev_stats["overdue"] += 1
                    limit = min(limit, kev_cfg) if limit else kev_cfg
                if limit and age > limit:
                    st["overdue"] += 1
                else:
                    st["within"] += 1
        for st in sla.values():
            st["compliance"] = round(100.0 * st["within"] / st["total"], 1) if st["total"] else None
            st["avg_age"] = round(st["sum_age"] / st["total"], 1) if st["total"] else None
            st.pop("sum_age")
        overdue_total = sum(st["overdue"] for st in sla.values())
        return {"age": buckets, "sla": {"by_severity": sla, "kev": kev_stats, "overdue_total": overdue_total}}

    # -------------------------------------------------------------------- MTTR
    def _mttr(self, enclave):
        """Mean days from first detection to the first scan where a finding no longer appears."""
        scan_dates = {}
        for r in _q(self.conn, "SELECT enclave, scan_date FROM scans ORDER BY enclave, scan_date"):
            scan_dates.setdefault(r["enclave"], []).append(r["scan_date"])
        sql = "SELECT enclave, first_date, last_date, severity FROM finding_keys"
        params = []
        if enclave:
            sql += " WHERE enclave=?"
            params.append(enclave)
        acc = {k: [0, 0] for k in SEV_ORDER}
        for r in _q(self.conn, sql, params):
            dates = scan_dates.get(r["enclave"], [])
            i = bisect.bisect_right(dates, r["last_date"])
            if i >= len(dates):
                continue  # still open at the latest scan
            name = SEV.get(r["severity"])
            if name not in acc:
                continue
            days = (_d(dates[i]) - _d(r["first_date"])).days
            acc[name][0] += days
            acc[name][1] += 1
        return {k: {"mean_days": round(v[0] / v[1], 1) if v[1] else None, "closed": v[1]} for k, v in acc.items()}

    # -------------------------------------------------------------- top vulns
    def _top_vulns(self, scan_ids, scans):
        if not scan_ids:
            return []
        ph = _placeholders(scan_ids)
        rows = _q(self.conn,
                  "SELECT f.plugin_id, MAX(f.plugin_name) name, MAX(f.severity) severity, MAX(f.family) family, "
                  "COUNT(DISTINCT f.host_key) hosts, COUNT(*) instances, COUNT(DISTINCT f.enclave) enclaves, "
                  "MAX(f.exploit_available) exploit, MAX(f.exploited_by_malware) malware, MAX(f.cvss3) cvss3, "
                  "MAX(f.cvss2) cvss2, MAX(f.vpr) vpr, MIN(k.first_date) first_seen, MAX(f.solution) solution, "
                  "MAX(f.exploit_frameworks) frameworks, MAX(f.cves) cves, "
                  "MAX(EXISTS(SELECT 1 FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve WHERE fc.finding_id=f.id)) is_kev, "
                  "MAX(EXISTS(SELECT 1 FROM poam_plugins pp JOIN poam p ON p.id=pp.poam_id WHERE pp.plugin_id=f.plugin_id)) on_poam "
                  "FROM findings f JOIN finding_keys k ON k.enclave=f.enclave AND k.fkey=f.fkey "
                  "WHERE f.scan_id IN (%s) GROUP BY f.plugin_id "
                  "ORDER BY severity DESC, hosts DESC LIMIT ?" % ph, scan_ids + [self.top_n * 2])
        out = []
        for r in rows:
            d = dict(r)
            d["severity_name"] = SEV.get(d["severity"])
            d["poam_status"] = self._poam_status_for_plugin(d["plugin_id"])
            d["risk"] = round(self.weights.get(d["severity_name"], 0) * d["hosts"], 1)
            out.append(d)
        out.sort(key=lambda x: (-x["risk"], -x["severity"], -x["hosts"]))
        return out[:self.top_n]

    def _poam_status_for_plugin(self, plugin_id):
        rows = _q(self.conn, "SELECT p.status, p.item_id, p.scheduled FROM poam_plugins pp JOIN poam p ON p.id=pp.poam_id "
                             "WHERE pp.plugin_id=? ORDER BY p.scheduled", (plugin_id,))
        if not rows:
            return None
        open_rows = [r for r in rows if r["status"] in self.open_statuses]
        pick = open_rows[0] if open_rows else rows[0]
        return {"status": pick["status"], "item_id": pick["item_id"], "scheduled": pick["scheduled"], "items": len(rows)}

    # ------------------------------------------------------------- worst hosts
    def _worst_hosts(self, scan_ids):
        if not scan_ids:
            return []
        ph = _placeholders(scan_ids)
        rows = _q(self.conn,
                  "SELECT f.enclave, f.host_key, MAX(h.ip) ip, MAX(h.os) os, "
                  "SUM(CASE WHEN f.severity=4 THEN 1 ELSE 0 END) Critical, SUM(CASE WHEN f.severity=3 THEN 1 ELSE 0 END) High, "
                  "SUM(CASE WHEN f.severity=2 THEN 1 ELSE 0 END) Medium, SUM(CASE WHEN f.severity=1 THEN 1 ELSE 0 END) Low, "
                  "SUM(f.exploit_available) exploitable, "
                  "SUM(EXISTS(SELECT 1 FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve WHERE fc.finding_id=f.id)) kev "
                  "FROM findings f LEFT JOIN hosts h ON h.scan_id=f.scan_id AND h.host_key=f.host_key "
                  "WHERE f.scan_id IN (%s) GROUP BY f.enclave, f.host_key" % ph, scan_ids)
        out = []
        for r in rows:
            d = dict(r)
            d["score"] = round(sum(self.weights.get(k, 0) * d[k] for k in SEV_ORDER), 1)
            out.append(d)
        out.sort(key=lambda x: (-x["score"], -x["Critical"], -x["High"]))
        return out[:self.top_n]

    # -------------------------------------------------------------- KEV items
    def _kev_items(self, scan_ids, scans):
        if not scan_ids:
            return []
        ph = _placeholders(scan_ids)
        latest = max(s["scan_date"] for s in scans)
        rows = _q(self.conn,
                  "SELECT kv.cve, kv.vendor, kv.product, kv.name, kv.due_date, kv.date_added, kv.ransomware, "
                  "COUNT(DISTINCT f.host_key) hosts, COUNT(DISTINCT f.plugin_id) plugins, MAX(f.severity) severity, "
                  "MIN(k.first_date) first_seen "
                  "FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve JOIN findings f ON f.id=fc.finding_id "
                  "JOIN finding_keys k ON k.enclave=f.enclave AND k.fkey=f.fkey "
                  "WHERE f.scan_id IN (%s) GROUP BY kv.cve ORDER BY hosts DESC LIMIT 50" % ph, scan_ids)
        out = []
        for r in rows:
            d = dict(r)
            d["severity_name"] = SEV.get(d["severity"])
            d["past_due"] = bool(d["due_date"] and d["due_date"] < latest)
            d["on_poam"] = self.conn.execute("SELECT COUNT(*) n FROM poam_cves WHERE cve=?", (d["cve"],)).fetchone()["n"] > 0
            out.append(d)
        return out

    # --------------------------------------------------------------- coverage
    def _coverage(self, scans, prev_map):
        per, added_total, dropped_total = [], 0, 0
        for s in scans:
            prev = prev_map.get(s["enclave"])
            cur = {r["host_key"]: r["ip"] for r in _q(self.conn, "SELECT host_key, ip FROM hosts WHERE scan_id=?", (s["id"],))}
            if not prev:
                per.append({"enclave": s["enclave"], "hosts": len(cur), "prev_hosts": None, "added": [], "dropped": [],
                            "added_n": 0, "dropped_n": 0})
                continue
            old = {r["host_key"]: r["ip"] for r in _q(self.conn, "SELECT host_key, ip FROM hosts WHERE scan_id=?", (prev["id"],))}
            added = sorted(k for k in cur if k not in old)
            dropped = sorted(k for k in old if k not in cur)
            added_total += len(added)
            dropped_total += len(dropped)
            per.append({"enclave": s["enclave"], "hosts": len(cur), "prev_hosts": len(old), "prev_period": prev["period"],
                        "added": added[:50], "dropped": dropped[:50], "added_n": len(added), "dropped_n": len(dropped)})
        return {"per_enclave": per, "added_total": added_total, "dropped_total": dropped_total}

    # ------------------------------------------------------------------ POA&M
    def _poam(self, scans, scan_ids):
        today = dt.date.today().isoformat()
        status_counts = {r["status"]: r["n"] for r in _q(self.conn, "SELECT status, COUNT(*) n FROM poam GROUP BY status")}
        open_ph = _placeholders(self.open_statuses) if self.open_statuses else "''"
        open_list = list(self.open_statuses)
        overdue_items = [dict(r) for r in _q(
            self.conn, "SELECT item_id, description, status, scheduled, severity, plugin_ids, cves, office FROM poam "
                       "WHERE status IN (%s) AND scheduled IS NOT NULL AND scheduled < ? ORDER BY scheduled LIMIT 25"
                       % open_ph, open_list + [today])]
        overdue_n = self.conn.execute("SELECT COUNT(*) n FROM poam WHERE status IN (%s) AND scheduled IS NOT NULL AND scheduled < ?"
                                      % open_ph, open_list + [today]).fetchone()["n"]
        no_date_n = self.conn.execute("SELECT COUNT(*) n FROM poam WHERE status IN (%s) AND scheduled IS NULL" % open_ph,
                                      open_list).fetchone()["n"]
        due_30 = self.conn.execute(
            "SELECT COUNT(*) n FROM poam WHERE status IN (%s) AND scheduled >= ? AND scheduled <= ?" % open_ph,
            open_list + [today, (dt.date.today() + dt.timedelta(days=30)).isoformat()]).fetchone()["n"]
        coverage = {k: {"open": 0, "closed": 0, "not_on_poam": 0} for k in SEV_ORDER}
        unmatched = []
        closed_but_present = []
        if scan_ids:
            ph = _placeholders(scan_ids)
            rows = _q(self.conn,
                      "SELECT f.plugin_id, MAX(f.plugin_name) name, MAX(f.severity) severity, COUNT(DISTINCT f.host_key) hosts, "
                      "COUNT(*) instances, "
                      "(SELECT GROUP_CONCAT(DISTINCT p.status) FROM poam_plugins pp JOIN poam p ON p.id=pp.poam_id "
                      " WHERE pp.plugin_id=f.plugin_id) statuses, "
                      "(SELECT GROUP_CONCAT(DISTINCT p.status) FROM finding_cves fc JOIN poam_cves pc ON pc.cve=fc.cve "
                      " JOIN poam p ON p.id=pc.poam_id WHERE fc.finding_id=f.id) cve_statuses "
                      "FROM findings f WHERE f.scan_id IN (%s) GROUP BY f.plugin_id" % ph, scan_ids)
            for r in rows:
                name = SEV.get(r["severity"])
                if name not in coverage:
                    continue
                statuses = set((r["statuses"] or "").split(",")) | set((r["cve_statuses"] or "").split(","))
                statuses.discard("")
                if not statuses:
                    coverage[name]["not_on_poam"] += r["instances"]
                    unmatched.append({"plugin_id": r["plugin_id"], "name": r["name"], "severity": r["severity"],
                                      "severity_name": name, "hosts": r["hosts"], "instances": r["instances"]})
                elif statuses & self.open_statuses:
                    coverage[name]["open"] += r["instances"]
                else:
                    coverage[name]["closed"] += r["instances"]
                    closed_but_present.append({"plugin_id": r["plugin_id"], "name": r["name"], "severity": r["severity"],
                                               "severity_name": name, "hosts": r["hosts"], "statuses": sorted(statuses)})
        unmatched.sort(key=lambda x: (-x["severity"], -x["hosts"]))
        closed_but_present.sort(key=lambda x: (-x["severity"], -x["hosts"]))
        totals = {"open": sum(v["open"] for v in coverage.values()), "closed": sum(v["closed"] for v in coverage.values()),
                  "not_on_poam": sum(v["not_on_poam"] for v in coverage.values())}
        # hosts still affected per overdue item
        for it in overdue_items:
            pids = [int(p) for p in (it["plugin_ids"] or "").split(",") if p]
            n = 0
            if pids and scan_ids:
                n = self.conn.execute("SELECT COUNT(DISTINCT host_key) n FROM findings WHERE scan_id IN (%s) AND plugin_id IN (%s)"
                                      % (_placeholders(scan_ids), _placeholders(pids)), scan_ids + pids).fetchone()["n"]
            it["hosts_affected"] = n
        return {"loaded": bool(status_counts), "status_counts": status_counts, "overdue_items": overdue_items,
                "overdue_n": overdue_n, "no_date_n": no_date_n, "due_30_n": due_30,
                "coverage": coverage, "coverage_totals": totals,
                "unmatched_top": [u for u in unmatched if u["severity"] >= 3][:self.top_n],
                "closed_but_present": closed_but_present[:self.top_n]}

    # ---------------------------------------------------------- drill-down API
    def findings(self, period=None, enclave=None, plugin_id=None, host_key=None, severity=None, q=None,
                 exploitable=None, kev=None, limit=500):
        periods = self.periods()
        if not periods:
            return []
        if period not in periods:
            period = periods[-1]
        scans = self._scans(period, enclave if enclave in self.enclaves() else None)
        ids = [s["id"] for s in scans]
        if not ids:
            return []
        sql = ("SELECT f.id, f.enclave, f.host_key, h.ip, f.plugin_id, f.plugin_name, f.severity, f.port, f.protocol, "
               "f.cvss3, f.cvss2, f.vpr, f.cves, f.exploit_available, f.exploit_frameworks, f.plugin_pub_date, f.solution, "
               "k.first_date, s.scan_date, "
               "EXISTS(SELECT 1 FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve WHERE fc.finding_id=f.id) is_kev, "
               "(SELECT GROUP_CONCAT(DISTINCT p.status) FROM poam_plugins pp JOIN poam p ON p.id=pp.poam_id WHERE pp.plugin_id=f.plugin_id) poam "
               "FROM findings f JOIN scans s ON s.id=f.scan_id "
               "LEFT JOIN hosts h ON h.scan_id=f.scan_id AND h.host_key=f.host_key "
               "LEFT JOIN finding_keys k ON k.enclave=f.enclave AND k.fkey=f.fkey "
               "WHERE f.scan_id IN (%s)" % _placeholders(ids))
        params = list(ids)
        if plugin_id:
            sql += " AND f.plugin_id=?"
            params.append(int(plugin_id))
        if host_key:
            sql += " AND f.host_key=?"
            params.append(host_key)
        if severity:
            sql += " AND f.severity=?"
            params.append(int(severity))
        if exploitable:
            sql += " AND f.exploit_available=1"
        if kev:
            sql += " AND EXISTS(SELECT 1 FROM finding_cves fc JOIN kev kv ON kv.cve=fc.cve WHERE fc.finding_id=f.id)"
        if q:
            sql += " AND (f.plugin_name LIKE ? OR f.host_key LIKE ? OR f.cves LIKE ? OR CAST(f.plugin_id AS TEXT) LIKE ?)"
            params += ["%" + q + "%"] * 4
        sql += " ORDER BY f.severity DESC, f.host_key LIMIT ?"
        params.append(int(limit))
        out = []
        for r in _q(self.conn, sql, params):
            d = dict(r)
            d["severity_name"] = SEV.get(d["severity"])
            d["age_days"] = (_d(d["scan_date"]) - _d(d["first_date"])).days if d["first_date"] else None
            out.append(d)
        return out
