"""Nessus vulnerability dashboard - standard-library only."""
__version__ = "1.0.0"
