"""Walk the data folder and load anything new or changed into SQLite."""
import datetime as dt
import hashlib
import os
import re

from . import db as dbmod
from .kev import load_kev_file
from .parsers.nessus_csv import parse_csv_multi, parse_xlsx_multi
from .parsers.nessus_xml import parse_nessus
from .parsers.poam import parse_poam_file

SCAN_EXTS = {".nessus": "nessus", ".xml": "nessus", ".csv": "csv", ".xlsx": "xlsx", ".xlsm": "xlsx"}


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


class Ingester:
    def __init__(self, conn, cfg, log=print):
        self.conn = conn
        self.cfg = cfg
        self.log = log
        self.messages = []

    # ---------------------------------------------------------------- helpers
    def _note(self, level, msg):
        self.messages.append((level, msg))
        self.conn.execute("INSERT INTO ingest_log(at, level, message) VALUES (?,?,?)", (_now(), level, msg))
        self.log("[%s] %s" % (level, msg))

    def _file_changed(self, path, kind):
        st = os.stat(path)
        row = self.conn.execute("SELECT size, mtime, sha256, status FROM files WHERE path=?", (path,)).fetchone()
        if row and row["size"] == st.st_size and abs(row["mtime"] - st.st_mtime) < 1 and row["status"] == "ok":
            return False, row
        return True, row

    def _record_file(self, path, kind, status, note=""):
        st = os.stat(path)
        self.conn.execute(
            "INSERT OR REPLACE INTO files(path, kind, size, mtime, sha256, imported_at, status, note) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (path, kind, st.st_size, st.st_mtime, _sha256(path) if st.st_size < (200 << 20) else "", _now(), status, note))

    def _enclave_for(self, path, scans_dir, hint):
        if hint:
            return hint
        rel = os.path.relpath(path, scans_dir)
        parts = rel.replace("\\", "/").split("/")
        if len(parts) > 1:
            return parts[0]
        rx = self.cfg["enclaves"].get("filename_regex")
        if rx:
            m = re.search(rx, os.path.basename(path))
            if m:
                return (m.groupdict().get("enclave") or m.group(1)).strip()
        return self.cfg["enclaves"].get("default_name", "Default")

    # ------------------------------------------------------------------ scans
    def run(self):
        data_dir = self.cfg["data_dir"]
        scans_dir = os.path.join(data_dir, "scans")
        poam_dir = os.path.join(data_dir, "poam")
        kev_dir = os.path.join(data_dir, "kev")
        for d in (scans_dir, poam_dir, kev_dir):
            os.makedirs(d, exist_ok=True)
        changed = 0
        changed += self._ingest_kev(kev_dir)
        changed += self._ingest_scans(scans_dir)
        changed += self._ingest_poam(poam_dir)
        self._remove_deleted_files()
        if changed:
            self._rebuild_finding_keys()
        dbmod.set_meta(self.conn, "last_ingest", _now())
        self.conn.commit()
        return changed

    def _ingest_scans(self, scans_dir):
        changed = 0
        for root, _dirs, files in os.walk(scans_dir):
            for name in sorted(files):
                ext = os.path.splitext(name)[1].lower()
                kind = SCAN_EXTS.get(ext)
                if not kind or name.startswith("~$"):
                    continue
                path = os.path.join(root, name)
                is_new, _prev = self._file_changed(path, kind)
                if not is_new:
                    continue
                try:
                    n = self._load_scan_file(path, kind, scans_dir)
                    changed += n
                except Exception as exc:  # keep going on a bad file
                    self._note("error", "%s: failed to parse (%s)" % (name, exc))
                    self._record_file(path, kind, "error", str(exc)[:300])
                self.conn.commit()
        return changed

    def _load_scan_file(self, path, kind, scans_dir):
        name = os.path.basename(path)
        prio = self.cfg["host_key_priority"]
        if kind == "nessus":
            parsed = [(None, parse_nessus(path, prio))]
        elif kind == "csv":
            parsed = list(parse_csv_multi(path, prio))
        else:
            parsed = list(parse_xlsx_multi(path, prio))
        if not parsed:
            self._note("warn", "%s: no findings tables recognised, skipped" % name)
            self._record_file(path, kind, "skipped", "no findings table")
            return 0
        # Old scans from this file are replaced wholesale.
        self._delete_scans_for_file(path)
        loaded = 0
        notes = []
        for hint, scan in parsed:
            for w in scan.warnings:
                if w:
                    self._note("warn", "%s: %s" % (scan.source, w))
            if not scan.findings and not scan.hosts:
                continue
            if not scan.scan_date:
                self._note("error", "%s: no scan date; put YYYY-MM-DD or YYYY-MM in the filename" % scan.source)
                continue
            enclave = self._enclave_for(path, scans_dir, hint)
            period = scan.scan_date.strftime("%Y-%m")
            existing = self.conn.execute(
                "SELECT id, scan_date, source_file, file_path FROM scans WHERE enclave=? AND period=?",
                (enclave, period)).fetchone()
            if existing and existing["file_path"] != path:
                if existing["scan_date"] >= scan.scan_date.isoformat():
                    self._note("warn", "%s: %s already has a scan for %s from %s (newer or same date); skipped" % (
                        scan.source, enclave, period, existing["source_file"]))
                    continue
                self._note("warn", "%s: replaces older %s scan for %s from %s" % (
                    scan.source, enclave, period, existing["source_file"]))
                self._delete_scan(existing["id"])
            self._insert_scan(enclave, period, scan, path)
            loaded += 1
            notes.append("%s %s" % (enclave, period))
        self._record_file(path, kind, "ok" if loaded else "skipped", "; ".join(notes)[:300])
        if loaded:
            self._note("info", "%s: loaded %s" % (name, ", ".join(notes)))
        return loaded

    def _insert_scan(self, enclave, period, scan, path):
        include_info = self.cfg.get("include_info", False)
        findings = [f for f in scan.findings if include_info or f["severity"] > 0]
        cur = self.conn.execute(
            "INSERT INTO scans(enclave, period, scan_date, source_file, file_path, imported_at, host_count, finding_count) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (enclave, period, scan.scan_date.isoformat(), scan.source, path, _now(), len(scan.hosts), len(findings)))
        scan_id = cur.lastrowid
        self.conn.executemany(
            "INSERT OR REPLACE INTO hosts(scan_id, host_key, ip, fqdn, netbios, os) VALUES (?,?,?,?,?,?)",
            [(scan_id, k, h["ip"], h["fqdn"], h["netbios"], h["os"]) for k, h in scan.hosts.items()])
        rows = []
        for f in findings:
            fkey = "%s|%d|%d|%s" % (f["host_key"], f["plugin_id"], f["port"] or 0, f["protocol"] or "")
            rows.append((scan_id, enclave, f["host_key"], fkey, f["plugin_id"], f["plugin_name"], f["family"],
                         f["severity"], f["port"], f["protocol"], f["cvss2"], f["cvss3"], f["vpr"],
                         ",".join(f["cves"]), 1 if f["exploit_available"] else 0, f["exploit_frameworks"],
                         1 if f["exploited_by_malware"] else 0,
                         f["plugin_pub_date"].isoformat() if f["plugin_pub_date"] else None,
                         f["solution"], f["stig_severity"]))
        self.conn.executemany(
            "INSERT INTO findings(scan_id, enclave, host_key, fkey, plugin_id, plugin_name, family, severity, port, "
            "protocol, cvss2, cvss3, vpr, cves, exploit_available, exploit_frameworks, exploited_by_malware, "
            "plugin_pub_date, solution, stig_severity) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
        # CVE link table for KEV joins
        self.conn.execute(
            "INSERT INTO finding_cves(finding_id, cve) "
            "WITH RECURSIVE split(fid, cve, rest) AS ("
            "  SELECT id, '', cves || ',' FROM findings WHERE scan_id=? AND cves <> '' "
            "  UNION ALL SELECT fid, substr(rest, 1, instr(rest, ',') - 1), substr(rest, instr(rest, ',') + 1) "
            "  FROM split WHERE rest <> '') "
            "SELECT fid, cve FROM split WHERE cve <> ''", (scan_id,))

    def _delete_scan(self, scan_id):
        self.conn.execute("DELETE FROM finding_cves WHERE finding_id IN (SELECT id FROM findings WHERE scan_id=?)", (scan_id,))
        self.conn.execute("DELETE FROM findings WHERE scan_id=?", (scan_id,))
        self.conn.execute("DELETE FROM hosts WHERE scan_id=?", (scan_id,))
        self.conn.execute("DELETE FROM scans WHERE id=?", (scan_id,))

    def _delete_scans_for_file(self, path):
        for row in self.conn.execute("SELECT id FROM scans WHERE file_path=?", (path,)).fetchall():
            self._delete_scan(row["id"])

    def _remove_deleted_files(self):
        for row in self.conn.execute("SELECT path, kind FROM files").fetchall():
            if os.path.exists(row["path"]):
                continue
            if row["kind"] in ("nessus", "csv", "xlsx"):
                self._delete_scans_for_file(row["path"])
            elif row["kind"] == "poam":
                self._delete_poam_for_file(row["path"])
            self.conn.execute("DELETE FROM files WHERE path=?", (row["path"],))
            self._note("info", "%s: file removed, data dropped" % os.path.basename(row["path"]))
            self._rebuild_finding_keys()

    def _rebuild_finding_keys(self):
        self.conn.execute("DELETE FROM finding_keys")
        self.conn.execute(
            "INSERT INTO finding_keys(enclave, fkey, first_date, first_period, last_date, last_period, severity) "
            "SELECT f.enclave, f.fkey, MIN(s.scan_date), MIN(s.period), MAX(s.scan_date), MAX(s.period), MAX(f.severity) "
            "FROM findings f JOIN scans s ON s.id = f.scan_id GROUP BY f.enclave, f.fkey")

    # ------------------------------------------------------------------- POA&M
    def _ingest_poam(self, poam_dir):
        changed = 0
        for name in sorted(os.listdir(poam_dir)):
            ext = os.path.splitext(name)[1].lower()
            if ext not in (".xlsx", ".xlsm", ".csv") or name.startswith("~$"):
                continue
            path = os.path.join(poam_dir, name)
            is_new, _prev = self._file_changed(path, "poam")
            if not is_new:
                continue
            try:
                items, warnings = parse_poam_file(path, self.cfg["poam"].get("columns"))
            except Exception as exc:
                self._note("error", "%s: failed to parse POA&M (%s)" % (name, exc))
                self._record_file(path, "poam", "error", str(exc)[:300])
                continue
            for w in warnings:
                self._note("warn", w)
            self._delete_poam_for_file(path)
            for it in items:
                cur = self.conn.execute(
                    "INSERT INTO poam(item_id, description, plugin_ids, cves, status, raw_status, scheduled, severity, "
                    "devices, office, control, milestones, source_file) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (it["item_id"], it["description"], ",".join(str(p) for p in it["plugin_ids"]), ",".join(it["cves"]),
                     it["status"], it["raw_status"], it["scheduled"], it["severity"], it["devices"], it["office"],
                     it["control"], it["milestones"], path))
                pid = cur.lastrowid
                self.conn.executemany("INSERT INTO poam_plugins(plugin_id, poam_id) VALUES (?,?)",
                                      [(p, pid) for p in it["plugin_ids"]])
                self.conn.executemany("INSERT INTO poam_cves(cve, poam_id) VALUES (?,?)",
                                      [(c, pid) for c in it["cves"]])
            self._record_file(path, "poam", "ok" if items else "skipped", "%d items" % len(items))
            self._note("info", "%s: loaded %d POA&M items" % (name, len(items)))
            changed += 1
            self.conn.commit()
        return changed

    def _delete_poam_for_file(self, path):
        ids = [r["id"] for r in self.conn.execute("SELECT id FROM poam WHERE source_file=?", (path,)).fetchall()]
        if ids:
            q = ",".join("?" * len(ids))
            self.conn.execute("DELETE FROM poam_plugins WHERE poam_id IN (%s)" % q, ids)
            self.conn.execute("DELETE FROM poam_cves WHERE poam_id IN (%s)" % q, ids)
            self.conn.execute("DELETE FROM poam WHERE id IN (%s)" % q, ids)

    # --------------------------------------------------------------------- KEV
    def _ingest_kev(self, kev_dir):
        changed = 0
        for name in sorted(os.listdir(kev_dir)):
            ext = os.path.splitext(name)[1].lower()
            if ext not in (".json", ".csv"):
                continue
            path = os.path.join(kev_dir, name)
            is_new, _prev = self._file_changed(path, "kev")
            if not is_new:
                continue
            try:
                rows = load_kev_file(path)
            except Exception as exc:
                self._note("error", "%s: failed to parse KEV catalog (%s)" % (name, exc))
                self._record_file(path, "kev", "error", str(exc)[:300])
                continue
            self.conn.execute("DELETE FROM kev")
            self.conn.executemany(
                "INSERT OR REPLACE INTO kev(cve, vendor, product, name, date_added, due_date, ransomware) "
                "VALUES (?,?,?,?,?,?,?)",
                [(r["cve"], r["vendor"], r["product"], r["name"], r["date_added"], r["due_date"],
                  1 if r["ransomware"] else 0) for r in rows])
            self._record_file(path, "kev", "ok", "%d CVEs" % len(rows))
            self._note("info", "%s: loaded %d KEV entries" % (name, len(rows)))
            changed += 1
            self.conn.commit()
        return changed
