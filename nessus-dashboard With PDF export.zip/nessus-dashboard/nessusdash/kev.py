"""CISA Known Exploited Vulnerabilities catalog loader (JSON or CSV)."""
import csv
import json
import os

KEV_JSON_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"


def load_kev_file(path):
    """Return list of dicts: cve, vendor, product, name, date_added, due_date, ransomware."""
    ext = os.path.splitext(path)[1].lower()
    out = []
    if ext == ".json":
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        for v in data.get("vulnerabilities", []):
            out.append({
                "cve": str(v.get("cveID", "")).upper(),
                "vendor": v.get("vendorProject", ""),
                "product": v.get("product", ""),
                "name": v.get("vulnerabilityName", ""),
                "date_added": v.get("dateAdded"),
                "due_date": v.get("dueDate"),
                "ransomware": str(v.get("knownRansomwareCampaignUse", "")).lower() == "known",
            })
    elif ext == ".csv":
        with open(path, "r", newline="", encoding="utf-8-sig", errors="replace") as fh:
            for row in csv.DictReader(fh):
                low = {k.strip().lower(): v for k, v in row.items() if k}
                out.append({
                    "cve": str(low.get("cveid", "")).upper(),
                    "vendor": low.get("vendorproject", ""),
                    "product": low.get("product", ""),
                    "name": low.get("vulnerabilityname", ""),
                    "date_added": low.get("dateadded"),
                    "due_date": low.get("duedate"),
                    "ransomware": str(low.get("knownransomwarecampaignuse", "")).lower() == "known",
                })
    return [r for r in out if r["cve"].startswith("CVE-")]


def download_kev(dest_dir, timeout=30):
    """Fetch the catalog from CISA (needs internet). Returns the saved path."""
    import urllib.request
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, "known_exploited_vulnerabilities.json")
    req = urllib.request.Request(KEV_JSON_URL, headers={"User-Agent": "nessus-dashboard"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(dest, "wb") as fh:
        fh.write(resp.read())
    return dest
