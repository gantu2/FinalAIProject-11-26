"""SQLite storage."""
import os
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS files (
    path TEXT PRIMARY KEY, kind TEXT, size INTEGER, mtime REAL, sha256 TEXT,
    imported_at TEXT, status TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    enclave TEXT NOT NULL, period TEXT NOT NULL, scan_date TEXT NOT NULL,
    source_file TEXT, file_path TEXT, imported_at TEXT,
    host_count INTEGER DEFAULT 0, finding_count INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_scans_enc_period ON scans(enclave, period);
CREATE TABLE IF NOT EXISTS hosts (
    scan_id INTEGER NOT NULL, host_key TEXT NOT NULL,
    ip TEXT, fqdn TEXT, netbios TEXT, os TEXT,
    PRIMARY KEY (scan_id, host_key)
);
CREATE TABLE IF NOT EXISTS findings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL, enclave TEXT NOT NULL, host_key TEXT NOT NULL,
    fkey TEXT NOT NULL,
    plugin_id INTEGER NOT NULL, plugin_name TEXT, family TEXT, severity INTEGER NOT NULL,
    port INTEGER, protocol TEXT, cvss2 REAL, cvss3 REAL, vpr REAL, cves TEXT,
    exploit_available INTEGER DEFAULT 0, exploit_frameworks TEXT,
    exploited_by_malware INTEGER DEFAULT 0, plugin_pub_date TEXT, solution TEXT,
    stig_severity TEXT
);
CREATE INDEX IF NOT EXISTS ix_findings_scan ON findings(scan_id);
CREATE INDEX IF NOT EXISTS ix_findings_key ON findings(enclave, fkey);
CREATE INDEX IF NOT EXISTS ix_findings_plugin ON findings(plugin_id);
CREATE TABLE IF NOT EXISTS finding_keys (
    enclave TEXT NOT NULL, fkey TEXT NOT NULL,
    first_date TEXT, first_period TEXT, last_date TEXT, last_period TEXT, severity INTEGER,
    PRIMARY KEY (enclave, fkey)
);
CREATE TABLE IF NOT EXISTS poam (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id TEXT, description TEXT, plugin_ids TEXT, cves TEXT, status TEXT, raw_status TEXT,
    scheduled TEXT, severity TEXT, devices TEXT, office TEXT, control TEXT, milestones TEXT,
    source_file TEXT
);
CREATE TABLE IF NOT EXISTS poam_plugins (plugin_id INTEGER, poam_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_poam_plugins ON poam_plugins(plugin_id);
CREATE TABLE IF NOT EXISTS poam_cves (cve TEXT, poam_id INTEGER);
CREATE INDEX IF NOT EXISTS ix_poam_cves ON poam_cves(cve);
CREATE TABLE IF NOT EXISTS kev (
    cve TEXT PRIMARY KEY, vendor TEXT, product TEXT, name TEXT,
    date_added TEXT, due_date TEXT, ransomware INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS finding_cves (finding_id INTEGER, cve TEXT);
CREATE INDEX IF NOT EXISTS ix_finding_cves_cve ON finding_cves(cve);
CREATE INDEX IF NOT EXISTS ix_finding_cves_fid ON finding_cves(finding_id);
CREATE TABLE IF NOT EXISTS ingest_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT, level TEXT, message TEXT
);
"""


def connect(data_dir):
    os.makedirs(data_dir, exist_ok=True)
    path = os.path.join(data_dir, "dashboard.sqlite")
    conn = sqlite3.connect(path, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.executescript(SCHEMA)
    return conn


def set_meta(conn, key, value):
    conn.execute("INSERT OR REPLACE INTO meta(key, value) VALUES (?, ?)", (key, str(value)))


def get_meta(conn, key, default=None):
    row = conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
    return row["value"] if row else default
