"""Build a single self-contained HTML file with the dashboard data embedded."""
import json
import os

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")


def _read(rel):
    with open(os.path.join(WEB_DIR, rel), "r", encoding="utf-8") as fh:
        return fh.read()


def build_static_html(metrics, period=None):
    periods = metrics.periods()
    if not periods:
        raise RuntimeError("no scans loaded")
    if period not in periods:
        period = periods[-1]
    payloads = {"": metrics.dashboard(period, None)}
    for e in metrics.enclaves():
        payloads[e] = metrics.dashboard(period, e)
    embedded = {"period": period, "dashboards": payloads}
    html = _read("index.html")
    html = html.replace('<link rel="stylesheet" href="static/styles.css">', "<style>\n%s\n</style>" % _read("styles.css"))
    html = html.replace('<script src="static/vendor/chart.umd.js"></script>',
                        "<script>\n%s\n</script>" % _read("vendor/chart.umd.js"))
    data_js = json.dumps(embedded, default=str).replace("</", "<\\/")
    html = html.replace('<script src="static/app.js"></script>',
                        "<script>window.__EMBEDDED__ = %s;</script>\n<script>\n%s\n</script>" % (data_js, _read("app.js")))
    return html
