@echo off
rem Writes the monthly leadership brief (PDF) for the latest month into this folder.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 app.py brief %*) || (python app.py brief %*)
pause
