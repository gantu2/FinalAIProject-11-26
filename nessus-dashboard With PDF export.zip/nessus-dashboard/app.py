#!/usr/bin/env python3
"""Nessus vulnerability dashboard.

Usage:
  python app.py                 ingest new files, then start the dashboard
  python app.py ingest          ingest only (no server)
  python app.py serve           start the server without ingesting
  python app.py export [--period YYYY-MM] [--out file.html]
                                write a standalone HTML dashboard to share
  python app.py brief [--period YYYY-MM] [--enclave NAME] [--out file.pdf]
                                write the monthly leadership brief as a PDF
  python app.py update-kev      download the CISA KEV catalog into data/kev (needs internet)
  python app.py reset           delete the database (source files are untouched)
Options:
  --config path/to/config.json  (default: config.json next to this file)
  --no-browser                  do not open a browser window
  --data path                   use another data folder (e.g. sample-data)
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from nessusdash import __version__                     # noqa: E402
from nessusdash.config import load_config              # noqa: E402
from nessusdash import db as dbmod                     # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description="Nessus vulnerability dashboard", usage=__doc__)
    ap.add_argument("command", nargs="?", default="run",
                    choices=["run", "ingest", "serve", "export", "brief", "update-kev", "reset"])
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--period", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--enclave", default=None)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--port", type=int, default=None)
    ap.add_argument("--data", default=None, help="data folder (overrides data_dir in config.json)")
    args = ap.parse_args(argv)

    if sys.version_info < (3, 8):
        print("Python 3.8 or newer is required (found %s)." % sys.version.split()[0])
        return 2
    cfg = load_config(args.config)
    if args.port:
        cfg["server"]["port"] = args.port
    if args.data:
        cfg["data_dir"] = os.path.abspath(args.data)
    data_dir = cfg["data_dir"]
    print("Nessus dashboard v%s  |  data folder: %s" % (__version__, data_dir))

    if args.command == "reset":
        for name in ("dashboard.sqlite", "dashboard.sqlite-wal", "dashboard.sqlite-shm"):
            p = os.path.join(data_dir, name)
            if os.path.exists(p):
                os.remove(p)
        print("Database removed. Run again to rebuild from the files in %s" % data_dir)
        return 0

    if args.command == "update-kev":
        from nessusdash.kev import download_kev
        try:
            path = download_kev(os.path.join(data_dir, "kev"))
            print("Saved %s" % path)
        except Exception as exc:
            print("Download failed (%s). Download it manually from cisa.gov and copy it to %s"
                  % (exc, os.path.join(data_dir, "kev")))
            return 1
        return 0

    conn = dbmod.connect(data_dir)
    if args.command in ("run", "ingest", "brief"):
        from nessusdash.ingest import Ingester
        print("Scanning %s for new or changed files..." % data_dir)
        ing = Ingester(conn, cfg)
        changed = ing.run()
        n = conn.execute("SELECT COUNT(*) n FROM scans").fetchone()["n"]
        print("Done. %d file(s) loaded this run, %d scan(s) in the database." % (changed, n))
        if n == 0:
            print("No scans found. Put .nessus / .csv / .xlsx exports under %s" % os.path.join(data_dir, "scans"))
    if args.command == "export":
        from nessusdash.export import build_static_html
        from nessusdash.metrics import Metrics
        html = build_static_html(Metrics(conn, cfg), args.period)
        out = args.out or os.path.join(HERE, "vulnerability-dashboard-%s.html" % (args.period or "latest"))
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(html)
        print("Wrote %s" % out)
        return 0
    if args.command == "brief":
        from nessusdash.brief import build_brief_pdf, brief_filename
        from nessusdash.metrics import Metrics
        try:
            pdf, sel = build_brief_pdf(Metrics(conn, cfg), cfg, args.period, args.enclave)
        except RuntimeError as exc:
            print("Cannot build the brief: %s" % exc)
            return 1
        out = args.out or os.path.join(HERE, brief_filename(sel))
        with open(out, "wb") as fh:
            fh.write(pdf)
        print("Wrote %s" % out)
        return 0
    if args.command in ("run", "serve"):
        from nessusdash.server import serve
        serve(conn, cfg, open_browser=not args.no_browser)
    return 0


if __name__ == "__main__":
    sys.exit(main())
