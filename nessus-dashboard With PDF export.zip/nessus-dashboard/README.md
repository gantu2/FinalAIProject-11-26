# Nessus Vulnerability Dashboard

A single-pane-of-glass view of monthly Nessus scans across several enclaves,
with POA&M tracking and CISA KEV cross-referencing. Built for a locked-down
Windows workstation: **Python standard library only, no pip, no internet
required**, no database server, no authentication.

```
run.bat            ingest anything new under data\ and open the dashboard
try-sample.bat     same, but on built-in synthetic data (nothing real in it)
brief.bat          write the monthly leadership brief as a PDF
export.bat         write a standalone .html you can email to leadership
```

## 1. Requirements

* Windows (also runs on Linux/macOS) with **Python 3.8 or newer** on the PATH
  (`py -3 --version` or `python --version`). Nothing else is installed; the
  chart library is bundled in `web\vendor`.
* A modern browser (Edge, Chrome, Firefox).

## 2. Quick start

1. Copy the whole `nessus-dashboard` folder to the work machine.
2. Run `tools\selftest.py` once (`py -3 tools\selftest.py`) to confirm the
   Python install is good.
3. Drop scan exports under `data\scans\<Enclave>\` (see layout below), the
   POA&M workbook under `data\poam\`, and optionally the KEV catalog under
   `data\kev\`.
4. Double-click `run.bat`. It imports new files, starts a local web server on
   `http://127.0.0.1:8050/` and opens your browser. Close the console window
   (or Ctrl+C) to stop it.

To see it working before you have real data, double-click `try-sample.bat`.

## 3. Data folder layout

```
data\
  scans\
    HQ-Users\          <- one folder per enclave; the folder name is the enclave name
      HQ-Users_2026-10-07.nessus
      HQ-Users_2026-11-04.nessus
    DMZ\
      DMZ_2026-11-08.csv
    Combined_2026-11.xlsx    <- a combined workbook can sit at the top level
  poam\
    POAM_export.xlsx         <- eMASS POA&M export (.xlsx or .csv)
  kev\
    known_exploited_vulnerabilities.json   <- CISA KEV catalog (JSON or CSV)
  dashboard.sqlite           <- created automatically; delete to rebuild
```

**Accepted scan formats**

| Format | Notes |
|---|---|
| `.nessus` (Nessus v2 XML) | Preferred. Scan date, hostnames, CVEs, exploit flags and VPR all come from the file. |
| `.csv` (Nessus Professional or Tenable.sc export) | Columns are matched by name, so either product's export works. Nessus CSV has no scan date, so put the date in the filename. |
| `.xlsx` combined workbook | Each sheet whose header looks like a Nessus CSV is loaded. The **sheet name** becomes the enclave name, unless the sheet has an `Enclave` / `Site` / `Network` column, in which case rows are split on that column. |

**How the enclave is decided**, in order: an Enclave column or sheet name in the
file, then the sub-folder under `data\scans`, then the optional
`enclaves.filename_regex` in `config.json`, then `enclaves.default_name`.

**How the scan date is decided**: `HOST_START` tags in `.nessus`, a
`Last Observed` / `Scan Date` column in CSV, otherwise a date in the filename
(`2026-11-04`, `2026-11`, `11-04-2026`, `Nov 2026` all work). A file with no
date at all is skipped with a message in the Data panel.

**One scan per enclave per month.** If two files land in the same enclave and
month, the one with the later scan date wins and the other is reported as
skipped.

**Re-importing.** Every start of `run.bat`, and the *Refresh data* button,
re-scan the folder. Unchanged files are skipped; changed files are reloaded;
files you delete are removed from the database. The *Data* button in the
header shows every file, every scan and every import message.

Keep each enclave on one export format where you can. Hosts are identified by
FQDN, then NetBIOS name, then IP (order set by `host_key_priority`), so a
`.nessus` file one month and a CSV without DNS names the next month can make
the same host look like two different hosts.

## 4. POA&M workbook

Drop the eMASS POA&M export (`.xlsx` or `.csv`) into `data\poam`. The metadata
block eMASS puts above the header row is handled automatically. Columns are
found by name; the defaults cover the eMASS template (`POA&M Item ID`,
`Control Vulnerability Description`, `Security Checks`,
`Source Identifying Vulnerability`, `Status`, `Scheduled Completion Date`,
`Raw Severity`, `Devices Affected`, `Office/Org`, ...). If your workbook uses
different titles, map them in `config.json`:

```json
"poam": { "columns": { "checks": "Nessus Plugin IDs", "scheduled": "Target Date" } }
```

Findings are matched to POA&M items by **Nessus plugin ID** found in the
`Security Checks`, `Source Identifying Vulnerability` or description columns
(`Plugin 12345`, `Plugin ID: 12345` or a bare 5-7 digit number in the
Security Checks column), and by **CVE** as a fallback. Statuses are normalised
to Ongoing, Delayed, Completed, Risk Accepted and Not Applicable; the first
two count as open (`poam.open_statuses`).

The dashboard then shows: status breakdown, items past their scheduled
completion date, items due in 30 days, how many current findings have an open
item / a closed item / no item at all, critical and high findings with no
item, and items marked Completed whose plugin is still being detected.

## 5. CISA KEV catalog

With the catalog loaded, findings whose CVEs are in it are flagged, counted,
listed with the CISA due date, and held to the shorter `KEV` SLA. Get the file
one of two ways:

* `py -3 app.py update-kev` on a machine with internet access, then copy
  `data\kev\known_exploited_vulnerabilities.json` across; or
* download the JSON or CSV from cisa.gov yourself and drop it in `data\kev`.

Refresh it monthly alongside the scans.

## 6. What the numbers mean

* **Health score** `= 100 x e^(-density / scale)`, where
  `density = (10xCritical + 4xHigh + 1xMedium + 0.2xLow) / hosts`. 100 means
  no findings; the grade bands are A >= 90, B >= 75, C >= 60, D >= 40, else F.
  It is a relative index for tracking direction month over month. Weights,
  scale and bands are in `config.json` under `health_score`; change them to
  match how your leadership wants to grade, then every month is re-scored
  consistently.
* **New / Fixed / Persistent** compare each enclave's scan with that enclave's
  previous scan. A finding is the same finding when host, plugin, port and
  protocol match. *Fixed* means it is no longer detected, so a host that drops
  out of the scan makes its findings look fixed; the *Scan coverage* card shows
  added and dropped hosts so you can tell the difference.
* **Age** is days since the finding was first seen in the loaded history. Load
  as many months as you have; the first month loaded is the floor.
* **Past SLA** counts open findings older than the window for their severity.
  Defaults in `config.json` are Critical 15 d, High 30 d, Medium 90 d,
  Low 180 d, KEV 14 d. **These are placeholders**: set them to the timelines
  your DAF / DoD guidance requires (for example IAVM or CISA BOD 22-01 due
  dates) before briefing the numbers.
* **Mean time to remediate** is first detection to the first scan in which the
  finding is gone, averaged over every finding closed in the loaded history.
* **Exploit available** uses Nessus's exploit flags (exploit_available,
  Metasploit / Core Impact / CANVAS). **KEV** is the CISA catalog match.
* **Risk** in the top-vulnerabilities table is the severity weight times the
  number of hosts affected, so one critical on 50 hosts outranks ten lows.

Every chart has a *Table* toggle, hover tooltips, and a light/dark theme. The
period and enclave selection is kept in the URL (`#period=2026-11&enclave=DMZ`)
so a view can be bookmarked.

## 7. Sharing with leadership

### Monthly brief (PDF)

The **Brief PDF** button in the header downloads a 3-4 page brief for the
period and enclave currently selected. `brief.bat` does the same for the
latest month, and the command line takes options:

```
py -3 app.py brief                                  latest month, all enclaves
py -3 app.py brief --period 2026-10                 a specific month
py -3 app.py brief --enclave DMZ --out DMZ-brief.pdf
```

The brief contains: headline tiles, plain-language key points written from
the numbers, the 13-month severity and health trend, the enclave table,
change since the previous scan, remediation timeliness against your SLA
windows, the top 10 vulnerabilities, the top KEV matches with CISA due dates,
and the POA&M picture (overdue items, untracked critical/high findings, items
closed on paper but still detected). It names plugins and POA&M items but
**no hostnames or IP addresses**.

The PDF is generated by the tool itself (no Word, no browser print dialog, no
extra software). Set the header text in `config.json`:

```json
"brief": { "title": "Vulnerability Posture Brief", "organization": "Your unit", "marking": "CUI" }
```

`marking` is printed centered at the top and bottom of every page; it is
blank by default, so set it to whatever your marking guidance requires.

### Standalone HTML

*Export HTML* (or `export.bat`, or `py -3 app.py export --period 2026-11`)
writes one self-contained `.html` file with the selected month's data for all
enclaves embedded. It opens in any browser with no server and no network, so
it can be emailed or dropped on a share. The per-host drill-down is only in
the live dashboard. The export is a snapshot of the data at the time it was
written; it includes hostnames, so handle it at the same classification as the
scans.

To let co-workers open the live dashboard from their own machines later, set
`"host": "0.0.0.0"` in `config.json` and point them at `http://<your-pc>:8050/`.
There is no login, so only do that on a network where that is acceptable.

## 8. Command reference

```
py -3 app.py                 ingest + serve (what run.bat does)
py -3 app.py ingest          import new files and exit
py -3 app.py serve           serve without re-importing
py -3 app.py export [--period YYYY-MM] [--out file.html]
py -3 app.py brief  [--period YYYY-MM] [--enclave NAME] [--out file.pdf]
py -3 app.py update-kev      download the KEV catalog (needs internet)
py -3 app.py reset           delete the database; next run rebuilds it from the files
py -3 app.py --data D:\other-folder   use a different data folder
py -3 app.py --port 9000     use another port
py -3 tools\selftest.py      verify the install on synthetic data
py -3 tools\make_sample_data.py [--out folder] [--months 13]   regenerate sample data
```

## 9. Troubleshooting

* **"No scans found"**: files must sit under `data\scans`; check the extension
  is `.nessus`, `.csv`, `.xlsx` or `.xml`, and open the *Data* panel for the
  message about each file.
* **An enclave shows "no scan this period"**: that enclave has no file whose
  scan date falls in the selected month. Totals and the banner tell you how
  many enclaves are missing.
* **Numbers look off after fixing a file**: click *Refresh data*; changed files
  are reloaded automatically. If in doubt, `py -3 app.py reset` and run again.
* **Port already in use**: `py -3 app.py --port 9000`, or change `server.port`.
* **Windows SmartScreen on the .bat files**: they only run `python app.py`;
  you can run that command yourself from a prompt in this folder instead.

## 10. Layout of the code

```
app.py                     command-line entry point
config.json                SLA windows, health-score weights, POA&M column map, server port
nessusdash/
  parsers/nessus_xml.py    .nessus reader (streaming)
  parsers/nessus_csv.py    Nessus / Tenable.sc CSV and combined .xlsx reader
  parsers/xlsx.py          minimal .xlsx reader (no openpyxl needed)
  parsers/poam.py          eMASS POA&M reader
  kev.py                   CISA KEV loader
  ingest.py                folder walk, change detection, SQLite loading
  metrics.py               every number on the dashboard
  server.py                local HTTP server + JSON API
  export.py                standalone HTML builder
  brief.py                 leadership brief content and layout
  pdf.py                   minimal PDF writer (no reportlab needed)
web/                       dashboard page (index.html, app.js, styles.css, vendored Chart.js)
tools/                     selftest.py, make_sample_data.py
```
