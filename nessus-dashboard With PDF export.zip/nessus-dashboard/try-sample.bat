@echo off
rem Opens the dashboard on the built-in synthetic sample data (nothing real).
cd /d "%~dp0"
if not exist sample-data\scans ( where py >nul 2>nul && (py -3 tools\make_sample_data.py) || (python tools\make_sample_data.py) )
where py >nul 2>nul && (py -3 app.py --data sample-data %*) || (python app.py --data sample-data %*)
if errorlevel 1 pause
