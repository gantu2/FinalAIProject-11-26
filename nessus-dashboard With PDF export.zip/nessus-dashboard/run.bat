@echo off
rem Starts the Nessus vulnerability dashboard. Requires Python 3.8+ on PATH.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 app.py %*) || (python app.py %*)
if errorlevel 1 pause
