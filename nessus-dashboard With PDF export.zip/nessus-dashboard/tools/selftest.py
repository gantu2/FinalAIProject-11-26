#!/usr/bin/env python3
"""Self-test: builds synthetic data in a temp folder, ingests it and checks the numbers hang together.
Run it on the target machine before loading real exports:  python tools/selftest.py
"""
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)


def main():
    from nessusdash import db as dbmod
    from nessusdash.config import load_config
    from nessusdash.ingest import Ingester
    from nessusdash.metrics import Metrics
    from nessusdash.export import build_static_html

    tmp = tempfile.mkdtemp(prefix="nessusdash-selftest-")
    failures = []
    try:
        subprocess.check_call([sys.executable, os.path.join(HERE, "make_sample_data.py"), "--out", tmp, "--months", "4"],
                              stdout=subprocess.DEVNULL)
        cfg = load_config(os.path.join(ROOT, "config.json"))
        cfg["data_dir"] = tmp
        conn = dbmod.connect(tmp)
        ing = Ingester(conn, cfg, log=lambda m: None)
        ing.run()
        errors = [m for lv, m in ing.messages if lv == "error"]
        if errors:
            failures.append("ingest errors: %s" % errors[:3])
        m = Metrics(conn, cfg)
        periods, enclaves = m.periods(), m.enclaves()
        if len(periods) != 4:
            failures.append("expected 4 periods, got %s" % periods)
        if len(enclaves) != 7:
            failures.append("expected 7 enclaves, got %s" % enclaves)
        d = m.dashboard()
        k = d["kpis"]
        total = sum(v["value"] for v in k["severity"].values())
        if total != k["total"]["value"] or total == 0:
            failures.append("severity counts do not add up")
        nf = d["new_fixed"]["totals"]
        if nf["new"] + nf["persistent"] != total:
            failures.append("new + persistent (%d) != total open (%d)" % (nf["new"] + nf["persistent"], total))
        if not (0 <= (k["health"]["score"] or 0) <= 100):
            failures.append("health score out of range")
        if sum(sum(b[s] for s in ("Critical", "High", "Medium", "Low")) for b in d["age"]) != total:
            failures.append("age buckets do not sum to total")
        sla = d["sla"]["by_severity"]
        if sum(v["total"] for v in sla.values()) != total:
            failures.append("SLA totals do not sum to total")
        if not d["top_vulns"] or not d["worst_hosts"]:
            failures.append("top lists empty")
        if not d["poam"]["loaded"] or d["meta"]["poam_items"] == 0:
            failures.append("POA&M not loaded")
        if d["meta"]["kev_entries"] == 0 or k["kev"]["value"] == 0:
            failures.append("KEV not matched")
        cov = d["poam"]["coverage_totals"]
        if cov["open"] + cov["closed"] + cov["not_on_poam"] != total:
            failures.append("POA&M coverage does not sum to total")
        per_enc = m.dashboard(enclave=enclaves[0])
        if per_enc["selection"]["enclave"] != enclaves[0]:
            failures.append("enclave filter failed")
        rows = m.findings(plugin_id=d["top_vulns"][0]["plugin_id"])
        if len(rows) != d["top_vulns"][0]["instances"]:
            failures.append("drill-down count mismatch")
        html = build_static_html(m)
        if "__EMBEDDED__" not in html or len(html) < 100000:
            failures.append("export looks wrong")
        from nessusdash.brief import build_brief_pdf
        pdf, _sel = build_brief_pdf(m, cfg)
        pdf_one, _sel = build_brief_pdf(m, cfg, enclave=enclaves[0])
        for blob in (pdf, pdf_one):
            if not blob.startswith(b"%PDF-1.4") or not blob.rstrip().endswith(b"%%EOF") or blob.count(b"/Type /Page ") < 2:
                failures.append("PDF brief looks wrong")
        # re-run: nothing should change
        ing2 = Ingester(conn, cfg, log=lambda m: None)
        if ing2.run() != 0:
            failures.append("second ingest re-imported unchanged files")
        # delete one file: its scan must disappear
        victim = [r["file_path"] for r in conn.execute("SELECT file_path FROM scans").fetchall()][0]
        os.remove(victim)
        Ingester(conn, cfg, log=lambda m: None).run()
        if conn.execute("SELECT COUNT(*) n FROM scans WHERE file_path=?", (victim,)).fetchone()["n"]:
            failures.append("deleted file still in database")
        conn.close()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if failures:
        print("SELF-TEST FAILED")
        for f in failures:
            print(" -", f)
        return 1
    print("Self-test passed: parsers, ingest, metrics, HTML export, PDF brief and change detection all OK (Python %s)" % sys.version.split()[0])
    return 0


if __name__ == "__main__":
    sys.exit(main())
