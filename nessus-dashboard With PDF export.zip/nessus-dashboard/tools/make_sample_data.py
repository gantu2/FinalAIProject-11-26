#!/usr/bin/env python3
"""Generate synthetic Nessus-style data to try the dashboard without real exports.

Creates, under sample-data/ (or --out):
  scans/<Enclave>/*.nessus        three enclaves as Nessus XML
  scans/<Enclave>/*.csv           two enclaves as Nessus CSV exports
  scans/combined_<YYYY-MM>.xlsx   two enclaves inside a combined workbook (one sheet each)
  poam/POAM_export.xlsx           an eMASS-style POA&M workbook
  kev/known_exploited_vulnerabilities.json   a small KEV-format catalog (fake CVE ids)
Everything is invented: hostnames, plugins, CVEs and dates carry no real-world meaning.
"""
import argparse
import datetime as dt
import json
import os
import random
import zipfile
from xml.sax.saxutils import escape

ENCLAVES = {
    "HQ-Users": ("nessus", 70), "HQ-Servers": ("nessus", 38), "DMZ": ("nessus", 16),
    "Ops-Center": ("csv", 44), "Lab": ("csv", 28),
    "Remote-Site-A": ("xlsx", 24), "Remote-Site-B": ("xlsx", 19),
}
OS_CHOICES = ["Microsoft Windows 11 Enterprise", "Microsoft Windows Server 2019", "Microsoft Windows Server 2022",
              "Red Hat Enterprise Linux 8", "Ubuntu 22.04", "Cisco IOS 15.x", "VMware ESXi 7.0"]
FAMILIES = ["Windows : Microsoft Bulletins", "Windows", "Red Hat Local Security Checks", "General",
            "Service detection", "Web Servers", "Misc.", "CISCO", "Ubuntu Local Security Checks"]
NAME_TEMPLATES = [
    ("Security Updates for Microsoft Office Products ({mon} {yr})", 3, 0.6),
    ("KB{kb}: Windows 11 Security Update ({mon} {yr})", 4, 0.7),
    ("KB{kb}: Windows Server 2019 Security Update ({mon} {yr})", 4, 0.7),
    ("Microsoft Edge (Chromium) < {ver} Multiple Vulnerabilities", 3, 0.5),
    ("Google Chrome < {ver} Multiple Vulnerabilities", 3, 0.5),
    ("Mozilla Firefox < {ver}", 3, 0.4),
    ("Oracle Java SE {ver} Multiple Vulnerabilities", 4, 0.6),
    ("OpenSSL 3.0.x < 3.0.{n} Multiple Vulnerabilities", 3, 0.3),
    ("Apache Log4j < 2.{n} Remote Code Execution", 4, 0.9),
    ("RHEL 8 : kernel (RHSA-{yr}:{n4})", 3, 0.3),
    ("Ubuntu 22.04 LTS : linux vulnerabilities (USN-{n4}-1)", 3, 0.3),
    ("Cisco IOS Software SNMP Remote Code Execution", 4, 0.8),
    ("VMware ESXi 7.0 Multiple Vulnerabilities (VMSA-{yr}-{n4})", 4, 0.6),
    ("SMB Signing not required", 2, 0.0),
    ("SSL Certificate Cannot Be Trusted", 2, 0.0),
    ("SSL Medium Strength Cipher Suites Supported (SWEET32)", 2, 0.1),
    ("TLS Version 1.0 Protocol Detection", 2, 0.0),
    ("SSH Weak Key Exchange Algorithms Enabled", 1, 0.0),
    ("SSH Server CBC Mode Ciphers Enabled", 1, 0.0),
    ("Microsoft Windows SMBv1 Multiple Vulnerabilities", 4, 0.95),
    ("Adobe Acrobat < {ver} Multiple Vulnerabilities (APSB{yy}-{n2})", 4, 0.5),
    ("7-Zip < {ver} Multiple Vulnerabilities", 3, 0.2),
    ("Wireshark {ver} Multiple Vulnerabilities", 2, 0.1),
    ("Microsoft .NET Core SEoL", 4, 0.0),
    ("Microsoft SQL Server Unsupported Version Detection", 4, 0.0),
    ("Unsupported Web Server Detection", 4, 0.1),
    ("HTTP TRACE / TRACK Methods Allowed", 2, 0.0),
    ("Terminal Services Doesn't Use Network Level Authentication (NLA) Only", 2, 0.0),
    ("DNS Server Cache Snooping Remote Information Disclosure", 2, 0.0),
    ("ICMP Timestamp Request Remote Date Disclosure", 1, 0.0),
    ("Microsoft Windows Unquoted Service Path Enumeration", 2, 0.2),
    ("Apache Tomcat < {ver} Multiple Vulnerabilities", 3, 0.4),
    ("PHP < {ver} Multiple Vulnerabilities", 3, 0.4),
    ("curl < {ver} Heap Buffer Overflow", 3, 0.3),
    ("MS KB{kb}: Security Update for .NET Framework ({mon} {yr})", 3, 0.5),
    ("Microsoft Exchange Server Multiple Vulnerabilities ({mon} {yr})", 4, 0.9),
    ("Fortinet FortiOS < {ver} SSL VPN Heap Overflow", 4, 0.9),
    ("Ivanti Connect Secure Authentication Bypass", 4, 0.95),
    ("Palo Alto PAN-OS Command Injection", 4, 0.9),
    ("Veeam Backup & Replication < {ver} Unauthenticated RCE", 4, 0.8),
]
SOLUTIONS = ["Apply the vendor-supplied patch.", "Upgrade to the latest supported version.",
             "Disable the service or restrict access with a firewall rule.",
             "Apply the appropriate STIG configuration setting.", "Microsoft has released a set of patches."]
MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def month_list(end, n):
    y, m = end.year, end.month
    out = []
    for _ in range(n):
        out.append((y, m))
        m -= 1
        if m == 0:
            y, m = y - 1, 12
    return list(reversed(out))


class Catalog:
    def __init__(self, rng, months):
        self.rng = rng
        self.plugins = {}   # plugin_id -> dict
        self.kev = []
        self.by_month = {}
        pid = 100000
        for i, (y, m) in enumerate(months):
            batch = []
            for tpl, sev, exploit_p in NAME_TEMPLATES:
                if rng.random() < (0.35 if "{mon}" in tpl else 0.18):
                    pid += rng.randint(3, 40)
                    name = tpl.format(mon=MONTHS[m - 1], yr=y, yy=str(y)[2:], kb=rng.randint(5000000, 5099999),
                                      ver=f"{rng.randint(90,140)}.0.{rng.randint(1000,7000)}.{rng.randint(10,200)}",
                                      n=rng.randint(1, 30), n2=rng.randint(10, 99), n4=rng.randint(1000, 9999))
                    sev_actual = sev if rng.random() < 0.8 else max(1, sev - 1)
                    cves = []
                    if sev_actual >= 2 and rng.random() < 0.8:
                        cves = [f"CVE-{y}-{rng.randint(20000, 69999)}" for _ in range(rng.randint(1, 4))]
                    exploit = rng.random() < exploit_p
                    is_kev = bool(cves) and exploit and rng.random() < 0.45
                    if is_kev:
                        added = dt.date(y, m, min(28, rng.randint(1, 28)))
                        self.kev.append({"cveID": cves[0], "vendorProject": "ExampleVendor", "product": name.split(" ")[0],
                                         "vulnerabilityName": name, "dateAdded": added.isoformat(),
                                         "shortDescription": "Synthetic entry for dashboard testing.",
                                         "requiredAction": "Apply updates per vendor instructions.",
                                         "dueDate": (added + dt.timedelta(days=21)).isoformat(),
                                         "knownRansomwareCampaignUse": "Known" if rng.random() < 0.3 else "Unknown",
                                         "notes": ""})
                    self.plugins[pid] = {
                        "id": pid, "name": name, "sev": sev_actual, "family": rng.choice(FAMILIES),
                        "cves": cves, "exploit": exploit, "kev": is_kev,
                        "frameworks": [f for f in ("Metasploit", "Core Impact", "CANVAS") if exploit and rng.random() < 0.5],
                        "pub": dt.date(y, m, min(28, rng.randint(1, 28))).isoformat(),
                        "cvss3": round(rng.uniform(3.0, 9.8), 1) if sev_actual > 0 else None,
                        "vpr": round(rng.uniform(2.0, 9.6), 1) if sev_actual > 0 else None,
                        "solution": rng.choice(SOLUTIONS), "port": rng.choice([0, 445, 443, 80, 22, 3389, 135, 8080, 161]),
                        "proto": "tcp", "windows_only": "Windows" in name or "KB" in name or "Office" in name or ".NET" in name,
                        "linux_only": "RHEL" in name or "Ubuntu" in name, "net_only": "Cisco" in name,
                        "born": i,
                    }
                    batch.append(pid)
            self.by_month[i] = batch
        # a backlog of older plugins that existed before the first month
        self.by_month[-1] = [p for p in self.plugins if rng.random() < 0.0]  # none; handled by first month


def simulate(rng, enclave, n_hosts, months, cat):
    """Return list of (date, hosts, findings) per month."""
    hosts = {}
    for i in range(n_hosts):
        os_name = rng.choice(OS_CHOICES)
        kind = "ws" if "Windows 11" in os_name else ("srv" if "Server" in os_name or "Linux" in os_name or "ESXi" in os_name or "Ubuntu" in os_name else "net")
        name = f"{kind}-{enclave.lower()}-{i+1:03d}"
        hosts[name] = {"fqdn": f"{name}.example.internal", "ip": f"10.{rng.randint(10,99)}.{rng.randint(1,254)}.{rng.randint(2,250)}",
                       "netbios": name.upper() if "Windows" in os_name else "", "os": os_name,
                       "neglected": rng.random() < 0.12}
    open_f = {}   # (host, pid) -> start month
    results = []
    for mi, (y, m) in enumerate(months):
        # fixes
        fix_rate = {4: 0.55, 3: 0.4, 2: 0.25, 1: 0.15}
        for key in list(open_f):
            h, pid = key
            p = cat.plugins[pid]
            rate = fix_rate[p["sev"]] * (0.25 if hosts[h]["neglected"] else 1.0)
            if mi >= len(months) - 3:
                rate *= 1.25  # improving recently
            if rng.random() < rate:
                del open_f[key]
        # new findings: this month's plugins plus some older ones
        candidates = cat.by_month.get(mi, [])
        older = [pid for pid in cat.plugins if cat.plugins[pid]["born"] < mi]
        for h, hd in hosts.items():
            for pid in candidates:
                p = cat.plugins[pid]
                if p["windows_only"] and "Windows" not in hd["os"]:
                    continue
                if p["linux_only"] and not ("Linux" in hd["os"] or "Ubuntu" in hd["os"]):
                    continue
                if p["net_only"] and "Cisco" not in hd["os"]:
                    continue
                prob = 0.35 if p["sev"] >= 3 else 0.5
                if rng.random() < prob:
                    open_f.setdefault((h, pid), mi)
            for pid in rng.sample(older, min(len(older), 3)) if older else []:
                p = cat.plugins[pid]
                if p["windows_only"] and "Windows" not in hd["os"]:
                    continue
                if rng.random() < 0.08:
                    open_f.setdefault((h, pid), mi)
        if mi == 0:  # seed a backlog so the first month isn't empty
            for h, hd in hosts.items():
                for pid in rng.sample(list(cat.plugins), 6):
                    p = cat.plugins[pid]
                    if p["born"] <= 2 and not (p["windows_only"] and "Windows" not in hd["os"]):
                        open_f.setdefault((h, pid), 0)
        # host churn
        scanned = {h: d for h, d in hosts.items() if rng.random() > 0.03}
        if mi > 0 and rng.random() < 0.5:
            i = len(hosts) + 1
            name = f"ws-{enclave.lower()}-{i:03d}"
            hosts[name] = {"fqdn": f"{name}.example.internal", "ip": f"10.{rng.randint(10,99)}.{rng.randint(1,254)}.{rng.randint(2,250)}",
                           "netbios": name.upper(), "os": "Microsoft Windows 11 Enterprise", "neglected": False}
            scanned[name] = hosts[name]
        date = dt.date(y, m, rng.randint(3, 12))
        findings = [(h, pid) for (h, pid) in open_f if h in scanned]
        results.append((date, dict(scanned), findings))
    return results


def write_nessus(path, enclave, date, hosts, findings, cat, rng):
    start = dt.datetime.combine(date, dt.time(8, 0))
    lines = ['<?xml version="1.0" ?>', '<NessusClientData_v2>', '<Policy><policyName>Monthly Credentialed Scan</policyName></Policy>',
             f'<Report name="{escape(enclave)} monthly" xmlns:cm="http://www.nessus.org/cm">']
    by_host = {}
    for h, pid in findings:
        by_host.setdefault(h, []).append(pid)
    for h, hd in hosts.items():
        hs = start + dt.timedelta(minutes=rng.randint(0, 240))
        lines.append(f'<ReportHost name="{escape(hd["ip"])}"><HostProperties>')
        lines.append(f'<tag name="HOST_START">{hs.strftime("%a %b %d %H:%M:%S %Y")}</tag>')
        lines.append(f'<tag name="HOST_END">{(hs + dt.timedelta(minutes=25)).strftime("%a %b %d %H:%M:%S %Y")}</tag>')
        lines.append(f'<tag name="host-ip">{hd["ip"]}</tag><tag name="host-fqdn">{hd["fqdn"]}</tag>')
        if hd["netbios"]:
            lines.append(f'<tag name="netbios-name">{hd["netbios"]}</tag>')
        lines.append(f'<tag name="operating-system">{escape(hd["os"])}</tag></HostProperties>')
        lines.append('<ReportItem port="0" svc_name="general" protocol="tcp" severity="0" pluginID="19506" pluginName="Nessus Scan Information" pluginFamily="Settings"><risk_factor>None</risk_factor></ReportItem>')
        for pid in by_host.get(h, []):
            p = cat.plugins[pid]
            lines.append(f'<ReportItem port="{p["port"]}" svc_name="general" protocol="{p["proto"]}" severity="{p["sev"]}" '
                         f'pluginID="{pid}" pluginName="{escape(p["name"])}" pluginFamily="{escape(p["family"])}">')
            lines.append(f'<risk_factor>{["None","Low","Medium","High","Critical"][p["sev"]]}</risk_factor>')
            if p["cvss3"]:
                lines.append(f'<cvss3_base_score>{p["cvss3"]}</cvss3_base_score><cvss_base_score>{max(1.0, p["cvss3"] - 0.6):.1f}</cvss_base_score>')
            if p["vpr"]:
                lines.append(f'<vpr_score>{p["vpr"]}</vpr_score>')
            for c in p["cves"]:
                lines.append(f'<cve>{c}</cve>')
            lines.append(f'<exploit_available>{"true" if p["exploit"] else "false"}</exploit_available>')
            for f in p["frameworks"]:
                tag = {"Metasploit": "exploit_framework_metasploit", "Core Impact": "exploit_framework_core", "CANVAS": "exploit_framework_canvas"}[f]
                lines.append(f'<{tag}>true</{tag}>')
            lines.append(f'<plugin_publication_date>{p["pub"].replace("-", "/")}</plugin_publication_date>')
            lines.append(f'<solution>{escape(p["solution"])}</solution><synopsis>Synthetic finding.</synopsis>')
            lines.append('<plugin_output>Synthetic plugin output.</plugin_output></ReportItem>')
        lines.append('</ReportHost>')
    lines.append('</Report></NessusClientData_v2>')
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


CSV_HEADER = ["Plugin ID", "CVE", "CVSS v2.0 Base Score", "Risk", "Host", "Protocol", "Port", "Name", "Synopsis", "Description",
              "Solution", "See Also", "Plugin Output", "STIG Severity", "CVSS v3.0 Base Score", "CVSS v2.0 Temporal Score",
              "CVSS v3.0 Temporal Score", "VPR Score", "Risk Factor", "BID", "XREF", "MSKB", "Plugin Publication Date",
              "Plugin Modification Date", "Metasploit", "Core Impact", "CANVAS"]


def csv_rows(hosts, findings, cat, include_info=True):
    rows = []
    risk = ["None", "Low", "Medium", "High", "Critical"]
    for h, hd in hosts.items():
        if include_info:
            rows.append(["19506", "", "", "None", hd["ip"], "tcp", "0", "Nessus Scan Information", "", "", "", "", "", "", "", "", "", "", "None", "", "", "", "", "", "", "", ""])
    for h, pid in findings:
        p, hd = cat.plugins[pid], hosts[h]
        rows.append([str(pid), ",".join(p["cves"]), f"{max(1.0, (p['cvss3'] or 1) - 0.6):.1f}", risk[p["sev"]], hd["fqdn"], p["proto"], str(p["port"]),
                     p["name"], "Synthetic finding.", "Synthetic description.", p["solution"], "", "Synthetic output.", "",
                     str(p["cvss3"] or ""), "", "", str(p["vpr"] or ""), risk[p["sev"]], "", "", "", p["pub"].replace("-", "/"), "",
                     "true" if "Metasploit" in p["frameworks"] else "", "true" if "Core Impact" in p["frameworks"] else "",
                     "true" if "CANVAS" in p["frameworks"] else ""])
    return rows


def write_csv(path, hosts, findings, cat):
    import csv
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(CSV_HEADER)
        w.writerows(csv_rows(hosts, findings, cat))


def write_xlsx(path, sheets):
    """sheets: list of (name, rows). Minimal writer with inline strings and numbers."""
    def col(n):
        s = ""
        n += 1
        while n:
            n, r = divmod(n - 1, 26)
            s = chr(65 + r) + s
        return s
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml",
                    '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                    '<Default Extension="xml" ContentType="application/xml"/>'
                    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                    + "".join(f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets)))
                    + '</Types>')
        zf.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        zf.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
                    + "".join(f'<sheet name="{escape(n)}" sheetId="{i+1}" r:id="rId{i+1}"/>' for i, (n, _r) in enumerate(sheets)) + '</sheets></workbook>')
        zf.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                    + "".join(f'<Relationship Id="rId{i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i+1}.xml"/>' for i in range(len(sheets))) + '</Relationships>')
        for i, (_n, rows) in enumerate(sheets):
            parts = ['<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
            for ri, row in enumerate(rows):
                parts.append(f'<row r="{ri+1}">')
                for ci, v in enumerate(row):
                    ref = f"{col(ci)}{ri+1}"
                    if v is None or v == "":
                        continue
                    if isinstance(v, (int, float)) and not isinstance(v, bool):
                        parts.append(f'<c r="{ref}"><v>{v}</v></c>')
                    else:
                        parts.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(v))}</t></is></c>')
                parts.append('</row>')
            parts.append('</sheetData></worksheet>')
            zf.writestr(f"xl/worksheets/sheet{i+1}.xml", "".join(parts))


def excel_serial(d):
    return (d - dt.date(1899, 12, 30)).days


def write_poam(path, cat, latest_findings, rng, today):
    """eMASS-style POA&M: metadata block, then the real header row."""
    header = ["", "POA&M Item ID", "Control Vulnerability Description", "Security Control Number (NC/NA/CP Only)", "Office/Org",
              "Security Checks", "Resources Required", "Scheduled Completion Date", "Milestone with Completion Dates",
              "Milestone Changes", "Source Identifying Vulnerability", "Status", "Comments", "Raw Severity", "Devices Affected",
              "Mitigations", "Predisposing Conditions", "Severity", "Relevance of Threat", "Threat Description", "Likelihood",
              "Impact", "Impact Description", "Residual Risk Level", "Recommendations", "Resulting Residual Risk after Proposed Mitigations"]
    rows = [["", "Date Exported:", today.strftime("%m/%d/%Y")], ["", "Exported By:", "ISSM"], ["", "DoD Component:", "USAF"],
            ["", "System / Project Name:", "Synthetic Enclave Set"], ["", "DoD IT Registration Number:", "0000"],
            ["", "System Type:", "IS Major Application"], ["", "POC Name:", "Jane Doe"], [], header]
    present = {}
    for pid, hosts in latest_findings.items():
        present[pid] = hosts
    pids = sorted(present, key=lambda p: (-cat.plugins[p]["sev"], -present[p]))
    chosen = pids[: int(len(pids) * 0.6)]
    rng.shuffle(chosen)
    for i, pid in enumerate(chosen):
        p = cat.plugins[pid]
        r = rng.random()
        status = "Ongoing" if r < 0.6 else ("Completed" if r < 0.8 else ("Risk Accepted" if r < 0.92 else "Not Applicable"))
        sched = today + dt.timedelta(days=rng.randint(-120, 150))
        sev = ["", "I", "II", "III", "IV"][p["sev"]]
        raw = ["", "Low", "Moderate", "High", "Very High"][p["sev"]]
        rows.append(["", f"V-{1000 + i}", f"Vulnerability: {p['name']}", "SI-2", "Cyber Ops",
                     f"Plugin {pid}" if rng.random() < 0.7 else str(pid), "Patch window / 2 FTE hours",
                     excel_serial(sched) if rng.random() < 0.8 else sched.strftime("%m/%d/%Y"),
                     f"Milestone 1: Deploy patch ({sched.strftime('%m/%d/%Y')})", "",
                     f"Nessus Scan, Plugin ID {pid}, {', '.join(p['cves'][:2])}", status, "", raw, present[pid], "", "", sev,
                     "High", "", "Moderate", "Moderate", "", "Moderate", "", "Low"])
    # a few items with no plugin ids (manual controls)
    for i in range(4):
        rows.append(["", f"V-{2000 + i}", "AC-2: Account management review overdue", "AC-2", "ISSO", "", "", excel_serial(today + dt.timedelta(days=30)),
                     "", "", "Self Assessment", "Ongoing", "", "Moderate", "", "", "", "II", "", "", "", "", "", "", "", ""])
    write_xlsx(path, [("POA&M", rows)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sample-data"))
    ap.add_argument("--months", type=int, default=13)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--end", default=None, help="last month YYYY-MM (default: current month)")
    args = ap.parse_args()
    rng = random.Random(args.seed)
    today = dt.date.today()
    end = dt.date(int(args.end[:4]), int(args.end[5:7]), 1) if args.end else today.replace(day=1)
    months = month_list(end, args.months)
    cat = Catalog(rng, months)
    out = args.out
    for d in ("scans", "poam", "kev"):
        os.makedirs(os.path.join(out, d), exist_ok=True)
    combined = {}   # (y,m) -> list of (sheet, rows)
    latest = {}
    for enclave, (fmt, n_hosts) in ENCLAVES.items():
        sim = simulate(rng, enclave, n_hosts, months, cat)
        for (y, m), (date, hosts, findings) in zip(months, sim):
            if fmt == "nessus":
                d = os.path.join(out, "scans", enclave)
                os.makedirs(d, exist_ok=True)
                write_nessus(os.path.join(d, f"{enclave}_{date.isoformat()}.nessus"), enclave, date, hosts, findings, cat, rng)
            elif fmt == "csv":
                d = os.path.join(out, "scans", enclave)
                os.makedirs(d, exist_ok=True)
                write_csv(os.path.join(d, f"{enclave}_{date.isoformat()}.csv"), hosts, findings, cat)
            else:
                combined.setdefault((y, m, date), []).append((enclave, [CSV_HEADER] + csv_rows(hosts, findings, cat)))
        date, hosts, findings = sim[-1]
        for h, pid in findings:
            latest[pid] = latest.get(pid, 0) + 1
    for (y, m, date), sheets in combined.items():
        write_xlsx(os.path.join(out, "scans", f"Combined_Remote_Sites_{date.isoformat()}.xlsx"), sheets)
    write_poam(os.path.join(out, "poam", "POAM_export.xlsx"), cat, latest, rng, today)
    with open(os.path.join(out, "kev", "known_exploited_vulnerabilities.json"), "w", encoding="utf-8") as fh:
        json.dump({"title": "Synthetic KEV catalog (fake CVE ids)", "catalogVersion": "synthetic", "count": len(cat.kev),
                   "vulnerabilities": cat.kev}, fh, indent=1)
    print(f"Sample data written to {out}: {len(ENCLAVES)} enclaves x {len(months)} months, {len(cat.plugins)} plugins, {len(cat.kev)} KEV entries")


if __name__ == "__main__":
    main()
