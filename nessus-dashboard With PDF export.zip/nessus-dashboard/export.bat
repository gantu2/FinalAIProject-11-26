@echo off
rem Writes a standalone HTML dashboard you can email or drop on a share.
cd /d "%~dp0"
where py >nul 2>nul && (py -3 app.py export %*) || (python app.py export %*)
pause
